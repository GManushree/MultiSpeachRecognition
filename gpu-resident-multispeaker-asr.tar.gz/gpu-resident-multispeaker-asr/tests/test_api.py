import io

import numpy as np
import pytest
import soundfile as sf
import torch
import yaml


@pytest.fixture(scope="module")
def client(tmp_path_factory, tiny_corpus):
    from fastapi.testclient import TestClient
    from conftest import ROOT, TINY
    from src.models.joint_model import JointModel
    from src.training.checkpoints import save_checkpoint
    d = tmp_path_factory.mktemp("api")
    torch.manual_seed(0)
    m = JointModel(TINY)
    save_checkpoint(d / "m.pt", m, 0, {}, "test")
    cfg = yaml.safe_load((ROOT / "configs/inference.yaml").read_text())
    cfg.pop("defaults")
    cfg.update(model=TINY, checkpoint=str(d / "m.pt"), lm_checkpoint=None)
    cfg["api"]["max_upload_mb"] = 1
    (d / "inf.yaml").write_text(yaml.safe_dump(cfg))
    import os
    os.environ["MSASR_CONFIG"] = str(d / "inf.yaml")
    from src.api.main import app
    with TestClient(app) as c:
        yield c
    os.environ.pop("MSASR_CONFIG")


def _wav(seconds=1.0):
    buf = io.BytesIO()
    sf.write(buf, (0.1 * np.random.RandomState(0).randn(int(16000 * seconds))).astype(np.float32), 16000, format="WAV")
    return buf.getvalue()


def test_health_and_model_info(client):
    h = client.get("/health").json()
    assert h["status"] == "ok" and h["model_loaded"]
    info = client.get("/model-info").json()
    assert info["sample_rate"] == 16000 and info["n_mels"] == 80 and info["speaker_capacity"] == 3


def test_transcribe_valid(client):
    r = client.post("/transcribe", files={"file": ("a.wav", _wav(), "audio/wav")})
    assert r.status_code == 200
    j = r.json()
    assert j["duration_s"] == pytest.approx(1.0) and j["rtf"] > 0 and j["host_device_crossings"] == 2
    assert j["device"] in ("cpu", "cuda") and isinstance(j["segments"], list)


def test_transcribe_rejects_bad_inputs(client):
    assert client.post("/transcribe", files={"file": ("a.wav", b"", "audio/wav")}).status_code == 400
    assert client.post("/transcribe", files={"file": ("a.wav", b"garbage!", "audio/wav")}).status_code == 400
    assert client.post("/transcribe", files={"file": ("a.wav", _wav(40.0), "audio/wav")}).status_code == 413
