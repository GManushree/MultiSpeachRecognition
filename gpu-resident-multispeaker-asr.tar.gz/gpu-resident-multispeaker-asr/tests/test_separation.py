import numpy as np
import torch

from src.evaluation.separation_metrics import pit_si_sdr
from src.models.separator import AttractorConditionedSeparator
from src.training.losses import si_sdr

CFG = dict(enc_dim=16, kernel=32, stride=16, bottleneck=16, hidden=32, n_blocks=2, n_repeats=1, cond_dim=8)


def test_output_shape_any_length_and_k():
    m = AttractorConditionedSeparator(**CFG)
    for n, k in ((16000, 2), (12345, 3), (20, 1)):
        y = m(torch.randn(2, n), torch.randn(2, k, 8), torch.rand(2, 10, k))
        assert y.shape == (2, k, n) and torch.isfinite(y).all()


def test_si_sdr_known_values():
    torch.manual_seed(0)
    ref = torch.randn(16000)
    assert si_sdr(ref, ref) > 70
    noise = torch.randn(16000)
    noise = noise - (noise @ ref) / (ref @ ref) * ref                              # orthogonal noise
    noise = noise / noise.norm() * ref.norm() * 10 ** (-10 / 20)                    # 10 dB
    assert abs(float(si_sdr(ref + noise, ref)) - 10.0) < 0.05
    assert abs(float(si_sdr(3.7 * (ref + noise), ref)) - float(si_sdr(ref + noise, ref))) < 1e-3  # scale invariant


def test_pit_metric_matches_swapped_outputs():
    torch.manual_seed(0)
    r = torch.randn(2, 8000)
    res = pit_si_sdr(r.flip(0) + 0.01 * torch.randn(2, 8000), r, r.sum(0))
    assert res["perm"] == [1, 0] and min(res["si_sdr"]) > 30 and res["missed"] == 0
    res2 = pit_si_sdr(r[:1], r)
    assert res2["missed"] == 1


def test_separation_loss_gradients_reach_all_parts():
    m = AttractorConditionedSeparator(**CFG)
    att = torch.randn(1, 2, 8, requires_grad=True)
    y = m(torch.randn(1, 4000), att, torch.rand(1, 7, 2))
    (-si_sdr(y[0], torch.randn(2, 4000)).mean()).backward()
    assert att.grad.abs().sum() > 0  # conditioning path is differentiable (joint training)
    assert all(p.grad is not None for n, p in m.named_parameters() if "film" not in n)


def test_learns_to_separate_toy_mixture():
    """Two tones; attractor k selects tone k. SI-SDRi must exceed 10 dB after a short fit."""
    torch.manual_seed(0)
    t = torch.arange(8000) / 16000
    s = torch.stack([0.3 * torch.sin(2 * np.pi * 400 * t), 0.3 * torch.sin(2 * np.pi * 2300 * t)])
    mix = s.sum(0, keepdim=True)
    att = torch.eye(2, 8)[None]
    m = AttractorConditionedSeparator(**CFG)
    opt = torch.optim.Adam(m.parameters(), 3e-3)
    for _ in range(200):
        loss = -si_sdr(m(mix, att)[0], s).mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
    with torch.no_grad():
        res = pit_si_sdr(m(mix, att)[0], s, mix[0])
    assert res["perm"] == [0, 1]           # stream identity follows the attractor
    assert min(res["si_sdri"]) > 10
