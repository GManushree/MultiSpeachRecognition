import json

import pytest

from src.models.aggregation import (UNKNOWN_SPEAKER, Segment, Word, aggregate, to_json, to_srt, to_text,
                                    tokens_to_words, words_to_segments)


def test_tokens_to_words_timestamps():
    w = tokens_to_words("hi yo", [10, 11, 0, 20, 22], 0.02, offset_s=1.0)
    assert [(x.text, round(x.start, 2), round(x.end, 2)) for x in w] == [("hi", 1.2, 1.24), ("yo", 1.4, 1.46)]


def test_overlap_preserved_and_sorted():
    segs = [Segment(1.5, 3.2, "SPEAKER_01", "another"), Segment(0.25, 2.25, "SPEAKER_00", "example")]
    out = aggregate(segs)
    assert [s.speaker_id for s in out] == ["SPEAKER_00", "SPEAKER_01"]
    assert out[0].end > out[1].start  # overlapping intervals kept


def test_duplicates_removed_and_neighbours_merged():
    segs = [Segment(0.0, 1.0, "A", "hello"), Segment(0.02, 1.01, "A", "hello"),
            Segment(1.3, 2.0, "A", "world"), Segment(0.5, 1.5, "B", "hello")]
    out = aggregate(segs, merge_gap=0.5)
    texts = {(s.speaker_id, s.text) for s in out}
    assert texts == {("A", "hello world"), ("B", "hello")}


def test_validation_and_missing_labels():
    with pytest.raises(ValueError):
        aggregate([Segment(2.0, 1.0, "A", "x")])
    with pytest.raises(ValueError):
        aggregate([Segment(float("nan"), 1.0, "A", "x")])
    out = aggregate([Segment(-0.1, 9.0, "", "x")], duration=5.0)
    assert out[0].speaker_id == UNKNOWN_SPEAKER and out[0].uncertain and out[0].start == 0 and out[0].end == 5.0


def test_words_to_segments_gap():
    ws = [Word("a", 0, 0.2), Word("b", 0.3, 0.5), Word("c", 2.0, 2.2)]
    segs = words_to_segments(ws, "S", max_gap=0.6)
    assert [s.text for s in segs] == ["a b", "c"]


def test_exports(tmp_path):
    segs = [Segment(0.25, 2.25, "SPEAKER_00", "example transcription")]
    d = json.loads(to_json(segs, tmp_path / "t.json"))
    assert d == [{"start": 0.25, "end": 2.25, "speaker_id": "SPEAKER_00", "text": "example transcription"}]
    assert "SPEAKER_00: example" in to_text(segs)
    assert "00:00:00,250 --> 00:00:02,250" in to_srt(segs)


def test_diarization_timestamps_place_words_in_active_regions():
    import numpy as np
    from src.inference.pipeline import active_regions, place_words
    act = np.zeros(100)
    act[10:30] = 0.9          # 0.40-1.20 s
    act[31:33] = 0.9          # 1-frame gap -> merged
    act[60:80] = 0.9          # 2.40-3.20 s
    regs = active_regions(act, 0.5, offset=1.0)
    assert [(round(a, 2), round(b, 2)) for a, b in regs] == [(1.4, 2.32), (3.4, 4.2)]
    words = place_words([Word("aa", 0, 0), Word("bbbb", 0, 0), Word("c", 0, 0)], regs)
    assert [w.text for w in words] == ["aa", "bbbb", "c"]
    assert words[0].start == regs[0][0] and words[-1].end <= regs[-1][1] + 1e-9
    assert all(a.end <= b.start + 1e-9 for a, b in zip(words, words[1:]))           # ordered, non-overlapping
    inside = lambda t: any(a - 1e-9 <= t <= b + 1e-9 for a, b in regs)               # noqa: E731
    assert all(inside(w.start) for w in words)
