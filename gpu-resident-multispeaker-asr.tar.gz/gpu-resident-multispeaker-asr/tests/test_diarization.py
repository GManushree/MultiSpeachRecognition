import torch

from src.models.stdn import STDN, DiarizationOutput, estimate_speaker_count
from src.training.losses import existence_loss, hungarian, pairwise_bce

CFG = dict(n_mels=80, d_model=32, n_heads=2, n_layers=1, ff_dim=64, dropout=0.0, max_speakers=3)


def test_output_ranges_and_shapes():
    torch.manual_seed(0)
    m = STDN(**CFG).eval()
    out = m(torch.randn(2, 80, 201))
    assert out.activity_prob.shape == (2, 51, 4) and out.exist_prob.shape == (2, 4)
    assert (out.activity_prob >= 0).all() and (out.activity_prob <= 1).all()


def test_speaker_count_formula():
    p = torch.tensor([[0.9, 0.8, 0.2, 0.1], [0.1, 0.1, 0.1, 0.1], [0.9, 0.55, 0.9, 0.3]])
    k, mask, unc = estimate_speaker_count(p)
    assert k.tolist() == [2, 0, 3]                    # K_hat = count(p_exist > 0.5)
    assert mask[1].sum() == 0                          # no-speech recording
    assert unc.tolist() == [False, False, True]        # 0.55 is within the uncertainty margin


def test_multiple_speakers_active_in_same_frame():
    z = torch.tensor([[[1.0, 1.0], [1.0, -1.0]]])      # (B=1, T=2, D=2)
    a = torch.tensor([[[2.0, 0.0], [0.0, 2.0]]])        # two attractors
    out = DiarizationOutput(z, a, torch.zeros(1, 2), torch.einsum("btd,bsd->bts", z, a))
    act = out.activity_prob[0] > 0.5
    assert act[0].all()                                 # frame 0: both speakers active
    assert act[1].tolist() == [True, False]


def test_padding_invariance():
    torch.manual_seed(1)
    m = STDN(**CFG).eval()
    a, b = torch.randn(1, 80, 161), torch.randn(1, 80, 241)
    batch = torch.zeros(2, 80, 241)
    batch[0, :, :161], batch[1] = a[0], b[0]
    with torch.no_grad():
        single = m(a, torch.tensor([161]), shuffle=False)
        batched = m(batch, torch.tensor([161, 241]), shuffle=False)
    T = single.activity_logits.shape[1]
    assert torch.allclose(single.activity_logits[0], batched.activity_logits[0, :T], atol=1e-4)
    assert torch.allclose(single.exist_logits[0], batched.exist_logits[0], atol=1e-4)


def test_existence_loss_handles_zero_and_one_speaker():
    logits = torch.tensor([[-5.0, -5.0, -5.0, -5.0], [5.0, -5.0, 0.0, 0.0]])
    l = existence_loss(logits, torch.tensor([0, 1]))
    assert l < 0.02  # both correct: 0 speakers -> first off; 1 speaker -> first on, second off


def test_pit_assignment_recovers_permutation():
    labels = torch.tensor([[1, 0], [1, 0], [0, 1], [0, 1]], dtype=torch.float)
    logits = torch.tensor([[-6, 6], [-6, 6], [6, -6], [6, -6]], dtype=torch.float)  # swapped speakers
    perm = hungarian(pairwise_bce(logits, labels, torch.ones(4, dtype=torch.bool)))
    assert perm.tolist() == [1, 0]


def test_stdn_learns_speaker_count_on_toy_data():
    """Overfit: 'speakers' are tones; K tones -> K speakers. Count accuracy must reach 100%."""
    torch.manual_seed(0)
    m = STDN(**CFG)
    from src.audio.mel_features import LogMel
    lm = LogMel()
    t = torch.arange(16000) / 16000
    tones = [torch.sin(2 * torch.pi * f * t) * 0.3 for f in (300, 1100, 2900)]
    mixes, labels, ks = [], [], []
    for k in (0, 1, 2, 3, 2, 1):
        x = torch.zeros(16000)
        lab = torch.zeros(26, 3)
        for j in range(k):
            s0 = j * 4000
            x[s0:s0 + 9000] += tones[j][s0:s0 + 9000]
            lab[s0 // 640: (s0 + 9000) // 640, j] = 1
        mixes.append(x + 0.001 * torch.randn(16000))
        labels.append(lab)
        ks.append(k)
    feats = lm(torch.stack(mixes))
    labels, ks = torch.stack(labels), torch.tensor(ks)
    opt = torch.optim.Adam(m.parameters(), 3e-3)
    for _ in range(150):
        out = m(feats)
        loss = existence_loss(out.exist_logits, ks)
        for b in range(len(ks)):
            if ks[b]:
                c = pairwise_bce(out.activity_logits[b, :, : ks[b]], labels[b, :, : ks[b]], torch.ones(26, dtype=torch.bool))
                p = torch.as_tensor(hungarian(c))
                loss = loss + c[p, torch.arange(int(ks[b]))].mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
    m.eval()
    with torch.no_grad():
        k_hat, _, _ = estimate_speaker_count(m(feats).exist_prob)
    assert k_hat.tolist() == ks.tolist()
