import math

import numpy as np
import pytest
import torch
import torch.nn.functional as F

from conftest import TINY, cuda
from src.audio.mel_features import LogMel
from src.models.asr import (CharTokenizer, CTCASR, ctc_collapse, ctc_loss, device_nbest, forced_align,
                            greedy_decode, prefix_beam_search)
from src.utils.device import autocast_ctx

TOK = CharTokenizer()


def _logp_for(path, V=29, conf=0.9):
    """Log-probs whose argmax path is `path` (list of ids)."""
    lp = np.full((len(path), V), math.log((1 - conf) / (V - 1)))
    for t, c in enumerate(path):
        lp[t, c] = math.log(conf)
    return lp


def test_tokenizer_roundtrip_and_normalization():
    assert TOK.decode(TOK.encode("Hello, World! it's")) == "hello world it's"
    assert TOK.vocab_size == 29 and TOK.encode("") == []


def test_ctc_collapse_and_frames():
    p = torch.tensor([[0, 5, 5, 0, 5, 7, 7, 0, 0]])
    tok, fr, n = ctc_collapse(p)
    assert n.tolist() == [3] and tok[0, :3].tolist() == [5, 5, 7] and fr[0, :3].tolist() == [1, 4, 5]


def test_greedy_and_device_nbest_contains_greedy():
    path = TOK.encode("go")
    lp = torch.tensor(_logp_for([0] + path + [0]), dtype=torch.float)[None]
    toks, _, n = greedy_decode(lp)
    assert TOK.decode(toks[0, : n[0]].tolist()) == "go"
    paths, scores, t2, _, n2 = device_nbest(lp, n_best=4, n_flip=2)
    assert paths.shape == (1, 4, lp.shape[1]) and torch.all(scores[0, :-1] >= scores[0, 1:])
    assert TOK.decode(t2[0, 0, : n2[0, 0]].tolist()) == "go"   # best alignment == greedy
    g1 = device_nbest(lp, 1, 0)
    assert TOK.decode(g1[2][0, 0, : g1[4][0, 0]].tolist()) == "go"


def test_prefix_beam_search_merges_alignments():
    # Frame-wise argmax gives "ab", but the summed probability of "a" (a a / a blank) is higher.
    lp = np.log(np.array([[0.0, 0.6, 0.4], [0.4, 0.3, 0.3]]) + 1e-12)
    hyps = prefix_beam_search(lp, beam=4, n_best=3)
    best = hyps[0]
    assert best[0] == (1,)
    # exact total for "a": paths aa, a_, _a  = .6*.3 + .6*.4 + 0*.3 = 0.42
    assert abs(math.exp(best[1]) - 0.42) < 1e-6


def test_forced_align_recovers_emission_frames():
    path = [0, 0, 7, 7, 0, 9, 0, 0, 7, 0]
    assert forced_align(_logp_for(path), [7, 9, 7]) == [2, 5, 8]


@pytest.fixture(scope="module")
def asr():
    torch.manual_seed(0)
    return CTCASR(**TINY["asr"]).eval()


def test_variable_length_batch_matches_individual(asr):
    lm = LogMel()
    a, b = torch.randn(8000) * 0.1, torch.randn(16000) * 0.1
    batch = torch.zeros(2, 16000)
    batch[0, :8000], batch[1] = a, b
    lens = torch.tensor([8000, 16000]) // 160 + 1
    with torch.no_grad():
        fb = lm(batch)
        lb, ol = asr(fb, lens)
        # same features for the short item (STFT edge padding differs between a padded batch and
        # an unpadded signal; that is a property of centred STFT, not of the model)
        la, _ = asr(fb[:1, :, : int(lens[0])])
    assert ol.tolist() == [la.shape[1], lb.shape[1]]
    assert torch.allclose(lb[0, : la.shape[1]], la[0], atol=1e-4)


def test_short_long_and_empty_inputs(asr):
    lm = LogMel()
    with torch.no_grad():
        assert asr(lm(torch.randn(1, 480)))[0].shape[1] >= 1           # 30 ms
        assert asr(lm(torch.randn(1, 16000 * 30) * 0.1))[0].shape[1] == 1501  # 30 s, 20 ms frames
    with pytest.raises(ValueError):
        lm(torch.zeros(1, 0))


def test_mixed_precision_cpu_bf16_and_fp16_guard(asr):
    x = LogMel()(torch.randn(1, 16000) * 0.1)
    with torch.no_grad():
        ref, _ = asr(x)
        with autocast_ctx(torch.device("cpu"), "bf16"):
            lo, _ = asr(x)
    assert lo.dtype == torch.bfloat16 and asr.head.weight.dtype == torch.float32  # FP32 master weights
    assert (F.softmax(lo.float(), -1) - F.softmax(ref, -1)).abs().max() < 0.05
    with pytest.raises(ValueError):
        autocast_ctx(torch.device("cpu"), "fp16")


def test_asr_overfits_two_utterances():
    """Learning check: tiny CTC model must transcribe its two training sequences exactly."""
    torch.manual_seed(0)
    lm = LogMel()
    t = torch.arange(16000) / 16000
    # "words" made of tone segments: each character is a 120 ms tone at a char-specific pitch
    def utt(text):
        segs = []
        for c in text:
            f = 300 + 90 * TOK.encode(c)[0]
            segs += [0.3 * torch.sin(2 * np.pi * f * t[:1920]), torch.zeros(800)]
        return torch.cat(segs)
    texts = ["abc", "cab"]
    wavs = [utt(s) for s in texts]
    N = max(len(w) for w in wavs)
    x = torch.stack([F.pad(w, (0, N - len(w))) for w in wavs])
    lens = torch.tensor([len(w) for w in wavs]) // 160 + 1
    tg = torch.tensor([TOK.encode(s) for s in texts])
    m = CTCASR(**TINY["asr"])
    opt = torch.optim.Adam(m.parameters(), 3e-3)
    feats = lm(x)
    for _ in range(250):
        lo, ol = m(feats, lens)
        loss = ctc_loss(lo, ol, tg, torch.tensor([3, 3]))
        opt.zero_grad()
        loss.backward()
        opt.step()
    m.eval()
    with torch.no_grad():
        tok, _, n = greedy_decode(*m(feats, lens))
    assert [TOK.decode(tok[i, : n[i]].tolist()) for i in range(2)] == texts


@cuda
def test_gpu_inference_matches_cpu(asr):
    x = LogMel()(torch.randn(1, 16000) * 0.1)
    with torch.no_grad():
        c, _ = asr(x)
        g, _ = asr.cuda()(x.cuda())
    assert torch.allclose(c, g.cpu(), atol=1e-3)
    asr.cpu()
