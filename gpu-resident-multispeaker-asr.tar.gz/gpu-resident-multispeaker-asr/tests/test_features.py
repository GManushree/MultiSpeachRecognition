import numpy as np
import pytest
import torch

from conftest import cuda
from src.audio.mel_features import LogMel, mel_filterbank, reference_log_mel

TOL = 1e-4  # log-domain absolute tolerance vs the float64 reference


@pytest.fixture(scope="module")
def signal():
    rng = np.random.RandomState(0)
    t = np.arange(24000) / 16000
    return (0.2 * np.sin(2 * np.pi * 220 * t) + 0.05 * rng.randn(len(t))).astype(np.float32)


def test_shape_and_frame_rate(signal):
    f = LogMel()(torch.from_numpy(signal))
    assert f.shape == (80, len(signal) // 160 + 1)


def test_matches_reference(signal):
    ref = reference_log_mel(signal)
    with torch.no_grad():
        out = LogMel()(torch.from_numpy(signal)).numpy()
    assert np.abs(out - ref).max() < TOL


def test_fused_kernel_matches_reference(signal):
    m = LogMel(use_fused_kernel=True)
    with torch.no_grad():
        out = m(torch.from_numpy(signal)).numpy()
    assert np.abs(out - reference_log_mel(signal)).max() < TOL


def test_batched_equals_individual(signal):
    m = LogMel()
    x = torch.from_numpy(np.stack([signal, signal[::-1].copy() * 0.5]))
    with torch.no_grad():
        b = m(x)
        assert torch.allclose(b[1], m(x[1]), atol=1e-5)
        assert m(x[None]).shape == (1, 2, 80, b.shape[-1])  # arbitrary leading dims


def test_filterbank_is_sparse_triangles():
    fb = mel_filterbank()
    assert fb.shape == (201, 80) and fb.min() >= 0 and fb.max() <= 1.0
    assert all((fb[:, m] > 0).sum() < 40 for m in range(80))  # justifies the sparse fused kernel


def test_differentiable_and_short_input(signal):
    x = torch.from_numpy(signal[:4000]).requires_grad_()
    LogMel()(x).sum().backward()
    assert torch.isfinite(x.grad).all() and x.grad.abs().sum() > 0
    with pytest.raises(ValueError):
        LogMel()(torch.zeros(100))


@cuda
def test_cuda_fused_kernel_matches_cpu(signal):
    m = LogMel(use_fused_kernel=True).cuda()
    with torch.no_grad():
        g = m(torch.from_numpy(signal).cuda()).cpu().numpy()
    assert np.abs(g - reference_log_mel(signal)).max() < TOL
