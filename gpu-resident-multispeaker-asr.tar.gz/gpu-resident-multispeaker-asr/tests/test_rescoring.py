import torch
import torch.nn.functional as F

from conftest import TINY, cuda
from src.models.rescoring import CharLSTMLM, RescoreConfig, Rescorer, ctc_log_likelihood, lm_loss


def _inputs(S=3, N=5, T=40, V=29, L=10, seed=0):
    g = torch.Generator().manual_seed(seed)
    lp = F.log_softmax(torch.randn(S, T, V, generator=g) * 3, -1)
    toks = torch.randint(1, V, (S, N, L), generator=g)
    lens = torch.randint(0, L + 1, (S, N), generator=g)
    toks = toks * (torch.arange(L) < lens[..., None])
    return lp, torch.full((S,), T), toks, lens


def test_device_ctc_matches_torch_ctc():
    lp, ol, toks, lens = _inputs()
    S, N, L = toks.shape
    lpm = lp[:, None].expand(S, N, *lp.shape[1:]).reshape(S * N, *lp.shape[1:])
    a = ctc_log_likelihood(lpm, ol.repeat_interleave(N), toks.reshape(-1, L), lens.reshape(-1))
    b = -F.ctc_loss(lpm.transpose(0, 1), toks.reshape(-1, L), ol.repeat_interleave(N), lens.reshape(-1),
                    reduction="none", zero_infinity=False)
    fin = torch.isfinite(b)
    assert torch.equal(fin, torch.isfinite(a)) and (a[fin] - b[fin]).abs().max() < 1e-3


def test_modes_agree_and_best_is_argmax():
    torch.manual_seed(0)
    lm = CharLSTMLM(**TINY["lm"]).eval()
    r = Rescorer(lm, RescoreConfig(w_ac=1.0, w_lm=0.5, w_len=0.1))
    inp = _inputs()
    b_ser, s_ser = r.rescore(*inp, mode="serial")
    b_bat, s_bat = r.rescore(*inp, mode="batched")
    b_str, _ = r.rescore(*inp, mode="streams")  # falls back to serial on CPU
    assert torch.equal(b_ser, b_bat) and torch.equal(b_ser, b_str) and torch.allclose(s_ser, s_bat, atol=1e-3)
    assert torch.equal(b_ser, s_ser.argmax(-1))


def test_weights_change_selection():
    """Hyp 0 is acoustically best; hyp 1 is what the LM was trained on. Raising w_lm flips the choice."""
    torch.manual_seed(0)
    V, T = 29, 12
    seq_lm, seq_ac = [5, 6, 7], [8, 9, 10]
    lp = torch.full((1, T, V), -8.0)
    for t in range(T):
        lp[0, t, 0] = -0.1
    for i, c in enumerate(seq_ac):
        lp[0, 2 + 3 * i, c] = -0.05
    for i, c in enumerate(seq_lm):
        lp[0, 2 + 3 * i, c] = -2.0
    lp = F.log_softmax(lp, -1)
    toks = torch.tensor([[seq_ac, seq_lm]])
    lens = torch.tensor([[3, 3]])
    lm = CharLSTMLM(**TINY["lm"])
    opt = torch.optim.Adam(lm.parameters(), 1e-2)
    x = torch.tensor([seq_lm] * 8)
    for _ in range(100):
        loss = lm_loss(lm, x, torch.full((8,), 3))
        opt.zero_grad()
        loss.backward()
        opt.step()
    lm.eval()
    ol = torch.tensor([T])
    assert Rescorer(lm, RescoreConfig(w_lm=0.0)).rescore(lp, ol, toks, lens)[0].item() == 0
    assert Rescorer(lm, RescoreConfig(w_lm=2.0)).rescore(lp, ol, toks, lens)[0].item() == 1


def test_lm_sequence_logprob_matches_manual():
    torch.manual_seed(0)
    lm = CharLSTMLM(**TINY["lm"]).eval()
    toks, lens = torch.tensor([[3, 4, 0]]), torch.tensor([2])
    with torch.no_grad():
        lp = F.log_softmax(lm(torch.tensor([[0, 3, 4]])), -1)[0]
        manual = lp[0, 3] + lp[1, 4] + lp[2, 0]
        assert torch.allclose(lm.sequence_logprob(toks, lens)[0], manual, atol=1e-5)


@cuda
def test_cuda_streams_match_serial():
    lm = CharLSTMLM(**TINY["lm"]).cuda().eval()
    r = Rescorer(lm, RescoreConfig(n_streams=3))
    inp = [t.cuda() for t in _inputs()]
    b1, s1 = r.rescore(*inp, mode="serial")
    b2, s2 = r.rescore(*inp, mode="streams")
    torch.cuda.synchronize()
    assert torch.equal(b1, b2) and torch.allclose(s1, s2, atol=1e-3)
