"""Custom extension, transfer instrumentation and CUDA-only checks (skipped without a GPU)."""
import numpy as np
import torch

from conftest import cuda
from src.audio.mel_features import LogMel
from src.cuda.build import extension_status, load_extension
from src.evaluation.transfer_profiler import (TransferTracker, analytical_rtf, analytical_transfer_time,
                                              estimate_l_sync, profile_memcpy)


def test_extension_builds_with_cpu_kernel():
    st = extension_status()
    assert st["built"] and st["cpu_kernel"]
    assert st["cuda_kernel"] == (torch.cuda.is_available() and load_extension().built_with_cuda())


def test_fused_kernel_input_validation():
    ext = load_extension()
    import pytest
    with pytest.raises(RuntimeError):
        ext.fused_log_mel(torch.zeros(1, 201, 5), torch.zeros(80, 201), torch.zeros(80, dtype=torch.int32),
                          torch.zeros(80, dtype=torch.int32), 1e-6)


def test_fused_equals_dense_on_random_spectra():
    m = LogMel()
    spec = torch.randn(3, 201, 17, 2)
    out = load_extension().fused_log_mel(spec, m.fb, m.band_lo, m.band_hi, 1e-6)
    dense = torch.log(m.fb @ (spec[..., 0] ** 2 + spec[..., 1] ** 2) + 1e-6)
    assert torch.allclose(out, dense, atol=1e-4)


def test_tracker_counts_and_bytes():
    tr = TransferTracker(torch.device("cpu"))
    t = tr.h2d(np.zeros(1000, np.float32), "a")
    tr.d2h(t[:10], "b")
    s = tr.summary()
    assert s["n_crossings"] == 2 and s["h2d_bytes"] == 4000 and s["d2h_bytes"] == 40
    assert profile_memcpy(lambda: None, torch.device("cpu")) is None


def test_analytical_model():
    assert abs(analytical_transfer_time([16000, 4000], 10.0, 1e-5) - (2e-5 + 2e-6)) < 1e-9
    assert abs(analytical_rtf(0.05, 2, 0.001, 0.5) - 0.104) < 1e-9
    assert estimate_l_sync(0.012, 0.010) == 0.001


@cuda
def test_cuda_resident_pipeline_memcpy_count(inf_cfg):
    """On a GPU, the profiler must see exactly one HtoD and one DtoH memcpy per block."""
    from conftest import TINY
    from src.inference.pipeline import build_pipeline
    from src.models.joint_model import JointModel
    p = build_pipeline(JointModel(TINY), None, inf_cfg, torch.device("cuda"))
    x = np.random.randn(16000).astype(np.float32) * 0.1
    p.process_block(x)
    counts = profile_memcpy(lambda: p.process_block(x), torch.device("cuda"))
    assert counts["HtoD"] == 1 and counts["DtoH"] == 1, counts


@cuda
def test_cuda_streams_overlap_executes():
    s = [torch.cuda.Stream() for _ in range(2)]
    a = torch.randn(512, 512, device="cuda")
    outs = []
    for st in s:
        with torch.cuda.stream(st):
            outs.append(a @ a)
    torch.cuda.synchronize()
    assert torch.allclose(outs[0], outs[1])
