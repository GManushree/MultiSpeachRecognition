import numpy as np
import pytest
import torch

from src.audio.loader import AudioError, load_audio
from src.inference.offline import OfflineTranscriber
from src.inference.pipeline import build_pipeline
from src.inference.streaming import StreamingTranscriber
from src.models.joint_model import JointModel
from src.models.rescoring import CharLSTMLM
from src.training.datasets import _abs, read_manifest


@pytest.fixture(scope="module")
def models():
    from conftest import TINY
    torch.manual_seed(0)
    m = JointModel(TINY).eval()
    with torch.no_grad():
        m.stdn.eda.exist.bias.fill_(4.0)   # untrained model: force capacity speakers "present" for plumbing
        m.asr.head.bias[0] = -2.0           # discourage all-blank output so text is produced
    return m, CharLSTMLM(**TINY["lm"]).eval()


@pytest.fixture(scope="module")
def audio(tiny_corpus):
    root, meta = tiny_corpus
    r = max(read_manifest(meta["manifests"]["test"]), key=lambda r: r["n_speakers"])
    return load_audio(_abs(r, r["mix_path"]))


def test_resident_pipeline_two_crossings(models, inf_cfg, audio):
    p = build_pipeline(*models, inf_cfg, torch.device("cpu"))
    res = p.process_block(audio)
    t = res.transfers
    assert t["n_crossings"] == 2 and t["labels"] == ["H2D:audio", "D2H:decoded packet"] and t["explicit_syncs"] == 0
    assert len(res.speakers) == 3 and res.activity.shape[1] == 3
    assert set(res.timings) >= {"features", "diarization", "separation", "asr", "rescoring", "total"}


def test_crossing_variants(models, inf_cfg, audio):
    dev = torch.device("cpu")
    n = {k: build_pipeline(*models, inf_cfg, dev, **ov).process_block(audio).transfers["n_crossings"]
         for k, ov in {"n4": {"n_crossings": 4}, "dyn": {"fixed_capacity": False}, "beam": {"decoder": "beam"},
                       "casc": {"mode": "cascaded"}}.items()}
    assert n["n4"] == 4 and n["dyn"] == 3 and n["beam"] == 4 and n["casc"] > 10


def test_resident_beam_equals_cascaded(models, inf_cfg, audio):
    """Same weights + same decoder => same transcripts; only the data movement differs."""
    dev = torch.device("cpu")
    a = build_pipeline(*models, inf_cfg, dev, decoder="beam", fixed_capacity=False).process_block(audio)
    b = build_pipeline(*models, inf_cfg, dev, mode="cascaded").process_block(audio)
    assert {k: v["text"] for k, v in a.speakers.items()} == {k: v["text"] for k, v in b.speakers.items()}


def test_controlled_four_crossing_same_output(models, inf_cfg, audio):
    dev = torch.device("cpu")
    a = build_pipeline(*models, inf_cfg, dev).process_block(audio)
    b = build_pipeline(*models, inf_cfg, dev, n_crossings=4).process_block(audio)
    assert {k: v["text"] for k, v in a.speakers.items()} == {k: v["text"] for k, v in b.speakers.items()}


def test_offline_transcript_structure(models, inf_cfg, audio):
    out = OfflineTranscriber(*models, inf_cfg, torch.device("cpu")).transcribe_array(audio)
    assert out["segments"], "plumbing model should emit text"
    for s in out["segments"]:
        assert s.speaker_id.startswith("SPEAKER_") and 0 <= s.start <= s.end <= out["duration_s"] + 1e-6 and s.text
    starts = [s.start for s in out["segments"]]
    assert starts == sorted(starts)
    with pytest.raises(AudioError):
        OfflineTranscriber(*models, inf_cfg, torch.device("cpu")).transcribe_array(np.zeros(0, np.float32))


def test_streaming_timestamps_consistent(models, inf_cfg, audio):
    p = build_pipeline(*models, inf_cfg, torch.device("cpu"))
    x = np.concatenate([audio, audio])  # long enough for several blocks
    st = StreamingTranscriber(p, block_s=1.0, left_context_s=1.0)
    out = st.run(x)
    assert len(out["blocks"]) == int(np.ceil(len(x) / 16000))
    assert all(b["n_crossings"] == 2 for b in out["blocks"])              # 2 crossings incl. speaker tracking
    ends = [b["end_s"] for b in out["blocks"]]
    assert ends == sorted(ends) and abs(ends[-1] - len(x) / 16000) < 1e-6
    for s in out["segments"]:
        assert 0 <= s.start <= s.end <= len(x) / 16000 + 1e-6
    by_spk = {}
    for s in out["segments"]:
        by_spk.setdefault(s.speaker_id, []).append(s)
    for segs in by_spk.values():                                       # no duplicated words per speaker
        ws = sorted((w.start, w.end) for s in segs for w in s.words)
        assert all(b[0] >= a[0] for a, b in zip(ws, ws[1:]))


def test_streaming_survives_malformed_block(models, inf_cfg, audio):
    p = build_pipeline(*models, inf_cfg, torch.device("cpu"))
    x = np.concatenate([audio, audio]).copy()
    x[20000:20100] = np.nan
    out = StreamingTranscriber(p, block_s=1.0, left_context_s=0.0).run(x)
    assert len(out["errors"]) == 1 and "NaN" in out["errors"][0]
    assert len(out["blocks"]) == int(np.ceil(len(x) / 16000)) - 1


def test_no_speech_input_gives_no_speakers(inf_cfg):
    from conftest import TINY
    m = JointModel(TINY).eval()
    with torch.no_grad():
        m.stdn.eda.exist.bias.fill_(-6.0)   # model that detects nobody
    res = build_pipeline(m, None, inf_cfg, torch.device("cpu")).process_block(np.zeros(16000, np.float32))
    assert res.speakers == {} and res.transfers["n_crossings"] == 2
