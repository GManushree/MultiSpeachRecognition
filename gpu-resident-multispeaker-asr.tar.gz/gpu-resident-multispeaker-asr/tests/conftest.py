import copy
import sys
from pathlib import Path

import numpy as np
import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.utils.config import load_config  # noqa: E402

torch.set_num_threads(1)
cuda = pytest.mark.skipif(not torch.cuda.is_available(), reason="requires a CUDA device")

TINY = {
    "features": {"sample_rate": 16000, "n_fft": 400, "hop": 160, "n_mels": 80, "use_fused_kernel": False},
    "stdn": {"n_mels": 80, "d_model": 32, "n_heads": 2, "n_layers": 1, "ff_dim": 64, "dropout": 0.0, "max_speakers": 3},
    "separator": {"enc_dim": 16, "kernel": 32, "stride": 16, "bottleneck": 16, "hidden": 32, "n_blocks": 2,
                  "n_repeats": 1, "cond_dim": 32},
    "asr": {"n_mels": 80, "d_model": 32, "n_heads": 2, "n_layers": 1, "ff_dim": 64, "conv_ch": 8, "dropout": 0.0,
            "vocab_size": 29},
    "lm": {"vocab_size": 29, "emb": 16, "hidden": 32, "layers": 1, "dropout": 0.0},
}


@pytest.fixture
def tiny_model_cfg():
    return copy.deepcopy(TINY)


@pytest.fixture
def inf_cfg():
    cfg = load_config(ROOT / "configs/inference.yaml")
    cfg["model"] = copy.deepcopy(TINY)
    return cfg


@pytest.fixture(scope="session")
def tiny_corpus(tmp_path_factory):
    from src.data.synthetic import generate_corpus
    root = tmp_path_factory.mktemp("corpus")
    cfg = {"seed": 3, "sample_rate": 16000, "n_speakers": 18, "n_mixtures": {"train": 6, "val": 3, "test": 3},
           "k_probs": {0: 0.15, 1: 0.25, 2: 0.4, 3: 0.2}, "overlap_range": [0.1, 0.5], "gain_db": 3.0,
           "noise_snr_db": 30.0, "ablation_sets": [{"k": 2, "overlap": 0.5, "n": 2}]}
    meta = generate_corpus(cfg, root)
    return root, meta


def sine(f, dur=1.0, sr=16000, amp=0.3):
    t = np.arange(int(dur * sr)) / sr
    return (amp * np.sin(2 * np.pi * f * t)).astype(np.float32)
