import numpy as np
import pytest

from src.evaluation.der import der_pyannote, frame_der
from src.evaluation.wer import cer, corpus_wer, speaker_attributed_wer, wer


def test_wer_counts_known_case():
    c = wer("a b c d", "a x c d e")
    assert (c.sub, c.dele, c.ins, c.n_ref) == (1, 0, 1, 4) and c.rate == 0.5
    c = wer("a b c d", "a c d")
    assert (c.sub, c.dele, c.ins) == (0, 1, 0) and c.rate == 0.25
    c = wer("the cat sat on the mat", "the cat sit on mat today")
    assert c.errors == 3 and c.n_ref == 6  # several optimal alignments; the total is unique


def test_wer_edge_cases_and_cer():
    assert wer("", "").rate == 0.0 and wer("", "x").rate == float("inf")
    assert wer("a b", "").rate == 1.0
    assert cer("abc", "abd").rate == pytest.approx(1 / 3)


def test_wer_matches_jiwer():
    jiwer = pytest.importorskip("jiwer")
    pairs = [("we need more time", "we need time"), ("let me check that", "let me check the cat"),
             ("good point", "good point")]
    ours = corpus_wer(pairs).rate
    assert ours == pytest.approx(jiwer.wer([r for r, _ in pairs], [h for _, h in pairs]))


def test_cpwer_finds_speaker_mapping_and_counts_extra():
    ref = {"A": "hello there", "B": "good morning"}
    hyp = {"S1": "good morning", "S0": "hello there", "S2": "noise"}
    c, mapping = speaker_attributed_wer(ref, hyp)
    assert mapping == {"A": "S0", "B": "S1"} and c.ins == 1 and c.n_ref == 4 and c.rate == 0.25


def test_der_known_cases():
    ref = [(0, 10, "a"), (10, 20, "b")]
    assert der_pyannote(ref, [(0, 10, "x"), (10, 20, "y")], 20, collar=0) == pytest.approx(0.0)
    assert der_pyannote(ref, [(0, 10, "x")], 20, collar=0) == pytest.approx(0.5)            # missed
    assert der_pyannote(ref, [(0, 20, "x")], 20, collar=0) == pytest.approx(0.5)            # confusion
    # collar convention: per side. 0.25 s on each side of boundary 10 s excludes 0.5 s total.
    assert der_pyannote(ref, [(0, 10.25, "x"), (10.25, 20, "y")], 20, collar=0.25) == pytest.approx(0.0)
    assert der_pyannote(ref, [(0, 10.25, "x"), (10.25, 20, "y")], 20, collar=0.0) > 0


def test_der_overlap_scored():
    ref = [(0, 10, "a"), (5, 10, "b")]
    assert der_pyannote(ref, [(0, 10, "x")], 10, collar=0) == pytest.approx(5 / 15)


def test_frame_der_agrees_with_pyannote():
    rng = np.random.RandomState(0)
    ref = (rng.rand(500, 2) > 0.5).astype(float)
    hyp = ref[:, ::-1].copy()            # speakers swapped (mapping must undo this)
    flip = rng.rand(500) < 0.1
    hyp[flip, 0] = 1 - hyp[flip, 0]       # 10% frame errors on one speaker
    hyp[:50, 1] = 0                       # missed speech

    def segs(act, names):
        out = []
        for k, n in enumerate(names):
            on = np.append(act[:, k] > 0.5, False)
            s = None
            for t, v in enumerate(on):
                if v and s is None:
                    s = t
                elif not v and s is not None:
                    out.append((s * 0.04, t * 0.04, n))
                    s = None
        return out

    d, _ = frame_der(ref, hyp)
    p = der_pyannote(segs(ref, "ab"), segs(hyp, "xy"), 20.0, collar=0)
    assert d == pytest.approx(p, abs=1e-6)
