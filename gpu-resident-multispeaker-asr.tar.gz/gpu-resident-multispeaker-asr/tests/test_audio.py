import numpy as np
import pytest
import soundfile as sf

from conftest import sine
from src.audio.loader import AudioError, load_audio, load_bytes, resample, save_audio
from src.audio.preprocessing import iter_blocks, peak_normalize


def _dominant_hz(x, sr):
    spec = np.abs(np.fft.rfft(x))
    return np.argmax(spec) * sr / len(x)


def test_resample_preserves_frequency_and_length():
    x = sine(440, 1.0, 22050)
    y = resample(x, 22050, 16000)
    assert len(y) == 16000
    assert abs(_dominant_hz(y, 16000) - 440) < 2


def test_load_multichannel_mean_and_channel(tmp_path):
    a, b = sine(300, 0.5, 16000), sine(700, 0.5, 16000)
    p = tmp_path / "st.wav"
    sf.write(p, np.stack([a, b], 1), 16000, subtype="FLOAT")
    mono = load_audio(p)
    np.testing.assert_allclose(mono, (a + b) / 2, atol=1e-6)
    ch1 = load_audio(p, channel=1)
    np.testing.assert_allclose(ch1, b, atol=1e-6)
    with pytest.raises(AudioError):
        load_audio(p, channel=5)


def test_load_resamples_from_file(tmp_path):
    p = tmp_path / "a.wav"
    save_audio(p, sine(1000, 0.5, 8000), 8000)
    x = load_audio(p, 16000)
    assert len(x) == 8000 and abs(_dominant_hz(x, 16000) - 1000) < 4


def test_malformed_and_empty_inputs(tmp_path):
    bad = tmp_path / "bad.wav"
    bad.write_bytes(b"not a wav at all")
    with pytest.raises(AudioError):
        load_audio(bad)
    with pytest.raises(AudioError):
        load_bytes(b"\x00\x01garbage")
    empty = tmp_path / "empty.wav"
    sf.write(empty, np.zeros(0, np.float32), 16000)
    with pytest.raises(AudioError):
        load_audio(empty)


def test_blocks_cover_signal_with_context():
    x = np.arange(16000 * 3 + 500, dtype=np.float32)
    blocks = list(iter_blocks(x, 16000, 1.0, left_context_s=0.5))
    assert [b.start_sample for b in blocks] == [0, 16000, 32000, 48000]
    assert blocks[-1].end_sample == len(x)
    b1 = blocks[1]
    assert b1.ctx_start == 8000 and b1.audio[0] == 8000 and len(b1.audio) == 24000
    assert len(blocks[-1].audio) == 16000 + 8000  # padded to full block + context
    assert peak_normalize(np.zeros(5, np.float32)).max() == 0
