import json

import numpy as np
import soundfile as sf

from src.data.synthetic import overlap_ratio, vad_segments
from src.training.datasets import (MixtureDataset, SourceUtteranceDataset, activity_labels, collate_mixtures,
                                   manifest_stats, read_manifest, validate_manifest)


def test_corpus_valid_and_speaker_disjoint(tiny_corpus):
    root, meta = tiny_corpus
    spk = {}
    for split in ("train", "val", "test"):
        rows = read_manifest(meta["manifests"][split])
        assert validate_manifest(rows)["ok"]
        spk[split] = {s["speaker_id"] for r in rows for s in r["speakers"]}
        assert manifest_stats(rows)["mixtures"] == len(rows)
    assert not (spk["train"] & spk["val"]) and not (spk["train"] & spk["test"]) and not (spk["val"] & spk["test"])


def test_generation_is_reproducible(tiny_corpus, tmp_path):
    from src.data.synthetic import generate_corpus
    root, meta = tiny_corpus
    cfg = dict(meta["config"])
    cfg["n_mixtures"] = {"train": 2, "val": 1, "test": 1}
    cfg["ablation_sets"] = []
    a = read_manifest(generate_corpus(cfg, tmp_path / "a")["manifests"]["train"])
    b = read_manifest(generate_corpus(cfg, tmp_path / "b")["manifests"]["train"])
    strip = lambda rows: [{k: v for k, v in r.items() if k != "_root"} for r in rows]  # noqa: E731
    assert strip(a) == strip(b)


def test_mixture_equals_sum_of_sources(tiny_corpus):
    root, meta = tiny_corpus
    ds = MixtureDataset(meta["manifests"]["train"], 3)
    for i in range(len(ds)):
        it = ds[i]
        resid = it["mix"] - it["sources"].sum(0)
        # residual is only the added white noise (30 dB below the signal) + 16-bit quantisation
        if it["n_spk"]:
            assert 10 * np.log10(np.mean(it["mix"] ** 2) / np.mean(resid ** 2)) > 25


def test_activity_labels_follow_segments():
    row = {"speakers": [{"segments": [[0.0, 0.4]]}, {"segments": [[0.2, 0.8]]}]}
    lab = activity_labels(row, 25, 3)
    assert lab[:10, 0].all() and not lab[10:, 0].any()
    assert lab[5:20, 1].all() and not lab[:5, 1].any() and not lab[:, 2].any()
    assert (lab.sum(1) == 2).any()   # overlapping frames carry two active speakers


def test_vad_and_overlap_ratio():
    x = np.zeros(16000, np.float32)
    x[4000:8000] = 0.3 * np.sin(np.arange(4000) * 0.3)
    assert vad_segments(x, 16000) == [[0.25, 0.5]]
    spk = [{"segments": [[0.0, 1.0]]}, {"segments": [[0.5, 1.5]]}]
    assert abs(overlap_ratio(spk) - 1 / 3) < 0.01


def test_missing_file_and_bad_annotation_detection(tiny_corpus, tmp_path):
    root, meta = tiny_corpus
    rows = read_manifest(meta["manifests"]["train"])
    rows[0] = dict(rows[0], mix_path="does/not/exist.wav")
    rows[1] = json.loads(json.dumps(rows[1]))
    if rows[1]["speakers"]:
        rows[1]["speakers"][0]["segments"] = [[5.0, 1.0]]
    rep = validate_manifest(rows)
    assert not rep["ok"] and rep["missing_files"]


def test_collate_and_source_dataset(tiny_corpus):
    root, meta = tiny_corpus
    ds = MixtureDataset(meta["manifests"]["train"], 3)
    b = collate_mixtures([ds[0], ds[1]])
    assert b["mix"].shape[0] == 2 and b["sources"].shape[1] == 3 and b["targets"].dtype.is_floating_point is False
    src = SourceUtteranceDataset(meta["manifests"]["train"])
    it = src[0]
    assert it["wav"].ndim == 1 and len(it["target"]) == len(it["text"])


def test_ami_adapter_on_fixture(tmp_path):
    from src.data.ami import build_ami_manifest, parse_words_xml
    root = tmp_path / "ami"
    (root / "annotations" / "words").mkdir(parents=True)
    (root / "amicorpus" / "ES2002a" / "audio").mkdir(parents=True)
    sf.write(root / "amicorpus/ES2002a/audio/ES2002a.Mix-Headset.wav", np.zeros(16000 * 10, np.float32), 16000)
    for spk, words in (("A", [(0.5, 0.9, "hello"), (1.0, 1.4, "there")]), ("B", [(1.2, 1.6, "hi"), (9.5, 9.9, "bye")])):
        xml = "<nite:root xmlns:nite='http://nite.sourceforge.net/'>" + "".join(
            f"<w starttime='{s}' endtime='{e}'>{w}</w>" for s, e, w in words) + "<w starttime='2' endtime='2' punc='true'>.</w></nite:root>"
        (root / "annotations/words" / f"ES2002a.{spk}.words.xml").write_text(xml)
    assert parse_words_xml(root / "annotations/words/ES2002a.A.words.xml")[0][2] == "hello"
    out = build_ami_manifest(root, tmp_path / "out", window_s=8.0)
    rows = read_manifest(out["manifests"]["train"])
    assert rows[0]["n_speakers"] == 2 and rows[0]["speakers"][0]["text"] == "hello there"
    assert any(s["text"] == "" for r in rows for s in r["speakers"]) or len(rows) == 2


def test_chime7_adapter_on_fixture(tmp_path):
    from src.data.chime7 import build_chime7_manifest
    root = tmp_path / "c7"
    (root / "chime6/transcriptions/dev").mkdir(parents=True)
    (root / "chime6/audio/dev").mkdir(parents=True)
    sf.write(root / "chime6/audio/dev/S02_U01.CH1.wav", np.zeros(16000 * 9, np.float32), 16000)
    utts = [{"session_id": "S02", "speaker": "P05", "start_time": "0:00:01.00", "end_time": "0:00:02.50", "words": "Hi there."},
            {"session_id": "S02", "speaker": "P06", "start_time": 2.0, "end_time": 3.0, "words": "hello"}]
    (root / "chime6/transcriptions/dev/S02.json").write_text(json.dumps(utts))
    out = build_chime7_manifest(root, tmp_path / "out", "chime6", "dev")
    rows = read_manifest(out["manifest"])
    assert rows[0]["n_speakers"] == 2 and rows[0]["speakers"][0]["text"] == "hi there"
    assert rows[0]["speakers"][0]["segments"] == [[1.0, 2.5]]
