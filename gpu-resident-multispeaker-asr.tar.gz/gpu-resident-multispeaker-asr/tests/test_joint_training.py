import copy

import pytest
import torch
from torch.utils.data import DataLoader

from src.models.joint_model import JointModel
from src.training.checkpoints import load_checkpoint, save_checkpoint
from src.training.datasets import MixtureDataset, collate_mixtures

USE_ALL = {"diar": True, "sep": True, "asr": True}
W = {"lambda_sep": 1.0, "lambda_diar": 1.0, "lambda_asr": 1.0, "assign_diar": 1.0, "assign_sep": 0.05}


@pytest.fixture(scope="module")
def batch(tiny_corpus):
    root, meta = tiny_corpus
    ds = MixtureDataset(meta["manifests"]["train"], 3)
    b = collate_mixtures([ds[i] for i in range(len(ds))])
    assert (b["n_spk"] == 0).any() and (b["n_spk"] >= 2).any()  # covers no-speech + multi-speaker
    return b


def _grads(model):
    return {n: any(p.grad is not None and p.grad.abs().sum() > 0 for p in getattr(model, n).parameters())
            for n in ("stdn", "separator", "asr")}


def test_joint_losses_finite_and_gradients_reach_all(tiny_model_cfg, batch):
    torch.manual_seed(0)
    m = JointModel(tiny_model_cfg)
    loss, log = m.compute_losses(batch, USE_ALL, W)
    assert torch.isfinite(loss) and all(k in log for k in ("l_diar", "l_sep", "l_asr", "total"))
    assert abs(log["total"] - (log["l_sep"] + log["l_diar"] + log["l_asr"])) < 1e-3   # L_total formula
    loss.backward()
    assert _grads(m) == {"stdn": True, "separator": True, "asr": True}


def test_asr_loss_alone_reaches_upstream_modules(tiny_model_cfg, batch):
    """Joint coupling: L_asr alone must produce gradients in the separator and the STDN."""
    torch.manual_seed(0)
    m = JointModel(tiny_model_cfg)
    loss, _ = m.compute_losses(batch, {"asr": True}, W)
    loss.backward()
    assert _grads(m) == {"stdn": True, "separator": True, "asr": True}


def test_frozen_modules_receive_no_gradient(tiny_model_cfg, batch):
    m = JointModel(tiny_model_cfg)
    m.freeze(["stdn", "asr"])
    m.train()
    assert not m.stdn.training and m.separator.training
    loss, _ = m.compute_losses(batch, {"sep": True}, W)
    loss.backward()
    assert _grads(m) == {"stdn": False, "separator": True, "asr": False}


def test_loss_invariant_to_reference_speaker_order(tiny_model_cfg, batch):
    torch.manual_seed(0)
    m = JointModel(tiny_model_cfg).eval()
    b2 = copy.deepcopy(batch)
    for i in range(len(b2["n_spk"])):
        k = int(b2["n_spk"][i])
        if k >= 2:
            p = torch.arange(k).flip(0)
            for key in ("sources", "targets", "target_len"):
                b2[key][i, :k] = b2[key][i, p]
            b2["act_labels"][i, :, :k] = b2["act_labels"][i, :, p]
    with torch.no_grad():
        _, l1 = m.compute_losses(batch, USE_ALL, W)
        _, l2 = m.compute_losses(b2, USE_ALL, W)
    for k in ("l_act", "l_sep", "l_asr"):
        assert abs(l1[k] - l2[k]) < 1e-3, k


def test_nonfinite_guard(tiny_model_cfg, batch):
    m = JointModel(tiny_model_cfg)
    b = copy.deepcopy(batch)
    i = int(torch.nonzero(b["n_spk"] > 0)[0])
    b["sources"][i] = float("nan")
    loss, log = m.compute_losses(b, USE_ALL, W)
    assert torch.isfinite(loss) and any(k.startswith("nonfinite") for k in log)


def test_checkpoint_roundtrip_and_missing(tiny_model_cfg, batch, tmp_path):
    torch.manual_seed(0)
    m = JointModel(tiny_model_cfg).eval()
    opt = torch.optim.AdamW(m.parameters())
    save_checkpoint(tmp_path / "c.pt", m, 7, {"model": tiny_model_cfg}, "joint", opt)
    m2 = JointModel(tiny_model_cfg).eval()
    st = load_checkpoint(tmp_path / "c.pt", m2, torch.optim.AdamW(m2.parameters()))
    assert st["step"] == 7 and st["stage"] == "joint"
    x = batch["mix"][:1]
    with torch.no_grad():
        assert torch.equal(m.stdn(m.features(x)).activity_logits, m2.stdn(m2.features(x)).activity_logits)
    with pytest.raises(FileNotFoundError):
        load_checkpoint(tmp_path / "missing.pt", m2)


def test_training_step_reduces_joint_loss(tiny_model_cfg, batch):
    torch.manual_seed(0)
    m = JointModel(tiny_model_cfg)
    opt = torch.optim.Adam(m.parameters(), 2e-3)
    first = None
    for _ in range(25):
        loss, log = m.compute_losses(batch, USE_ALL, W)
        first = first or log["total"]
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
        opt.step()
    assert log["total"] < first
