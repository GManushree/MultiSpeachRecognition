"""Word error rate: WER = (S + D + I) / N via Levenshtein alignment with backtrace."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ErrorCounts:
    sub: int = 0
    dele: int = 0
    ins: int = 0
    n_ref: int = 0
    per_item: dict = field(default_factory=dict)

    @property
    def errors(self):
        return self.sub + self.dele + self.ins

    @property
    def rate(self) -> float:
        return self.errors / self.n_ref if self.n_ref else (0.0 if self.errors == 0 else float("inf"))

    def add(self, other: "ErrorCounts", key=None):
        self.sub += other.sub
        self.dele += other.dele
        self.ins += other.ins
        self.n_ref += other.n_ref
        if key is not None:
            self.per_item[key] = other.rate

    def as_dict(self):
        return {"rate": self.rate, "S": self.sub, "D": self.dele, "I": self.ins, "N": self.n_ref}


def align_counts(ref: list, hyp: list) -> ErrorCounts:
    R, H = len(ref), len(hyp)
    d = [[0] * (H + 1) for _ in range(R + 1)]
    for i in range(R + 1):
        d[i][0] = i
    for j in range(H + 1):
        d[0][j] = j
    for i in range(1, R + 1):
        for j in range(1, H + 1):
            d[i][j] = min(d[i - 1][j - 1] + (ref[i - 1] != hyp[j - 1]), d[i - 1][j] + 1, d[i][j - 1] + 1)
    c = ErrorCounts(n_ref=R)
    i, j = R, H
    while i > 0 or j > 0:
        if i > 0 and j > 0 and d[i][j] == d[i - 1][j - 1] + (ref[i - 1] != hyp[j - 1]):
            c.sub += ref[i - 1] != hyp[j - 1]
            i, j = i - 1, j - 1
        elif i > 0 and d[i][j] == d[i - 1][j] + 1:
            c.dele += 1
            i -= 1
        else:
            c.ins += 1
            j -= 1
    return c


def wer(ref: str, hyp: str) -> ErrorCounts:
    return align_counts(ref.split(), hyp.split())


def cer(ref: str, hyp: str) -> ErrorCounts:
    return align_counts(list(ref), list(hyp))


def corpus_wer(pairs: list[tuple[str, str]], keys: list | None = None) -> ErrorCounts:
    tot = ErrorCounts()
    for n, (r, h) in enumerate(pairs):
        tot.add(wer(r, h), keys[n] if keys else n)
    return tot


def speaker_attributed_wer(ref_by_spk: dict[str, str], hyp_by_spk: dict[str, str]) -> tuple[ErrorCounts, dict]:
    """Concatenated minimum-permutation WER (cpWER, as in CHiME-6): concatenate each speaker's
    words, find the reference/hypothesis speaker mapping minimising total errors (Hungarian on
    pairwise error counts), unmatched speakers count as all-deletions / all-insertions."""
    import numpy as np
    from scipy.optimize import linear_sum_assignment
    refs, hyps = list(ref_by_spk), list(hyp_by_spk)
    n = max(len(refs), len(hyps))
    cost = np.zeros((n, n))
    cache = {}
    for i in range(n):
        for j in range(n):
            r = ref_by_spk[refs[i]] if i < len(refs) else ""
            h = hyp_by_spk[hyps[j]] if j < len(hyps) else ""
            cache[i, j] = wer(r, h)
            cache[i, j].n_ref = len(r.split())
            cost[i, j] = cache[i, j].errors
    rows, cols = linear_sum_assignment(cost)
    tot = ErrorCounts()
    mapping = {}
    for i, j in zip(rows, cols):
        tot.add(cache[i, j])
        if i < len(refs) and j < len(hyps):
            mapping[refs[i]] = hyps[j]
    return tot, mapping
