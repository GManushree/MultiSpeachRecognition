"""Diarization error rate.

`der_pyannote` is the reported metric: pyannote.metrics' DiarizationErrorRate (an
established, md-eval-compatible implementation). Conventions used throughout:
  * `collar` is per boundary side in seconds (md-eval/NIST convention, e.g. 0.25). pyannote's
    `collar` argument is the *total* width, so 2 * collar is passed.
  * Overlapped speech is scored (skip_overlap=False) unless configured otherwise.
  * Speaker mapping: optimal one-to-one (Hungarian), done inside pyannote.
`frame_der` is a fast frame-level approximation used only for validation during training;
with collar 0 it agrees with pyannote up to frame quantisation (tested)."""
from __future__ import annotations

import numpy as np
from scipy.optimize import linear_sum_assignment


def to_annotation(segments: list[tuple[float, float, str]], uri: str = "rec"):
    from pyannote.core import Annotation, Segment
    ann = Annotation(uri=uri)
    for i, (s, e, spk) in enumerate(segments):
        if e > s:
            ann[Segment(float(s), float(e)), f"t{i}"] = spk
    return ann


class DERAccumulator:
    def __init__(self, collar: float = 0.25, skip_overlap: bool = False):
        from pyannote.metrics.diarization import DiarizationErrorRate
        self.collar = collar
        self.metric = DiarizationErrorRate(collar=2 * collar, skip_overlap=skip_overlap)

    def add(self, ref, hyp, uri: str, duration: float | None = None):
        from pyannote.core import Segment, Timeline
        uem = Timeline([Segment(0, duration)], uri=uri) if duration else None
        return self.metric(to_annotation(ref, uri), to_annotation(hyp, uri), uem=uem, detailed=True)

    def report(self) -> dict:
        comp = {k: float(v) for k, v in self.metric[:].items()} if hasattr(self.metric, "__getitem__") else {}
        total = comp.get("total", 0.0)
        out = {"der": float(abs(self.metric)), "collar_per_side_s": self.collar}
        if total:
            out.update(missed=comp.get("missed detection", 0) / total,
                       false_alarm=comp.get("false alarm", 0) / total,
                       confusion=comp.get("confusion", 0) / total, scored_speech_s=total)
        return out


def der_pyannote(ref, hyp, duration=None, collar: float = 0.25, skip_overlap: bool = False) -> float:
    acc = DERAccumulator(collar, skip_overlap)
    acc.add(ref, hyp, "rec", duration)
    return acc.report()["der"]


def frame_der(ref: np.ndarray, hyp: np.ndarray) -> tuple[float, dict]:
    """ref (T, Kr), hyp (T, Kh) binary activity -> (DER, components) with optimal mapping."""
    T = ref.shape[0]
    Kr, Kh = ref.shape[1], hyp.shape[1]
    K = max(Kr, Kh, 1)
    r = np.zeros((T, K), bool)
    h = np.zeros((T, K), bool)
    r[:, :Kr], h[:, :Kh] = ref > 0.5, hyp > 0.5
    n_ref, n_hyp = r.sum(1), h.sum(1)
    if K:
        match = (r[:, :, None] & h[:, None, :]).sum(0)
        rows, cols = linear_sum_assignment(-match)
        correct = np.zeros(T)
        for i, j in zip(rows, cols):
            correct += r[:, i] & h[:, j]
    else:
        correct = np.zeros(T)
    miss = np.maximum(0, n_ref - n_hyp).sum()
    fa = np.maximum(0, n_hyp - n_ref).sum()
    conf = (np.minimum(n_ref, n_hyp) - correct).sum()
    total = n_ref.sum()
    der = (miss + fa + conf) / total if total else float(fa > 0)
    return float(der), {"miss": float(miss), "fa": float(fa), "conf": float(conf), "speech_frames": float(total)}
