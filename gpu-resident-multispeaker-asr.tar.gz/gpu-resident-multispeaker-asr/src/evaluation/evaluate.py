"""System evaluation on a manifest: recognition, diarization, separation, latency.

Recognition metric: cpWER (concatenated minimum-permutation WER, CHiME-6 style) - each
reference speaker's words vs each hypothesis speaker's words under the best mapping; extra
or missing speakers count fully as insertions/deletions. Also reported: oracle-source WER
(ASR on the clean reference sources, isolating recognizer quality from separation).
Diarization: DER via pyannote.metrics (collar per side from config, overlap scored).
Separation: SI-SDRi of the estimated streams, using the *estimated* speaker count; missed
references are counted separately (no fabricated scores)."""
from __future__ import annotations

import numpy as np
import torch

from src.audio.loader import load_audio
from src.evaluation.der import DERAccumulator
from src.evaluation.separation_metrics import pit_si_sdr
from src.evaluation.wer import ErrorCounts, corpus_wer, speaker_attributed_wer
from src.inference.offline import OfflineTranscriber
from src.models.asr import CharTokenizer, greedy_decode
from src.models.joint_model import rms_normalize
from src.models.stdn import estimate_speaker_count
from src.training.datasets import _abs, read_manifest

TOK = CharTokenizer()


def _sources(row, n):
    srcs = np.zeros((len(row["speakers"]), n), np.float32)
    for j, s in enumerate(row["speakers"]):
        x = load_audio(_abs(row, s["path"]))
        o = int(round(s["offset"] * 16000))
        srcs[j, o:o + len(x)] = x[: max(0, n - o)]
    return srcs


@torch.no_grad()
def separation_eval(model, mix: np.ndarray, srcs: np.ndarray, device) -> dict:
    x = torch.from_numpy(mix).to(device)[None]
    diar = model.stdn(model.features(x))
    S = model.max_speakers
    _, present, _ = estimate_speaker_count(diar.exist_prob[:, :S])
    sel = torch.nonzero(present[0]).flatten()
    est = model.separator(x, diar.attractors[:, sel], diar.activity_prob[:, :, sel])[0] if len(sel) else x.new_zeros(0, x.shape[1])
    return pit_si_sdr(est.float().cpu(), torch.from_numpy(srcs), torch.from_numpy(mix))


@torch.no_grad()
def oracle_source_pairs(model, row, device) -> list[tuple[str, str]]:
    pairs = []
    for s in row["speakers"]:
        x = torch.from_numpy(load_audio(_abs(row, s["path"]))).to(device)[None]
        logits, _ = model.asr(model.features(rms_normalize(x)))
        t, _, n = greedy_decode(logits)
        pairs.append((TOK.normalize(s["text"]), TOK.decode(t[0, : n[0]].tolist())))
    return pairs


def evaluate_manifest(model, lm, cfg: dict, device, manifest: str, precision="fp32", max_items=None,
                      with_separation=True, with_oracle=True, pipeline_overrides: dict | None = None,
                      collar: float = 0.25, keep_items: bool = False) -> dict:
    rows = read_manifest(manifest)[: max_items or None]
    tr = OfflineTranscriber(model, lm, cfg, device, precision, **(pipeline_overrides or {}))
    der = DERAccumulator(collar=collar, skip_overlap=False)
    cp, oracle = ErrorCounts(), []
    count_ok, k_err, sdri, sdr, missed, n_ref_spk = [], [], [], [], 0, 0
    sdri_by_k: dict = {}
    lat, rtf, crossings, items = [], [], [], []
    for r in rows:
        mix = load_audio(_abs(r, r["mix_path"]))
        out = tr.transcribe_array(mix)
        hyp_spk: dict = {}
        for s in out["segments"]:
            hyp_spk[s.speaker_id] = (hyp_spk.get(s.speaker_id, "") + " " + s.text).strip()
        ref_spk = {s["speaker_id"]: TOK.normalize(s["text"]) for s in r["speakers"]}
        c, _ = speaker_attributed_wer(ref_spk, hyp_spk)
        cp.add(c, r["id"])
        ref_seg = [(a, b, s["speaker_id"]) for s in r["speakers"] for a, b in s["segments"]]
        der.add(ref_seg, out["diarization"], r["id"], r["duration"])
        k_hat = len(out.get("speakers", {}))
        count_ok.append(k_hat == r["n_speakers"])
        k_err.append(k_hat - r["n_speakers"])
        lat.append(out["timings"]["total"] if "timings" in out else out["processing_s"])
        rtf.append(out["rtf"])
        crossings.append(out.get("transfers", {}).get("n_crossings"))
        if with_separation and r["n_speakers"]:
            srcs = _sources(r, len(mix))
            res = separation_eval(model, mix, srcs, device)
            sdri += res.get("si_sdri", [])
            sdri_by_k.setdefault(r["n_speakers"], []).extend(res.get("si_sdri", []))
            sdr += res["si_sdr"]
            missed += res["missed"]
            n_ref_spk += r["n_speakers"]
        if with_oracle and r["n_speakers"]:
            oracle += oracle_source_pairs(model, r, device)
        if keep_items:
            items.append({"id": r["id"], "ref": ref_spk, "hyp": hyp_spk, "cpwer": c.rate,
                          "k": r["n_speakers"], "k_hat": k_hat})
    rep = der.report()
    out = {"manifest": manifest, "n_items": len(rows), "cpwer": cp.as_dict(),
           "der": rep, "speaker_count_accuracy": float(np.mean(count_ok)),
           "speaker_count_mean_error": float(np.mean(k_err)),
           "latency_s": {"mean": float(np.mean(lat)), "median": float(np.median(lat)), "p95": float(np.percentile(lat, 95))},
           "rtf_mean": float(np.mean(rtf)), "crossings_per_item": crossings[0] if crossings else None,
           "precision": precision, "pipeline": {**cfg["pipeline"], **(pipeline_overrides or {})}}
    if with_separation and n_ref_spk:
        out["separation"] = {"si_sdri_mean_db": float(np.mean(sdri)) if sdri else None,
                             "si_sdr_mean_db": float(np.mean(sdr)) if sdr else None,
                             "matched_refs": len(sdr), "missed_refs": missed, "total_refs": n_ref_spk,
                             "si_sdri_by_k_db": {int(k): float(np.mean(v)) for k, v in sorted(sdri_by_k.items()) if v},
                             "si_sdri_multispeaker_db": float(np.mean([x for k, v in sdri_by_k.items() if k > 1 for x in v]))
                             if any(k > 1 and v for k, v in sdri_by_k.items()) else None}
    if with_oracle and oracle:
        out["oracle_source_wer"] = corpus_wer(oracle).as_dict()
    if keep_items:
        out["items"] = items
    return out
