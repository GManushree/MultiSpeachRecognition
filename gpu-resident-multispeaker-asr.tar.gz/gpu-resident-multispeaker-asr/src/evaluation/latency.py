"""Latency benchmarks: per-block end-to-end and per-module latency, RTF, crossing costs.

Every function returns *measured* values only. Analytical predictions live in
transfer_profiler.analytical_* and are labelled as such wherever they are reported."""
from __future__ import annotations

import time

import numpy as np
import torch

from src.audio.loader import load_audio
from src.training.datasets import _abs, read_manifest
from src.utils.device import sync


def collect_blocks(manifest: str, block_s: float, n_items: int, sr: int = 16000, seed: int = 0) -> list[np.ndarray]:
    """Cut `block_s` windows from test mixtures (speech-containing items first)."""
    rows = [r for r in read_manifest(manifest) if r["n_speakers"] > 0][:n_items]
    B = int(round(block_s * sr))
    rng = np.random.RandomState(seed)
    out = []
    for r in rows:
        x = load_audio(_abs(r, r["mix_path"]))
        if len(x) < B:
            x = np.pad(x, (0, B - len(x)))
        s = rng.randint(0, len(x) - B + 1)
        out.append(x[s:s + B].copy())
    return out


def _pct(v):
    v = np.asarray(v, dtype=np.float64)
    return {"mean": float(v.mean()), "median": float(np.median(v)), "p95": float(np.percentile(v, 95)),
            "min": float(v.min()), "n": int(len(v))}


def block_latency(pipeline, blocks: list[np.ndarray], block_s: float, warmup: int = 2, repeats: int = 3) -> dict:
    """Wall-clock latency of process_block (H2D through D2H; D2H blocks until the device is done)."""
    for b in blocks[:warmup]:
        pipeline.process_block(b)
    walls, modules, crossings, syncw = [], {}, None, []
    for _ in range(repeats):
        for b in blocks:
            sync(pipeline.device)
            t0 = time.perf_counter()
            res = pipeline.process_block(b)
            walls.append(time.perf_counter() - t0)
            for k, v in res.timings.items():
                modules.setdefault(k, []).append(v)
            crossings = res.transfers
            syncw.append(res.transfers.get("sync_wait_s", 0.0))
    lat = _pct(walls)
    dominant = max(((k, np.median(v)) for k, v in modules.items() if k != "total"), key=lambda kv: kv[1])
    return {"block_s": block_s, "latency_s": lat, "rtf_median": lat["median"] / block_s,
            "rtf_p95": lat["p95"] / block_s, "meets_rtf_0.2": bool(lat["median"] / block_s < 0.2),
            "per_module_median_s": {k: float(np.median(v)) for k, v in modules.items()},
            "dominant_module": dominant[0], "crossings": {k: crossings[k] for k in
                                                          ("n_crossings", "n_h2d", "n_d2h", "h2d_bytes", "d2h_bytes",
                                                           "explicit_syncs", "labels")},
            "sync_wait_s_median": float(np.median(syncw))}


def preprocessing_overhead(manifest: str, n_items: int, block_s: float) -> dict:
    """Host-side cost of file decode + resample + block segmentation (CPU preprocessing)."""
    from src.audio.preprocessing import iter_blocks
    rows = read_manifest(manifest)[:n_items]
    t, audio_s = 0.0, 0.0
    for r in rows:
        t0 = time.perf_counter()
        x = load_audio(_abs(r, r["mix_path"]))
        list(iter_blocks(x, 16000, block_s))
        t += time.perf_counter() - t0
        audio_s += len(x) / 16000
    return {"seconds_per_audio_second": t / audio_s, "items": len(rows)}


def throughput(pipeline, manifest: str, n_items: int) -> dict:
    """Audio seconds processed per wall second over whole mixtures (single-pass offline)."""
    rows = read_manifest(manifest)[:n_items]
    xs = [load_audio(_abs(r, r["mix_path"])) for r in rows]
    pipeline.process_block(xs[0])
    t0 = time.perf_counter()
    for x in xs:
        pipeline.process_block(x)
    wall = time.perf_counter() - t0
    audio = sum(len(x) for x in xs) / 16000
    return {"audio_s_per_wall_s": audio / wall, "items_per_s": len(xs) / wall, "audio_s": audio, "wall_s": wall,
            "speaker_hist": {k: sum(r["n_speakers"] == k for r in rows) for k in range(4)}}


def crossing_cost_probe(device: torch.device, payload_bytes: int = 64 * 1024, iters: int = 200) -> dict | None:
    """Measure isolated vs loaded host<->device crossings (CUDA only).
    isolated: D2H of `payload_bytes` with an idle device; loaded: the same D2H issued right
    after enqueuing ~5 ms of matmul work (includes waiting for the queue to drain)."""
    if device.type != "cuda":
        return None
    n = payload_bytes // 4
    d = torch.randn(n, device=device)
    h = torch.empty(n, pin_memory=True)
    a = torch.randn(2048, 2048, device=device)
    res = {}
    for name, loaded in (("isolated", False), ("loaded", True)):
        ts = []
        for _ in range(iters):
            torch.cuda.synchronize()
            if loaded:
                for _ in range(4):
                    a = a @ a * 1e-3
            t0 = time.perf_counter()
            h.copy_(d, non_blocking=False)
            ts.append(time.perf_counter() - t0)
        res[name] = _pct(ts)
    t = []
    for _ in range(iters):  # pure synchronisation latency, no payload
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        torch.cuda.synchronize()
        t.append(time.perf_counter() - t0)
    res["empty_sync"] = _pct(t)
    res["payload_bytes"] = payload_bytes
    return res


@torch.no_grad()
def rescoring_modes(pipeline, blocks: list[np.ndarray], n_streams_list=(1, 2, 3, 4), repeats: int = 5) -> dict:
    """Serial vs CUDA-stream vs batched rescoring on identical N-best inputs from real ASR outputs."""
    from src.models.asr import device_nbest
    from src.models.joint_model import rms_normalize
    import torch.nn.functional as F
    m, dev = pipeline.model, pipeline.device
    inputs = []
    for b in blocks:
        x = torch.from_numpy(b).to(dev)[None]
        diar = m.stdn(m.features(x))
        S = m.max_speakers
        est = m.separator(x, diar.attractors[:, :S], diar.activity_prob[:, :, :S])[0]
        logits, _ = m.asr(m.features(rms_normalize(est)))
        lp = F.log_softmax(logits.float(), -1)
        _, _, toks, _, lens = device_nbest(lp, pipeline.cfg.get("n_best", 8), pipeline.cfg.get("n_flip", 3))
        inputs.append((lp, torch.full((S,), lp.shape[1], device=dev, dtype=torch.long), toks, lens))
    rs = pipeline.rescorer
    ref = [rs.rescore(*inp, mode="serial") for inp in inputs]
    out = {"device": dev.type, "n_blocks": len(inputs), "speakers_per_block": int(inputs[0][2].shape[0]),
           "n_best": int(inputs[0][2].shape[1])}

    def timed(mode, n_streams=None):
        if n_streams:
            rs.cfg.n_streams = n_streams
        res = [rs.rescore(*inp, mode=mode) for inp in inputs]  # warm-up + equality check
        same = all(bool((a[0] == b[0]).all()) and torch.allclose(a[1], b[1], atol=1e-3) for a, b in zip(res, ref))
        ts = []
        for _ in range(repeats):
            sync(dev)
            t0 = time.perf_counter()
            for inp in inputs:
                rs.rescore(*inp, mode=mode)
            sync(dev)
            ts.append((time.perf_counter() - t0) / len(inputs))
        return {"per_block_s": _pct(ts), "identical_to_serial": same}

    out["serial"] = timed("serial")
    out["batched"] = timed("batched")
    if dev.type == "cuda":
        out["streams"] = {n: timed("streams", n) for n in n_streams_list}
    else:
        out["streams"] = "NOT MEASURED: CUDA streams need a CUDA device (Rescorer falls back to serial on CPU)"
    return out
