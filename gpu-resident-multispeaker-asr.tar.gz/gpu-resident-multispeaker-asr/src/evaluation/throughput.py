"""Throughput and memory accounting."""
from __future__ import annotations

import torch

from src.evaluation.latency import throughput  # noqa: F401  (re-exported entry point)
from src.utils.device import param_bytes, peak_memory_mb, rss_mb


@torch.no_grad()
def memory_report(model, lm, device: torch.device, sample_block=None, pipeline=None) -> dict:
    rep = {"param_mb": {n: param_bytes(getattr(model, n)) / 2**20 for n in ("stdn", "separator", "asr")},
           "lm_param_mb": param_bytes(lm) / 2**20 if lm is not None else None,
           "rss_mb": rss_mb()}
    if device.type == "cuda" and pipeline is not None and sample_block is not None:
        torch.cuda.synchronize()
        base = torch.cuda.memory_allocated(device)
        torch.cuda.reset_peak_memory_stats(device)
        pipeline.process_block(sample_block)
        torch.cuda.synchronize()
        rep["gpu_peak_mb"] = peak_memory_mb(device)
        rep["gpu_activation_peak_mb"] = (torch.cuda.max_memory_allocated(device) - base) / 2**20
    else:
        rep["gpu_peak_mb"] = "NOT MEASURED: no CUDA device"
    return rep
