"""Separation quality: permutation-invariant SI-SDR and SI-SDR improvement (SI-SDRi)."""
from __future__ import annotations

import numpy as np
import torch
from scipy.optimize import linear_sum_assignment

from src.training.losses import si_sdr


def pit_si_sdr(est: torch.Tensor, ref: torch.Tensor, mix: torch.Tensor | None = None) -> dict:
    """est (Ke, N), ref (Kr, N). Matches estimates to references maximising total SI-SDR.
    Unmatched references (Ke < Kr) are reported as missed. Lists are ordered by reference:
    perm[n] is the estimate assigned to reference refs[n]."""
    Ke, Kr = est.shape[0], ref.shape[0]
    if Kr == 0:
        return {"si_sdr": [], "si_sdri": [], "perm": [], "missed": 0}
    mat = si_sdr(est[:, None], ref[None]).cpu().numpy() if Ke else np.zeros((0, Kr))
    rows, cols = linear_sum_assignment(-mat) if Ke else ([], [])
    pairs = sorted(zip(cols, rows))  # ordered by reference index
    res = {"si_sdr": [float(mat[i, j]) for j, i in pairs], "perm": [int(i) for _, i in pairs],
           "refs": [int(j) for j, _ in pairs], "missed": Kr - len(pairs)}
    if mix is not None:
        base = si_sdr(mix[None].expand(Kr, -1), ref).cpu().numpy()
        res["si_sdri"] = [float(mat[i, j] - base[j]) for j, i in pairs]
    return res
