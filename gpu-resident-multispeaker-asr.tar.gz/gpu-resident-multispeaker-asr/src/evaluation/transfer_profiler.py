"""Host<->device transfer and synchronisation instrumentation.

Two independent mechanisms:
  * `TransferTracker` - every crossing in the pipelines goes through `h2d()` / `d2h()`,
    which record direction, payload bytes and label; `sync()` records explicit host-visible
    synchronisation points (e.g. reading K_hat). This is the logical count.
  * `profile_memcpy()` - on CUDA, runs a callable under torch.profiler and counts the actual
    Memcpy HtoD / DtoH activities, so the logical count can be verified against what the
    driver really did. On CPU there is no device memory and it returns None.
On a CPU-only machine the `to(device)` calls are no-ops: crossings are *counted* but have no
bandwidth or sync cost, and that is reported as such."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
import torch


@dataclass
class Crossing:
    direction: str  # "H2D" | "D2H"
    nbytes: int
    label: str


@dataclass
class TransferTracker:
    device: torch.device
    crossings: list[Crossing] = field(default_factory=list)
    syncs: list[str] = field(default_factory=list)
    sync_wait_s: float = 0.0

    def reset(self):
        self.crossings.clear()
        self.syncs.clear()
        self.sync_wait_s = 0.0

    def h2d(self, x, label: str, dtype=torch.float32) -> torch.Tensor:
        t = torch.as_tensor(np.ascontiguousarray(x) if isinstance(x, np.ndarray) else x, dtype=dtype)
        if self.device.type == "cuda":
            t = t.pin_memory().to(self.device, non_blocking=True)
        self.crossings.append(Crossing("H2D", t.numel() * t.element_size(), label))
        return t

    def d2h(self, t: torch.Tensor, label: str) -> np.ndarray:
        """Blocking copy to host; time spent waiting for the device is recorded separately."""
        t0 = time.perf_counter()
        out = t.detach().to("cpu").numpy()
        if self.device.type == "cuda":
            self.sync_wait_s += time.perf_counter() - t0
        self.crossings.append(Crossing("D2H", t.numel() * t.element_size(), label))
        return out

    def sync(self, label: str):
        self.syncs.append(label)

    def summary(self) -> dict:
        h = [c for c in self.crossings if c.direction == "H2D"]
        d = [c for c in self.crossings if c.direction == "D2H"]
        return {"n_crossings": len(self.crossings), "n_h2d": len(h), "n_d2h": len(d),
                "h2d_bytes": sum(c.nbytes for c in h), "d2h_bytes": sum(c.nbytes for c in d),
                "explicit_syncs": len(self.syncs), "labels": [f"{c.direction}:{c.label}" for c in self.crossings],
                "device": self.device.type, "sync_wait_s": self.sync_wait_s}


def profile_memcpy(fn, device: torch.device) -> dict | None:
    """Count real CUDA memcpy activities while running fn(). None on non-CUDA devices."""
    if device.type != "cuda":
        return None
    from torch.profiler import ProfilerActivity, profile
    with profile(activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA]) as prof:
        fn()
        torch.cuda.synchronize()
    counts = {"HtoD": 0, "DtoH": 0, "DtoD": 0}
    for ev in prof.events():
        name = ev.name.lower()
        for k in counts:
            if "memcpy" in name and k.lower() in name.replace("_", "").replace(" ", ""):
                counts[k] += 1
    return counts


def analytical_transfer_time(payload_bytes: list[int], bandwidth_gbps: float, l_sync_s: float) -> float:
    """T_xfer = sum_i (S_i / B_PCIe + L_sync). Analytical model, NOT a measurement."""
    return sum(s / (bandwidth_gbps * 1e9) + l_sync_s for s in payload_bytes)


def analytical_rtf(t_comp_s: float, n_crossings: int, l_sync_s: float, block_s: float) -> float:
    """RTF ~= (T_comp + n * L_sync) / T_b. Analytical model, NOT a measurement."""
    return (t_comp_s + n_crossings * l_sync_s) / block_s


def estimate_l_sync(t_n4_s: float, t_n2_s: float) -> float:
    """L_sync = (T_{n=4} - T_{n=2}) / 2. Valid only if the two runs do identical compute and
    differ solely by one extra round trip (2 crossings) of the same payload; the payload's
    bandwidth time is subtracted separately by the caller if it is not negligible."""
    return (t_n4_s - t_n2_s) / 2
