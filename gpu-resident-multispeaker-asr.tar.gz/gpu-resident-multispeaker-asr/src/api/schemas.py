"""Pydantic response schemas for the inference API."""
from __future__ import annotations

from pydantic import BaseModel


class SegmentOut(BaseModel):
    start: float
    end: float
    speaker_id: str
    text: str
    confidence: float | None = None
    uncertain: bool = False


class TranscribeResponse(BaseModel):
    segments: list[SegmentOut]
    speakers: list[str]
    duration_s: float
    processing_s: float
    rtf: float
    device: str
    precision: str
    pipeline_mode: str
    host_device_crossings: int | None = None
    model: dict


class HealthResponse(BaseModel):
    status: str
    device: str
    cuda_available: bool
    model_loaded: bool


class ModelInfoResponse(BaseModel):
    sample_rate: int
    n_mels: int
    frame_hop_ms: float
    speaker_capacity: int
    checkpoint: dict
    model_config_: dict

    model_config = {"protected_namespaces": ()}
