"""FastAPI inference service:  uvicorn src.api.main:app --host 127.0.0.1 --port 8000

Models are loaded once at startup (lifespan). Uploads are size-limited, decoded in memory
(no temporary files, no filesystem paths accepted from clients) and duration-limited.
Environment: MSASR_CONFIG (default configs/inference.yaml), MSASR_CHECKPOINT (override)."""
from __future__ import annotations

import os
import threading
from contextlib import asynccontextmanager

import torch
from fastapi import FastAPI, File, HTTPException, UploadFile

from src.api.schemas import HealthResponse, ModelInfoResponse, SegmentOut, TranscribeResponse
from src.audio.loader import AudioError, load_bytes
from src.inference.offline import OfflineTranscriber, load_models
from src.utils.config import load_config
from src.utils.device import select_device

STATE: dict = {}


def _load(app_state: dict):
    cfg = load_config(os.environ.get("MSASR_CONFIG", "configs/inference.yaml"))
    device = select_device(cfg.get("device", "auto"))
    model, lm, info = load_models(cfg, device, os.environ.get("MSASR_CHECKPOINT"))
    precision = cfg.get("precision", "fp32")
    app_state.update(cfg=cfg, device=device, info=info, model=model, precision=precision,
                     transcriber=OfflineTranscriber(model, lm, cfg, device, precision),
                     lock=threading.Lock())


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        _load(STATE)
    except FileNotFoundError as e:  # start anyway so /health can report the problem
        STATE["load_error"] = str(e)
    yield
    STATE.clear()


app = FastAPI(title="GPU-resident multi-speaker ASR", version="0.1.0", lifespan=lifespan)


@app.get("/health", response_model=HealthResponse)
def health():
    dev = STATE.get("device")
    return HealthResponse(status="ok" if "model" in STATE else f"degraded: {STATE.get('load_error', 'not loaded')}",
                          device=str(dev) if dev else "none", cuda_available=torch.cuda.is_available(),
                          model_loaded="model" in STATE)


@app.get("/model-info", response_model=ModelInfoResponse)
def model_info():
    if "model" not in STATE:
        raise HTTPException(503, "model not loaded")
    f = STATE["cfg"]["model"]["features"]
    return ModelInfoResponse(sample_rate=f["sample_rate"], n_mels=f["n_mels"], frame_hop_ms=1000 * f["hop"] / f["sample_rate"],
                             speaker_capacity=STATE["model"].max_speakers, checkpoint=STATE["info"],
                             model_config_=STATE["cfg"]["model"])


@app.post("/transcribe", response_model=TranscribeResponse)
async def transcribe(file: UploadFile = File(...)):
    if "model" not in STATE:
        raise HTTPException(503, "model not loaded")
    api = STATE["cfg"].get("api", {})
    limit = int(api.get("max_upload_mb", 25) * 2**20)
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, f"file exceeds {api.get('max_upload_mb', 25)} MB")
    if not data:
        raise HTTPException(400, "empty upload")
    try:
        audio = load_bytes(data, 16000)
    except AudioError as e:
        raise HTTPException(400, f"invalid audio: {e}") from e
    dur = len(audio) / 16000
    if dur > api.get("max_duration_s", 600):
        raise HTTPException(413, f"audio longer than {api.get('max_duration_s')} s")
    try:
        with STATE["lock"]:  # one inference at a time on the shared model/device
            out = STATE["transcriber"].transcribe_array(audio)
    except AudioError as e:
        raise HTTPException(400, str(e)) from e
    segs = [SegmentOut(**s.to_dict()) for s in out["segments"]]
    return TranscribeResponse(segments=segs, speakers=sorted({s.speaker_id for s in segs}), duration_s=dur,
                              processing_s=out["processing_s"], rtf=out["rtf"], device=str(STATE["device"]),
                              precision=STATE["precision"], pipeline_mode=STATE["cfg"]["pipeline"]["mode"],
                              host_device_crossings=out.get("transfers", {}).get("n_crossings"),
                              model=STATE["info"])
