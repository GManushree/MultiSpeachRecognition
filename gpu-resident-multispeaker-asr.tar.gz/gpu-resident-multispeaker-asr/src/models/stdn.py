"""Module 2A: Self-Tuning Diarization Network (STDN).

log-Mel (B, 80, T) -> masked CMVN -> 2x strided Conv1d (x4 subsampling, 40 ms frames)
-> 4 self-attention layers (d=256, 4 heads) -> frame embeddings z_t
-> EDA attractors a_k, p_exist(k) = sigmoid(w^T a_k),  p(t,k) = sigmoid(z_t^T a_k).

Multi-label by construction: each (t, k) is an independent sigmoid, so any number of
speakers can be active in a frame. No positional encoding is used (as in EEND), the conv
front-end supplies local order. `max_speakers` is a decoding *capacity*, not a claim
that more speakers are handled; behaviour beyond the trained count is untested."""
from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn

from src.models.attractors import EncoderDecoderAttractor


def masked_cmvn(feats: torch.Tensor, frame_mask: torch.Tensor | None) -> torch.Tensor:
    """feats (B, F, T); frame_mask (B, T) bool or None. Per-utterance mean/var over valid frames."""
    if frame_mask is None:
        mu = feats.mean(-1, keepdim=True)
        sd = feats.std(-1, keepdim=True, correction=0)  # population std, same as the masked path
    else:
        m = frame_mask[:, None, :].to(feats.dtype)
        n = m.sum(-1, keepdim=True).clamp(min=1)
        mu = (feats * m).sum(-1, keepdim=True) / n
        sd = (((feats - mu) * m).square().sum(-1, keepdim=True) / n).sqrt()
    out = (feats - mu) / (sd + 1e-5)
    return out if frame_mask is None else out * frame_mask[:, None, :].to(out.dtype)


def subsampled_length(n: torch.Tensor | int, factor_layers: int = 2):
    for _ in range(factor_layers):
        n = (n - 1) // 2 + 1
    return n


@dataclass
class DiarizationOutput:
    embeddings: torch.Tensor      # (B, T', D)  z_t
    attractors: torch.Tensor      # (B, S, D)   a_k, S = capacity + 1
    exist_logits: torch.Tensor    # (B, S)
    activity_logits: torch.Tensor  # (B, T', S)

    @property
    def exist_prob(self):
        return torch.sigmoid(self.exist_logits)

    @property
    def activity_prob(self):
        return torch.sigmoid(self.activity_logits)


class STDN(nn.Module):
    def __init__(self, n_mels: int = 80, d_model: int = 256, n_heads: int = 4, n_layers: int = 4,
                 ff_dim: int = 1024, dropout: float = 0.1, max_speakers: int = 3):
        super().__init__()
        self.max_speakers = max_speakers
        self.conv1 = nn.Conv1d(n_mels, d_model, 3, stride=2, padding=1)
        self.conv2 = nn.Conv1d(d_model, d_model, 3, stride=2, padding=1)
        self.act = nn.GELU()
        layer = nn.TransformerEncoderLayer(d_model, n_heads, ff_dim, dropout, batch_first=True,
                                           norm_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(layer, n_layers, enable_nested_tensor=False)
        self.norm = nn.LayerNorm(d_model)
        self.eda = EncoderDecoderAttractor(d_model, max_speakers)

    def forward(self, feats: torch.Tensor, feat_lengths_cpu: torch.Tensor | None = None,
                shuffle: bool | None = None) -> DiarizationOutput:
        B, _, T = feats.shape
        fmask = None
        if feat_lengths_cpu is not None:
            fmask = (torch.arange(T)[None] < feat_lengths_cpu[:, None]).to(feats.device, non_blocking=True)
        x = self.act(self.conv1(masked_cmvn(feats, fmask)))
        lengths, kpm = None, None
        if feat_lengths_cpu is not None:  # zero padded positions so conv bias cannot leak into valid frames
            l1 = subsampled_length(feat_lengths_cpu, 1)
            x = x * (torch.arange(x.shape[-1])[None] < l1[:, None]).to(x.device, non_blocking=True)[:, None]
        x = self.act(self.conv2(x)).transpose(1, 2)  # (B, T', D)
        if feat_lengths_cpu is not None:
            lengths = subsampled_length(feat_lengths_cpu)
            kpm = (torch.arange(x.shape[1])[None] >= lengths[:, None]).to(feats.device, non_blocking=True)
        z = self.norm(self.encoder(x, src_key_padding_mask=kpm))
        if kpm is not None:
            z = z.masked_fill(kpm[..., None], 0.0)
        attractors, exist_logits = self.eda(z, lengths, shuffle=shuffle)
        activity = torch.einsum("btd,bsd->bts", z, attractors)
        return DiarizationOutput(z, attractors, exist_logits, activity)


def estimate_speaker_count(exist_prob: torch.Tensor, threshold: float = 0.5,
                           uncertainty_margin: float = 0.15):
    """K_hat = count(p_exist > threshold) over the capacity attractors (the extra
    "stop" attractor is included in the count, as in the paper's formula).
    Returns (k_hat (B,), speaker_mask (B, S) bool, uncertain (B,) bool). Everything
    stays on-device; no host synchronization."""
    mask = exist_prob > threshold
    k_hat = mask.sum(-1)
    uncertain = ((exist_prob - threshold).abs() < uncertainty_margin).any(-1)
    return k_hat, mask, uncertain
