"""LSTM encoder-decoder attractor (EDA) module, after Horiguchi et al. (EEND-EDA).

The encoder LSTM reads the frame embeddings (in random order during training, so the
attractors do not depend on speaker order of appearance); its final state seeds a
decoder LSTM fed zero vectors for `max_speakers + 1` steps. Each decoder output is an
attractor a_k with existence probability p_exist(k) = sigmoid(w^T a_k + b)."""
from __future__ import annotations

import torch
import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence


class EncoderDecoderAttractor(nn.Module):
    def __init__(self, dim: int = 256, max_speakers: int = 3):
        super().__init__()
        self.dim, self.max_speakers = dim, max_speakers
        self.encoder = nn.LSTM(dim, dim, batch_first=True)
        self.decoder = nn.LSTM(dim, dim, batch_first=True)
        self.exist = nn.Linear(dim, 1)

    def forward(self, emb: torch.Tensor, lengths_cpu: torch.Tensor | None = None,
                shuffle: bool | None = None, n_attractors: int | None = None):
        """emb: (B, T, D). `lengths_cpu`: (B,) valid frames as a *host* tensor, or None when
        no sequence is padded (the inference path) - packing needs host-side lengths, so
        passing None keeps inference free of device->host syncs.
        Returns attractors (B, S, D) and existence logits (B, S), S = max_speakers + 1."""
        B, T, D = emb.shape
        shuffle = self.training if shuffle is None else shuffle
        if shuffle:
            keys = torch.rand(B, T, device=emb.device)
            if lengths_cpu is not None:
                pad = torch.arange(T)[None] >= lengths_cpu[:, None]
                keys = keys.masked_fill(pad.to(emb.device, non_blocking=True), 2.0)
            emb = emb.gather(1, keys.argsort(1)[..., None].expand(B, T, D))
        if lengths_cpu is not None:
            seq = pack_padded_sequence(emb, lengths_cpu.clamp(min=1), batch_first=True,
                                       enforce_sorted=False)
        else:
            seq = emb
        _, state = self.encoder(seq)
        S = n_attractors or self.max_speakers + 1
        attractors, _ = self.decoder(emb.new_zeros(B, S, D), state)
        return attractors, self.exist(attractors).squeeze(-1)
