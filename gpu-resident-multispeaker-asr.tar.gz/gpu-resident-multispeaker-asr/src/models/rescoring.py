"""Module 4: N-best hypothesis rescoring, optionally across CUDA streams.

score(h) = w_ac * log P_ctc(h | X) + w_lm * log P_lm(h) + w_len * |h|

* Acoustic score: exact CTC log-likelihood of each hypothesis, computed on device with
  F.ctc_loss (not the single-alignment score from N-best generation).
* LM score: character LSTM LM trained on the training transcripts, on device.
* Execution modes over S independent speaker streams:
    serial   - one speaker at a time on the current stream (baseline),
    streams  - speaker s on CUDA stream s % n_streams, joined with events,
    batched  - all S*N hypotheses in one launch sequence (the usual alternative to streams).
  All three compute identical scores; tests verify this.

Thread-safety: model parameters are only read; every stream allocates its own
activations; inputs produced on the main stream are guarded with `record_stream` and an
event dependency so the caching allocator cannot recycle them early."""
from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


class CharLSTMLM(nn.Module):
    """Character LM over CharTokenizer ids; id 0 doubles as BOS/EOS."""

    def __init__(self, vocab_size: int = 29, emb: int = 64, hidden: int = 256, layers: int = 2,
                 dropout: float = 0.1):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, emb)
        self.lstm = nn.LSTM(emb, hidden, layers, batch_first=True, dropout=dropout)
        self.out = nn.Linear(hidden, vocab_size)

    def forward(self, inp):
        h, _ = self.lstm(self.emb(inp))
        return self.out(h)

    def sequence_logprob(self, tokens: torch.Tensor, lengths: torch.Tensor) -> torch.Tensor:
        """tokens (N, L) left-packed ids (0-padded), lengths (N,) -> log P(tokens + EOS) (N,)."""
        N, L = tokens.shape
        inp = F.pad(tokens, (1, 0), value=0)                      # BOS + tokens   (N, L+1)
        pos = torch.arange(L + 1, device=tokens.device)[None]
        tgt = torch.where(pos < lengths[:, None], F.pad(tokens, (0, 1), value=0), 0)  # EOS at len
        logp = F.log_softmax(self(inp).float(), -1).gather(-1, tgt[..., None]).squeeze(-1)
        return (logp * (pos <= lengths[:, None])).sum(-1)


def ctc_log_likelihood(logp: torch.Tensor, out_len: torch.Tensor, tokens: torch.Tensor,
                       lengths: torch.Tensor) -> torch.Tensor:
    """log P_ctc(tokens | logp) via the CTC forward algorithm, entirely on device.

    logp (M, T, V) log-probs, out_len (M,), tokens (M, L) left-packed, lengths (M,).
    Exists because F.ctc_loss on CUDA copies the length tensors to the host internally (an
    implicit D2H sync inside the rescoring step); this version issues no host reads.
    Equals -F.ctc_loss(..., reduction='none') (tested). Infeasible targets give -inf."""
    M, T, V = logp.shape
    L = tokens.shape[1]
    S = 2 * L + 1
    ext = torch.zeros(M, S, dtype=torch.long, device=logp.device)
    ext[:, 1::2] = tokens
    pos = torch.arange(S, device=logp.device)[None]
    valid_state = pos < (2 * lengths[:, None] + 1)
    prev2 = F.pad(ext[:, :-2], (2, 0), value=-1)
    can_skip = (ext != 0) & (ext != prev2) & (pos >= 2)
    ninf = torch.tensor(float("-inf"), device=logp.device)
    lp = logp.float()
    emit0 = lp[:, 0].gather(1, ext)
    alpha = torch.where(pos < 2, emit0, ninf)
    alpha = torch.where(valid_state, alpha, ninf)
    for t in range(1, T):
        a1 = F.pad(alpha[:, :-1], (1, 0), value=float("-inf"))
        a2 = torch.where(can_skip, F.pad(alpha[:, :-2], (2, 0), value=float("-inf")), ninf)
        new = torch.logsumexp(torch.stack([alpha, a1, a2]), 0) + lp[:, t].gather(1, ext)
        new = torch.where(valid_state, new, ninf)
        alpha = torch.where((t < out_len)[:, None], new, alpha)
    last = (2 * lengths).clamp(max=S - 1)
    end1 = alpha.gather(1, last[:, None]).squeeze(1)
    end2 = alpha.gather(1, (last - 1).clamp(min=0)[:, None]).squeeze(1)
    end2 = torch.where(lengths > 0, end2, ninf)
    return torch.logaddexp(end1, end2)


@dataclass
class RescoreConfig:
    w_ac: float = 1.0
    w_lm: float = 0.3
    w_len: float = 0.0
    n_streams: int = 4
    mode: str = "batched"    # serial | streams | batched
    acoustic: str = "device_dp"  # device_dp (no host sync) | torch_ctc (F.ctc_loss; syncs on CUDA)


class Rescorer:
    def __init__(self, lm: CharLSTMLM | None, cfg: RescoreConfig):
        self.lm, self.cfg = lm, cfg
        self._streams: list = []

    # --------------------------------------------------------------- core scoring
    def _score(self, logp, out_len, tokens, lengths):
        """logp (S, T, V); out_len (S,); tokens (S, N, L); lengths (S, N) -> scores (S, N)."""
        S, N, L = tokens.shape
        lp = logp[:, None].expand(S, N, *logp.shape[1:]).reshape(S * N, *logp.shape[1:])
        ol = out_len[:, None].expand(S, N).reshape(-1)
        tok, ln = tokens.reshape(S * N, L), lengths.reshape(-1)
        if self.cfg.acoustic == "device_dp":
            ac = ctc_log_likelihood(lp, ol, tok, ln)
        else:  # infeasible hypotheses -> inf loss -> -inf score (zero_infinity off)
            ac = -F.ctc_loss(lp.float().transpose(0, 1), tok.clamp(min=0), ol, ln, blank=0,
                             reduction="none", zero_infinity=False)
        score = self.cfg.w_ac * ac + self.cfg.w_len * ln.float()
        if self.lm is not None and self.cfg.w_lm != 0:
            score = score + self.cfg.w_lm * self.lm.sequence_logprob(tok, ln)
        return torch.nan_to_num(score, nan=-1e30, neginf=-1e30).reshape(S, N)

    @torch.no_grad()
    def rescore(self, logp, out_len, tokens, lengths, mode: str | None = None):
        """Returns (best index (S,), all scores (S, N)) on device; no host sync."""
        mode = mode or self.cfg.mode
        if mode == "streams" and logp.device.type != "cuda":
            mode = "serial"  # documented fallback: CUDA streams require a CUDA device
        if mode == "batched":
            scores = self._score(logp, out_len, tokens, lengths)
        elif mode == "serial":
            scores = torch.cat([self._score(logp[s:s + 1], out_len[s:s + 1], tokens[s:s + 1],
                                            lengths[s:s + 1]) for s in range(tokens.shape[0])])
        elif mode == "streams":
            scores = self._rescore_streams(logp, out_len, tokens, lengths)
        else:
            raise ValueError(f"unknown rescoring mode {mode!r}")
        return scores.argmax(-1), scores

    def _rescore_streams(self, logp, out_len, tokens, lengths):
        S = tokens.shape[0]
        n = max(1, min(self.cfg.n_streams, S))
        if len(self._streams) < n:
            self._streams = [torch.cuda.Stream(device=logp.device) for _ in range(n)]
        main = torch.cuda.current_stream(logp.device)
        ready = torch.cuda.Event()
        ready.record(main)
        parts, done = [None] * S, []
        for s in range(S):
            st = self._streams[s % n]
            st.wait_event(ready)
            with torch.cuda.stream(st):
                for t in (logp, out_len, tokens, lengths):
                    t.record_stream(st)
                parts[s] = self._score(logp[s:s + 1], out_len[s:s + 1], tokens[s:s + 1], lengths[s:s + 1])
                ev = torch.cuda.Event()
                ev.record(st)
                done.append((ev, parts[s], st))
        for ev, part, st in done:
            main.wait_event(ev)
            part.record_stream(main)
        return torch.cat(parts)


def lm_loss(lm: CharLSTMLM, tokens: torch.Tensor, lengths: torch.Tensor) -> torch.Tensor:
    """Mean negative log-likelihood per character (incl. EOS) for LM training."""
    return -(lm.sequence_logprob(tokens, lengths).sum() / (lengths + 1).sum())
