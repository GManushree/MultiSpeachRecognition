"""Module 3: hybrid CNN-Transformer CTC recognizer + decoders.

Architecture (custom, trained from scratch here - there is no pretrained checkpoint for it):
  log-Mel (reused Module 1, applied to each separated stream) -> masked CMVN
  -> 2x Conv2d (x2 time / x4 frequency subsampling, 20 ms frames) -> linear -> sinusoidal PE
  -> 4 Transformer layers (d=192, 4 heads) -> linear -> character CTC (29 symbols).

Decoders:
  * `greedy_decode`      - on-device argmax + CTC collapse.
  * `device_nbest`       - on-device N-best: enumerates the 2^m alternative alignments
                           obtained by switching the m lowest-margin frames to their
                           runner-up symbol; fully tensorized, no host sync. This is an
                           approximation of beam search, documented as such.
  * `prefix_beam_search` - standard CTC prefix beam search on host (NumPy); used by the
                           conventional cascaded baseline.
  * `forced_align`       - CTC Viterbi alignment (host) for word timestamps of beam output.

`PretrainedCTCBaseline` wraps a Hugging Face wav2vec2-CTC model when one is available
locally; it is a *baseline*, never presented as the paper's architecture."""
from __future__ import annotations

import math
from collections import defaultdict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from src.models.stdn import masked_cmvn


class CharTokenizer:
    BLANK = 0
    chars = [" ", "'"] + [chr(c) for c in range(ord("a"), ord("z") + 1)]

    def __init__(self):
        self.stoi = {c: i + 1 for i, c in enumerate(self.chars)}
        self.itos = {i + 1: c for i, c in enumerate(self.chars)}

    @property
    def vocab_size(self) -> int:
        return len(self.chars) + 1

    @staticmethod
    def normalize(text: str) -> str:
        t = "".join(c for c in text.lower() if c.isalpha() or c in " '")
        return " ".join(t.split())

    def encode(self, text: str) -> list[int]:
        return [self.stoi[c] for c in self.normalize(text)]

    def decode(self, ids) -> str:
        return "".join(self.itos.get(int(i), "") for i in ids if int(i) != self.BLANK)


class SinusoidalPE(nn.Module):
    def __init__(self, d: int, max_len: int = 20000):
        super().__init__()
        pos = torch.arange(max_len)[:, None]
        div = torch.exp(torch.arange(0, d, 2) * (-math.log(10000.0) / d))
        pe = torch.zeros(max_len, d)
        pe[:, 0::2], pe[:, 1::2] = torch.sin(pos * div), torch.cos(pos * div)
        self.register_buffer("pe", pe, persistent=False)

    def forward(self, x):
        return x + self.pe[: x.shape[1]].to(x.dtype)


ASR_FRAME_S = 0.02


def asr_out_lengths(n_frames):
    return (n_frames - 1) // 2 + 1


class CTCASR(nn.Module):
    def __init__(self, n_mels: int = 80, d_model: int = 192, n_heads: int = 4, n_layers: int = 4,
                 ff_dim: int = 768, conv_ch: int = 64, dropout: float = 0.1, vocab_size: int = 29):
        super().__init__()
        # (time, freq) strides: x2 in time (20 ms output frames), x4 in frequency
        self.conv = nn.Sequential(nn.Conv2d(1, conv_ch, 3, (2, 2), 1), nn.GELU(),
                                  nn.Conv2d(conv_ch, conv_ch, 3, (1, 2), 1), nn.GELU())
        self.proj = nn.Linear(conv_ch * ((n_mels + 3) // 4), d_model)
        self.pe = SinusoidalPE(d_model)
        layer = nn.TransformerEncoderLayer(d_model, n_heads, ff_dim, dropout, batch_first=True,
                                           norm_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(layer, n_layers, enable_nested_tensor=False)
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, feats: torch.Tensor, feat_lengths: torch.Tensor | None = None):
        """feats (B, 80, T) log-Mel; feat_lengths (B,) on any device or None.
        Returns logits (B, T', V) and output lengths (B,) on feats.device (or None)."""
        fmask = None
        if feat_lengths is not None:
            feat_lengths = feat_lengths.to(feats.device)
            fmask = torch.arange(feats.shape[-1], device=feats.device)[None] < feat_lengths[:, None]
        x = masked_cmvn(feats, fmask)
        x = self.conv[1](self.conv[0](x.transpose(1, 2)[:, None]))   # (B, C, T', F')
        if feat_lengths is not None:  # zero padded frames so the conv bias cannot leak into valid ones
            l1 = asr_out_lengths(feat_lengths)
            x = x * (torch.arange(x.shape[2], device=x.device)[None] < l1[:, None])[:, None, :, None]
        x = self.conv[3](self.conv[2](x))
        B, C, T, Fq = x.shape
        x = self.dropout(self.pe(self.proj(x.permute(0, 2, 1, 3).reshape(B, T, C * Fq))))
        out_len, kpm = None, None
        if feat_lengths is not None:
            out_len = asr_out_lengths(feat_lengths)
            kpm = torch.arange(T, device=x.device)[None] >= out_len[:, None]
        x = self.norm(self.encoder(x, src_key_padding_mask=kpm))
        return self.head(x), out_len


def ctc_loss(logits, out_len, targets, target_len, reduction="mean"):
    """CTC in FP32 regardless of autocast (numerically sensitive)."""
    logp = F.log_softmax(logits.float(), -1).transpose(0, 1)
    return F.ctc_loss(logp, targets, out_len, target_len, blank=0, reduction=reduction,
                      zero_infinity=True)


# ----------------------------------------------------------------------------- decoders
def ctc_collapse(paths: torch.Tensor, valid: torch.Tensor | None = None):
    """paths (..., T) int -> (tokens (..., T) left-packed, frames (..., T), lengths (...)).
    Padded positions hold 0. Fully tensorized (stays on device)."""
    prev = F.pad(paths[..., :-1], (1, 0), value=-1)
    keep = (paths != 0) & (paths != prev)
    if valid is not None:
        keep &= valid
    lengths = keep.sum(-1)
    pos = torch.where(keep, keep.cumsum(-1) - 1, paths.shape[-1])  # dropped -> overflow slot
    T = paths.shape[-1]
    tokens = torch.zeros(*paths.shape[:-1], T + 1, dtype=paths.dtype, device=paths.device)
    frames = torch.zeros_like(tokens)
    tokens.scatter_(-1, pos, paths)
    t_idx = torch.arange(T, device=paths.device).expand_as(paths).to(paths.dtype)
    frames.scatter_(-1, pos, t_idx)
    return tokens[..., :T], frames[..., :T], lengths


def greedy_decode(logits: torch.Tensor, out_len: torch.Tensor | None = None):
    paths = logits.argmax(-1)
    valid = None
    if out_len is not None:
        valid = torch.arange(paths.shape[-1], device=paths.device)[None] < out_len[:, None]
    return ctc_collapse(paths, valid)


def device_nbest(logp: torch.Tensor, n_best: int = 8, n_flip: int = 3,
                 valid: torch.Tensor | None = None):
    """logp (B, T, V) log-probs -> N-best alternative alignments, all on device.

    Returns paths (B, N, T), alignment scores (B, N), tokens/frames/lengths of the
    collapsed hypotheses (B, N, T). N = min(n_best, 2**n_flip)."""
    B, T, V = logp.shape
    top_v, top_i = logp.topk(2, -1)                           # (B, T, 2)
    margin = top_v[..., 0] - top_v[..., 1]
    if valid is not None:
        margin = margin.masked_fill(~valid, float("inf"))
    m = min(n_flip, T)
    flip_t = margin.topk(m, -1, largest=False).indices         # (B, m) least confident frames
    combos = ((torch.arange(2 ** m, device=logp.device)[:, None] >> torch.arange(m, device=logp.device)) & 1).bool()
    flip_margin = margin.gather(1, flip_t)                     # (B, m)
    flip_margin = torch.where(torch.isinf(flip_margin), torch.full_like(flip_margin, 1e9), flip_margin)
    base = top_v[..., 0].masked_fill(~valid, 0).sum(-1) if valid is not None else top_v[..., 0].sum(-1)
    scores = base[:, None] - (combos[None].float() * flip_margin[:, None]).sum(-1)  # (B, 2^m)
    N = min(n_best, 2 ** m)
    sel = scores.topk(N, -1).indices                           # (B, N)
    chosen = combos[sel]                                       # (B, N, m)
    paths = top_i[..., 0][:, None].expand(B, N, T).clone()
    alt = top_i[..., 1].gather(1, flip_t)[:, None].expand(B, N, m)
    cur = paths.gather(2, flip_t[:, None].expand(B, N, m))
    paths.scatter_(2, flip_t[:, None].expand(B, N, m), torch.where(chosen, alt, cur))
    v = None if valid is None else valid[:, None].expand(B, N, T)
    tokens, frames, lengths = ctc_collapse(paths, v)
    return paths, scores.gather(1, sel), tokens, frames, lengths


def _logsumexp(*xs):
    m = max(xs)
    if m == -np.inf:
        return -np.inf
    return m + math.log(sum(math.exp(x - m) for x in xs))


def prefix_beam_search(logp: np.ndarray, beam: int = 8, n_best: int = 8, prune: float = -12.0):
    """Standard CTC prefix beam search. logp (T, V) natural-log probs (host).
    Returns [(token tuple, log prob)] sorted best-first, length <= n_best."""
    beams = {(): (0.0, -np.inf)}  # prefix -> (log p_blank, log p_nonblank)
    for t in range(logp.shape[0]):
        row = logp[t]
        cand = np.where(row > prune)[0]
        nxt: dict = defaultdict(lambda: (-np.inf, -np.inf))
        for prefix, (pb, pnb) in beams.items():
            total = _logsumexp(pb, pnb)
            for c in cand:
                p = float(row[c])
                if c == 0:
                    b, nb = nxt[prefix]
                    nxt[prefix] = (_logsumexp(b, total + p), nb)
                    continue
                last = prefix[-1] if prefix else None
                ext = prefix + (int(c),)
                b, nb = nxt[ext]
                if c == last:
                    nxt[ext] = (b, _logsumexp(nb, pb + p))
                    b2, nb2 = nxt[prefix]
                    nxt[prefix] = (b2, _logsumexp(nb2, pnb + p))
                else:
                    nxt[ext] = (b, _logsumexp(nb, total + p))
        beams = dict(sorted(nxt.items(), key=lambda kv: -_logsumexp(*kv[1]))[:beam])
    ranked = sorted(((k, _logsumexp(*v)) for k, v in beams.items()), key=lambda kv: -kv[1])
    return ranked[:n_best]


def forced_align(logp: np.ndarray, tokens: list[int]) -> list[int]:
    """CTC Viterbi alignment; returns the first emission frame of each token."""
    if not tokens:
        return []
    ext = [0]
    for t in tokens:
        ext += [t, 0]
    S, T = len(ext), logp.shape[0]
    dp = np.full((T, S), -np.inf)
    bp = np.zeros((T, S), dtype=np.int64)
    dp[0, 0] = logp[0, 0]
    if S > 1:
        dp[0, 1] = logp[0, ext[1]]
    for t in range(1, T):
        for s in range(S):
            cands = [(dp[t - 1, s], s)]
            if s >= 1:
                cands.append((dp[t - 1, s - 1], s - 1))
            if s >= 2 and ext[s] != 0 and ext[s] != ext[s - 2]:
                cands.append((dp[t - 1, s - 2], s - 2))
            v, arg = max(cands)
            dp[t, s] = v + logp[t, ext[s]]
            bp[t, s] = arg
    s = S - 1 if S < 2 or dp[T - 1, S - 1] >= dp[T - 1, S - 2] else S - 2
    states = [s]
    for t in range(T - 1, 0, -1):
        s = bp[t, s]
        states.append(s)
    states.reverse()
    first = {}
    for t, s in enumerate(states):
        if s % 2 == 1 and (s // 2) not in first:
            first[s // 2] = t
    return [first.get(i, 0) for i in range(len(tokens))]


class PretrainedCTCBaseline:
    """Optional pretrained baseline (wav2vec2-CTC via Hugging Face Transformers).

    Only usable when `transformers` is installed and a checkpoint is present locally;
    in the development environment neither was available (huggingface.co unreachable),
    so this path is untested. It is never substituted silently for CTCASR."""

    def __init__(self, local_path: str, device: torch.device):
        try:
            from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
        except ImportError as e:
            raise RuntimeError("transformers is not installed; pretrained baseline unavailable") from e
        self.processor = Wav2Vec2Processor.from_pretrained(local_path, local_files_only=True)
        self.model = Wav2Vec2ForCTC.from_pretrained(local_path, local_files_only=True).to(device).eval()
        self.device = device

    @torch.no_grad()
    def transcribe(self, wav: np.ndarray, sr: int = 16000) -> str:
        inp = self.processor(wav, sampling_rate=sr, return_tensors="pt").input_values.to(self.device)
        ids = self.model(inp).logits.argmax(-1)[0]
        return self.processor.decode(ids).lower()
