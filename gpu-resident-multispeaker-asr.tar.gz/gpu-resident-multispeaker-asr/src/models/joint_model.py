"""Joint model wiring Modules 1-3 and the joint training objective.

    L_total = L_sep + lambda_1 * L_diar + lambda_2 * L_asr
    L_diar  = BCE(activity, labels | perm) + BCE(existence)
    L_sep   = -SI-SDR(est, ref | perm)
    L_asr   = CTC(ASR(LogMel(normalize(est))), transcript | perm)

Gradients of L_asr flow through the differentiable LogMel into the separator, and through
the separator's FiLM conditioning and activity channel into the STDN attractors - this
is the coupling that makes the optimization joint rather than a cascade of separately
trained models. Which terms are active, and which modules are frozen, is set per stage."""
from __future__ import annotations

import torch
import torch.nn as nn

from src.audio.mel_features import LogMel
from src.models.asr import CTCASR, ctc_loss
from src.models.separator import AttractorConditionedSeparator
from src.models.stdn import STDN, subsampled_length
from src.training.losses import (existence_loss, finite_or_zero, hungarian, pairwise_bce,
                                 si_sdr)


def rms_normalize(x: torch.Tensor, target: float = 0.05, eps: float = 1e-5) -> torch.Tensor:
    return x * (target / (x.float().square().mean(-1, keepdim=True).sqrt() + eps)).to(x.dtype)


class JointModel(nn.Module):
    def __init__(self, cfg: dict):
        super().__init__()
        f = cfg.get("features", {})
        self.features = LogMel(f.get("sample_rate", 16000), f.get("n_fft", 400), f.get("hop", 160),
                               f.get("n_mels", 80), f.get("use_fused_kernel", False))
        self.stdn = STDN(**cfg.get("stdn", {}))
        self.separator = AttractorConditionedSeparator(**cfg.get("separator", {}))
        self.asr = CTCASR(**cfg.get("asr", {}))
        self.cfg = cfg

    @property
    def max_speakers(self) -> int:
        return self.stdn.max_speakers

    def freeze(self, names: list[str]):
        for n in names:
            mod = getattr(self, n)
            mod.eval()
            for p in mod.parameters():
                p.requires_grad_(False)

    def train(self, mode: bool = True):
        super().train(mode)
        for n in ("stdn", "separator", "asr"):  # frozen modules stay in eval mode (dropout off)
            mod = getattr(self, n)
            if not any(p.requires_grad for p in mod.parameters()):
                mod.eval()
        return self

    # ------------------------------------------------------------------ training losses
    def compute_losses(self, batch: dict, use: dict, weights: dict) -> tuple[torch.Tensor, dict]:
        dev = batch["mix"].device
        mix, mix_len, n_spk = batch["mix"], batch["mix_len"], batch["n_spk"]
        B, N = mix.shape
        feat_len = mix_len // self.features.hop + 1
        feats = self.features(mix)
        diar = self.stdn(feats, feat_len)
        Tp = diar.activity_logits.shape[1]
        out_len = subsampled_length(feat_len)
        labels = batch["act_labels"][:, :Tp]
        kmax = int(n_spk.max())
        log: dict = {}

        est = None
        if (use.get("sep") or use.get("asr")) and kmax > 0:
            est = self.separator(mix, diar.attractors[:, :kmax], diar.activity_prob[:, :, :kmax])

        w_d, w_s = weights.get("assign_diar", 1.0), weights.get("assign_sep", 0.05)
        act_terms, sep_terms, perms = [], [], []
        for b in range(B):
            K = int(n_spk[b])
            if K == 0:
                perms.append(None)
                continue
            Tb, Nb = int(out_len[b]), int(mix_len[b])
            fmask = torch.ones(Tb, dtype=torch.bool, device=dev)
            bce = pairwise_bce(diar.activity_logits[b, :Tb, :K], labels[b, :Tb, :K], fmask)
            sdr = None
            cost = w_d * bce
            if est is not None:
                sdr = si_sdr(est[b, :K, None, :Nb], batch["sources"][b, None, :K, :Nb])  # (K, K)
                cost = cost - w_s * sdr
            perm = hungarian(cost)
            perms.append(perm)
            idx = torch.as_tensor(perm, device=dev)
            ref = torch.arange(K, device=dev)
            act_terms.append(bce[idx, ref].mean())
            if sdr is not None:
                sep_terms.append(sdr[idx, ref].mean())

        total = mix.new_zeros(())
        if use.get("diar"):
            l_act = torch.stack(act_terms).mean() if act_terms else mix.new_zeros(())
            l_exist = existence_loss(diar.exist_logits, n_spk)
            l_diar = finite_or_zero(l_act + l_exist, "diar", log)
            total = total + weights.get("lambda_diar", 1.0) * l_diar
            log.update(l_diar=l_diar.item(), l_act=l_act.item(), l_exist=l_exist.item())
        if use.get("sep") and sep_terms:
            l_sep = finite_or_zero(-torch.stack(sep_terms).mean(), "sep", log)
            total = total + weights.get("lambda_sep", 1.0) * l_sep
            log.update(l_sep=l_sep.item())
        if use.get("asr") and est is not None:
            streams, tgts, tlens, lens = [], [], [], []
            for b, perm in enumerate(perms):
                if perm is None:
                    continue
                for j, i in enumerate(perm):
                    streams.append(est[b, i])
                    tgts.append(batch["targets"][b, j])
                    tlens.append(batch["target_len"][b, j])
                    lens.append(mix_len[b])
            wav = rms_normalize(torch.stack(streams))
            lens_t = torch.stack(lens)
            tg, tl = torch.stack(tgts), torch.stack(tlens).to(dev)
            logits, a_len = self.asr(self.features(wav), lens_t // self.features.hop + 1)
            l_asr = finite_or_zero(ctc_loss(logits, a_len, tg, tl), "asr", log)
            total = total + weights.get("lambda_asr", 1.0) * l_asr
            log.update(l_asr=l_asr.item())
            w_clean = weights.get("lambda_asr_clean", 0.0)
            if w_clean:  # auxiliary multi-condition term on the clean references (not in the paper's
                # L_total; prevents the recogniser forgetting clean speech - docs/limitations.md)
                clean = [batch["sources"][b, j] for b, perm in enumerate(perms) if perm is not None
                         for j in range(len(perm))]
                lc, cl = self.asr(self.features(rms_normalize(torch.stack(clean))), lens_t // self.features.hop + 1)
                l_clean = finite_or_zero(ctc_loss(lc, cl, tg, tl), "asr_clean", log)
                total = total + w_clean * l_clean
                log.update(l_asr_clean=l_clean.item())
        log["total"] = total.item()
        return total, log
