"""Module 5: transcript aggregation (host side; operates on decoded text + metadata).

Input: per-speaker word lists with times (from CTC emission frames) and diarization
confidences. Output: chronologically ordered segments that may overlap in time - speakers
are never forced into one non-overlapping sequence."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

UNKNOWN_SPEAKER = "SPEAKER_UNK"


@dataclass
class Word:
    text: str
    start: float
    end: float


@dataclass
class Segment:
    start: float
    end: float
    speaker_id: str
    text: str
    confidence: float | None = None
    uncertain: bool = False
    words: list[Word] = field(default_factory=list)

    def to_dict(self, with_words: bool = False) -> dict:
        d = {"start": round(self.start, 3), "end": round(self.end, 3), "speaker_id": self.speaker_id,
             "text": self.text}
        if self.confidence is not None:
            d["confidence"] = round(self.confidence, 3)
        if self.uncertain:
            d["uncertain"] = True
        if with_words:
            d["words"] = [asdict(w) for w in self.words]
        return d


def speaker_label(idx: int | None) -> str:
    return UNKNOWN_SPEAKER if idx is None or idx < 0 else f"SPEAKER_{idx:02d}"


def tokens_to_words(chars: str, frames: list[int], frame_s: float, offset_s: float = 0.0) -> list[Word]:
    """Split a decoded character string into words with times from per-char frames."""
    words, cur, t0, t1 = [], [], None, None
    for c, f in zip(chars, frames):
        if c == " ":
            if cur:
                words.append(Word("".join(cur), t0, t1))
            cur, t0 = [], None
            continue
        if t0 is None:
            t0 = offset_s + f * frame_s
        cur.append(c)
        t1 = offset_s + (f + 1) * frame_s
    if cur:
        words.append(Word("".join(cur), t0, t1))
    return words


def words_to_segments(words: list[Word], speaker_id: str, max_gap: float = 0.6,
                      confidence: float | None = None, uncertain: bool = False) -> list[Segment]:
    segs: list[Segment] = []
    for w in sorted(words, key=lambda w: w.start):
        if segs and w.start - segs[-1].end <= max_gap:
            s = segs[-1]
            s.words.append(w)
            s.end = max(s.end, w.end)
            s.text = f"{s.text} {w.text}"
        else:
            segs.append(Segment(w.start, w.end, speaker_id, w.text, confidence, uncertain, [w]))
    return segs


def validate_segment(s: Segment, duration: float | None = None, tol: float = 1e-6) -> Segment:
    if not (s.start == s.start and s.end == s.end):  # NaN check
        raise ValueError(f"NaN timestamp in segment {s}")
    if s.end < s.start - tol:
        raise ValueError(f"segment ends before it starts: {s.start} > {s.end}")
    s.start = max(0.0, s.start)
    if duration is not None:
        s.end = min(s.end, duration)
        s.start = min(s.start, s.end)
    if not s.speaker_id:
        s.speaker_id, s.uncertain = UNKNOWN_SPEAKER, True
    return s


def aggregate(segments: list[Segment], duration: float | None = None, merge_gap: float = 0.6,
              dedup_overlap: float = 0.5) -> list[Segment]:
    """Validate, de-duplicate, merge same-speaker neighbours and sort chronologically.

    * Duplicate: same speaker, same text, temporal IoU >= dedup_overlap (e.g. a word emitted
      by two overlapping streaming blocks) -> keep one.
    * Merge: consecutive segments of the same speaker separated by <= merge_gap seconds.
    * Different speakers are never merged; their segments may overlap."""
    segs = [validate_segment(s, duration) for s in segments if s.text.strip()]
    segs.sort(key=lambda s: (s.speaker_id, s.start, s.end))
    kept: list[Segment] = []
    for s in segs:
        dup = False
        for k in reversed(kept[-4:]):
            if k.speaker_id != s.speaker_id:
                continue
            inter = max(0.0, min(k.end, s.end) - max(k.start, s.start))
            union = max(k.end, s.end) - min(k.start, s.start)
            if k.text == s.text and union > 0 and inter / union >= dedup_overlap:
                dup = True
                break
        if not dup:
            kept.append(s)
    merged: list[Segment] = []
    for s in kept:
        last = merged[-1] if merged else None
        if last and last.speaker_id == s.speaker_id and s.start - last.end <= merge_gap:
            last.end = max(last.end, s.end)
            last.text = f"{last.text} {s.text}"
            last.words += s.words
            last.uncertain = last.uncertain or s.uncertain
        else:
            merged.append(s)
    merged.sort(key=lambda s: (s.start, s.end, s.speaker_id))
    return merged


# ----------------------------------------------------------------------------- export
def to_json(segments: list[Segment], path: str | Path | None = None, with_words: bool = False) -> str:
    text = json.dumps([s.to_dict(with_words) for s in segments], indent=2)
    if path:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(text)
    return text


def to_text(segments: list[Segment]) -> str:
    return "\n".join(f"[{s.start:7.2f} - {s.end:7.2f}] {s.speaker_id}: {s.text}" for s in segments)


def _srt_time(t: float) -> str:
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def to_srt(segments: list[Segment]) -> str:
    return "\n".join(f"{i}\n{_srt_time(s.start)} --> {_srt_time(s.end)}\n[{s.speaker_id}] {s.text}\n"
                     for i, s in enumerate(segments, 1))
