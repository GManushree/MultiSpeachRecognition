"""Module 2B: attractor-conditioned time-domain separator (Conv-TasNet style).

mixture (B, N) -> learned encoder (Conv1d L=32, stride 16) -> bottleneck
-> for every attractor k (folded into the batch): TCN blocks whose hidden activations are
   FiLM-modulated by a_k (gamma_k * h + beta_k), with the speaker's upsampled activity
   p(t,k) appended as an extra bottleneck channel -> sigmoid mask_k
-> mask_k * encoded mixture -> transposed-conv decoder -> waveform_k (B, K, N).

Output stream k is *defined* by attractor k, so the separated stream carries the same
speaker index as the diarization output; no post-hoc matching is needed at inference."""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class GlobalLayerNorm(nn.Module):
    def __init__(self, ch: int):
        super().__init__()
        self.norm = nn.GroupNorm(1, ch, eps=1e-8)

    def forward(self, x):
        return self.norm(x)


class FiLMTCNBlock(nn.Module):
    def __init__(self, b: int, h: int, cond_dim: int, kernel: int, dilation: int):
        super().__init__()
        self.inp = nn.Conv1d(b, h, 1)
        self.act1, self.norm1 = nn.PReLU(), GlobalLayerNorm(h)
        self.dw = nn.Conv1d(h, h, kernel, dilation=dilation, padding=dilation * (kernel - 1) // 2, groups=h)
        self.act2, self.norm2 = nn.PReLU(), GlobalLayerNorm(h)
        self.film = nn.Linear(cond_dim, 2 * h)
        # near-identity modulation (gamma~1, beta~0); weights must not be exactly zero or no
        # gradient would reach the attractors at initialisation
        nn.init.normal_(self.film.weight, std=1e-2)
        nn.init.zeros_(self.film.bias)
        self.out = nn.Conv1d(h, b, 1)

    def forward(self, x, cond):
        y = self.norm1(self.act1(self.inp(x)))
        y = self.norm2(self.act2(self.dw(y)))
        gamma, beta = self.film(cond).chunk(2, -1)
        y = (1 + gamma)[..., None] * y + beta[..., None]
        return x + self.out(y)


class AttractorConditionedSeparator(nn.Module):
    def __init__(self, enc_dim: int = 128, kernel: int = 32, stride: int = 16, bottleneck: int = 128,
                 hidden: int = 256, n_blocks: int = 4, n_repeats: int = 2, cond_dim: int = 256,
                 tcn_kernel: int = 3):
        super().__init__()
        self.kernel, self.stride = kernel, stride
        self.encoder = nn.Conv1d(1, enc_dim, kernel, stride=stride, bias=False)
        self.in_norm = GlobalLayerNorm(enc_dim)
        self.bottleneck = nn.Conv1d(enc_dim + 1, bottleneck, 1)
        self.cond_proj = nn.Sequential(nn.Linear(cond_dim, cond_dim), nn.PReLU())
        self.blocks = nn.ModuleList(FiLMTCNBlock(bottleneck, hidden, cond_dim, tcn_kernel, 2 ** i)
                                    for _ in range(n_repeats) for i in range(n_blocks))
        self.mask = nn.Conv1d(bottleneck, enc_dim, 1)
        self.decoder = nn.ConvTranspose1d(enc_dim, 1, kernel, stride=stride, bias=False)

    def _pad(self, n: int) -> int:
        target = max(self.kernel, n)
        return target - n + (-(target - self.kernel)) % self.stride

    def forward(self, mixture: torch.Tensor, attractors: torch.Tensor,
                activity: torch.Tensor | None = None) -> torch.Tensor:
        """mixture (B, N); attractors (B, K, D); activity (B, T', K) probabilities or None.
        Returns (B, K, N) separated waveforms (one per attractor)."""
        B, N = mixture.shape
        K = attractors.shape[1]
        pad = self._pad(N)
        x = F.pad(mixture, (0, pad))[:, None]
        w = F.relu(self.encoder(x))                       # (B, C, L)
        L = w.shape[-1]
        e = self.in_norm(w)
        if activity is None:
            act = e.new_ones(B, K, L)
        else:
            act = F.interpolate(activity.transpose(1, 2).float(), size=L, mode="linear", align_corners=False)
        e_k = e[:, None].expand(B, K, *e.shape[1:]).reshape(B * K, e.shape[1], L)
        h = self.bottleneck(torch.cat([e_k, act.reshape(B * K, 1, L).to(e_k.dtype)], 1))
        cond = self.cond_proj(attractors.reshape(B * K, -1))
        for blk in self.blocks:
            h = blk(h, cond)
        m = torch.sigmoid(self.mask(h))
        w_k = w[:, None].expand(B, K, *w.shape[1:]).reshape(B * K, w.shape[1], L)
        out = self.decoder(m * w_k)[..., :N]
        return out.reshape(B, K, N)
