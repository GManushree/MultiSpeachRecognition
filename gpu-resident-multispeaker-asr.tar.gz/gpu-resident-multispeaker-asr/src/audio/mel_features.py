"""Module 1: log-Mel feature extraction.

Two independent implementations of the same definition:
  * `reference_log_mel` - NumPy/SciPy, float64, used only for validation.
  * `LogMel` - PyTorch module; batched STFT + Mel projection on whatever device the
    input lives on (GPU when available). Differentiable, so the ASR loss can flow back
    into the separator during joint training. Optionally uses the fused C++/CUDA kernel
    from `src.audio.cuda_features` for the power->Mel->log stage (inference only).

Definition (shared): 16 kHz input, 25 ms periodic Hann window (n_fft=400), 10 ms hop,
center=True with reflect padding, power spectrum, 80 HTK-scale triangular Mel filters
over 0-8 kHz without area normalization, feature = log(mel + 1e-6).
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

LOG_EPS = 1e-6


def hz_to_mel(f):
    return 2595.0 * np.log10(1.0 + np.asarray(f, dtype=np.float64) / 700.0)


def mel_to_hz(m):
    return 700.0 * (10.0 ** (np.asarray(m, dtype=np.float64) / 2595.0) - 1.0)


def mel_filterbank(sr: int = 16000, n_fft: int = 400, n_mels: int = 80,
                   fmin: float = 0.0, fmax: float | None = None) -> np.ndarray:
    """(n_freq, n_mels) triangular HTK filterbank, float64."""
    fmax = fmax or sr / 2
    n_freq = n_fft // 2 + 1
    freqs = np.linspace(0, sr / 2, n_freq)
    pts = mel_to_hz(np.linspace(hz_to_mel(fmin), hz_to_mel(fmax), n_mels + 2))
    fb = np.zeros((n_freq, n_mels))
    for m in range(n_mels):
        lo, c, hi = pts[m], pts[m + 1], pts[m + 2]
        up = (freqs - lo) / (c - lo)
        down = (hi - freqs) / (hi - c)
        fb[:, m] = np.maximum(0.0, np.minimum(up, down))
    return fb


def reference_log_mel(x: np.ndarray, sr: int = 16000, n_fft: int = 400, hop: int = 160,
                      n_mels: int = 80) -> np.ndarray:
    """NumPy reference. x: (N,) -> (n_mels, T) with T = 1 + N // hop."""
    x = np.asarray(x, dtype=np.float64)
    pad = n_fft // 2
    xp = np.pad(x, (pad, pad), mode="reflect")
    T = 1 + (len(xp) - n_fft) // hop
    idx = np.arange(n_fft)[None, :] + hop * np.arange(T)[:, None]
    win = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(n_fft) / n_fft)  # periodic Hann
    spec = np.fft.rfft(xp[idx] * win, axis=1)
    power = spec.real ** 2 + spec.imag ** 2                           # (T, F)
    return np.log(power @ mel_filterbank(sr, n_fft, n_mels) + LOG_EPS).T


class LogMel(nn.Module):
    def __init__(self, sr: int = 16000, n_fft: int = 400, hop: int = 160, n_mels: int = 80,
                 use_fused_kernel: bool = False):
        super().__init__()
        self.sr, self.n_fft, self.hop, self.n_mels = sr, n_fft, hop, n_mels
        fb = mel_filterbank(sr, n_fft, n_mels)
        self.register_buffer("fb", torch.tensor(fb.T, dtype=torch.float32), persistent=False)
        self.register_buffer("window", torch.hann_window(n_fft, periodic=True), persistent=False)
        nz = fb > 0
        self.register_buffer("band_lo", torch.tensor(nz.argmax(0), dtype=torch.int32), persistent=False)
        self.register_buffer("band_hi", torch.tensor(len(fb) - nz[::-1].argmax(0), dtype=torch.int32),
                             persistent=False)
        self.use_fused_kernel = use_fused_kernel

    def num_frames(self, n_samples: torch.Tensor | int):
        return n_samples // self.hop + 1

    def forward(self, wav: torch.Tensor) -> torch.Tensor:
        """wav: (..., N) float -> (..., n_mels, T). Runs on wav.device; batched over leading dims."""
        if wav.shape[-1] <= self.n_fft // 2:
            raise ValueError(f"waveform too short for STFT ({wav.shape[-1]} samples)")
        lead = wav.shape[:-1]
        x = wav.reshape(-1, wav.shape[-1]).float()   # STFT is numerically sensitive: FP32
        spec = torch.stft(x, self.n_fft, self.hop, window=self.window, center=True,
                          pad_mode="reflect", return_complex=True)          # (B, F, T)
        if self.use_fused_kernel and not torch.is_grad_enabled():
            from src.audio.cuda_features import fused_log_mel
            out = fused_log_mel(torch.view_as_real(spec).contiguous(), self.fb, self.band_lo,
                                self.band_hi, LOG_EPS)
        else:
            power = spec.real.square() + spec.imag.square()
            out = torch.log(torch.matmul(self.fb, power) + LOG_EPS)
        return out.reshape(*lead, self.n_mels, out.shape[-1])
