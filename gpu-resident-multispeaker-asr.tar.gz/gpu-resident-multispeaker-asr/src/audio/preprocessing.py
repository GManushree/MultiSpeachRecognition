"""Waveform normalization and block segmentation for offline/streaming processing."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def peak_normalize(x: np.ndarray, peak: float = 0.9, eps: float = 1e-8) -> np.ndarray:
    m = float(np.abs(x).max()) if x.size else 0.0
    return x if m < eps else (x * (peak / m)).astype(np.float32)


@dataclass
class Block:
    index: int
    start_sample: int      # absolute position of the block's emitted region
    end_sample: int
    ctx_start: int         # absolute position of the first sample incl. left context
    audio: np.ndarray      # samples [ctx_start, end_sample)


def iter_blocks(x: np.ndarray, sr: int, block_s: float, hop_s: float | None = None,
                left_context_s: float = 0.0):
    """Yield blocks of `block_s` seconds every `hop_s` seconds, each carrying up to
    `left_context_s` of preceding audio. The last block is zero-padded to full length
    so models see a fixed shape; `end_sample` marks the real end."""
    if block_s <= 0:
        raise ValueError("block_s must be > 0")
    hop_s = hop_s or block_s
    B, H, L = int(round(block_s * sr)), int(round(hop_s * sr)), int(round(left_context_s * sr))
    n = x.shape[-1]
    i, s = 0, 0
    while s < n:
        e = min(s + B, n)
        cs = max(0, s - L)
        seg = x[..., cs:e]
        pad = (s + B) - e
        if pad > 0:
            seg = np.pad(seg, [(0, 0)] * (seg.ndim - 1) + [(0, pad)])
        yield Block(i, s, e, cs, seg.astype(np.float32))
        i += 1
        s += H
