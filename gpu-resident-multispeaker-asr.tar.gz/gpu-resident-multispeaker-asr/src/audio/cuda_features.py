"""Thin wrapper around the compiled fused log-Mel extension (src/cuda)."""
from __future__ import annotations

import torch

from src.cuda.build import load_extension


def fused_log_mel(spec_ri: torch.Tensor, fb: torch.Tensor, band_lo: torch.Tensor,
                  band_hi: torch.Tensor, eps: float) -> torch.Tensor:
    """spec_ri: (B, F, T, 2) float32 on CPU or CUDA -> (B, M, T). No autograd support:
    LogMel only routes here under torch.no_grad() (inference)."""
    return load_extension().fused_log_mel(spec_ri, fb, band_lo, band_hi, eps)
