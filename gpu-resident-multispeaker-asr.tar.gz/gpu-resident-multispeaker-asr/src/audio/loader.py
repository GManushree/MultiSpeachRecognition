"""Audio loading, validation and sample-rate normalization."""
from __future__ import annotations

from math import gcd
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly


class AudioError(ValueError):
    """Raised for unreadable, empty or otherwise invalid audio."""


def resample(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    """Polyphase resampling along the last axis (exact rational ratio)."""
    if sr_in == sr_out:
        return x
    g = gcd(sr_in, sr_out)
    return resample_poly(x, sr_out // g, sr_in // g, axis=-1).astype(np.float32)


def validate_waveform(x: np.ndarray, min_samples: int = 1) -> np.ndarray:
    if x.ndim not in (1, 2):
        raise AudioError(f"expected 1-D or 2-D audio, got shape {x.shape}")
    if x.shape[-1] < min_samples:
        raise AudioError(f"audio too short: {x.shape[-1]} samples")
    if not np.isfinite(x).all():
        raise AudioError("audio contains NaN or Inf")
    return x


def load_audio(path: str | Path, target_sr: int = 16000, mono: bool = True,
               channel: int | None = None) -> np.ndarray:
    """Load audio as float32 in [-1, 1].

    Multichannel input: `channel=i` selects one channel; otherwise `mono=True` averages
    channels (the system is single-channel internally; see docs/limitations.md)."""
    try:
        x, sr = sf.read(str(path), dtype="float32", always_2d=True)
    except (RuntimeError, sf.LibsndfileError) as e:
        raise AudioError(f"cannot read {path}: {e}") from e
    x = x.T  # (C, N)
    if channel is not None:
        if not 0 <= channel < x.shape[0]:
            raise AudioError(f"channel {channel} out of range for {x.shape[0]} channels")
        x = x[channel]
    elif mono:
        x = x.mean(0)
    x = resample(x, sr, target_sr)
    return validate_waveform(np.ascontiguousarray(x, dtype=np.float32))


def load_bytes(data: bytes, target_sr: int = 16000) -> np.ndarray:
    import io
    try:
        x, sr = sf.read(io.BytesIO(data), dtype="float32", always_2d=True)
    except (RuntimeError, sf.LibsndfileError) as e:
        raise AudioError(f"cannot decode audio: {e}") from e
    return validate_waveform(resample(x.T.mean(0), sr, target_sr).astype(np.float32))


def save_audio(path: str | Path, x: np.ndarray, sr: int = 16000) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(path), np.clip(x, -1, 1), sr, subtype="PCM_16")
