"""In-process speech synthesis with eSpeak NG (GPL-3, via the `espeakng-loader` wheel).

Used only to build the synthetic overlapping-speech development corpus: it yields real
speech waveforms with exactly known transcripts and speaker identities. A "speaker" is a
fixed (voice, variant, pitch, rate) tuple. Synthetic TTS speech is far more regular than
human speech; results on it say nothing about AMI/CHiME-7 performance."""
from __future__ import annotations

import ctypes
import threading
from dataclasses import dataclass

import numpy as np

from src.audio.loader import resample

_LOCK = threading.Lock()
_STATE: dict = {}

ESPEAK_RATE, ESPEAK_PITCH, ESPEAK_RANGE = 1, 3, 4


@dataclass(frozen=True)
class Voice:
    speaker_id: str
    language: str
    variant: str
    pitch: int
    rate: int
    pitch_range: int = 50

    @property
    def name(self) -> str:
        return f"{self.language}+{self.variant}"


def _init():
    if _STATE:
        return _STATE
    try:
        import espeakng_loader as el
    except ImportError as e:
        raise RuntimeError("pip install espeakng-loader to synthesize the development corpus") from e
    lib = ctypes.CDLL(el.get_library_path())
    cb_type = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_short), ctypes.c_int, ctypes.c_void_p)
    chunks: list = []

    def _cb(wav, n, _events):
        if wav and n > 0:
            chunks.append(np.ctypeslib.as_array(wav, (n,)).copy())
        return 0

    cb = cb_type(_cb)
    sr = lib.espeak_Initialize(1, 0, el.get_data_path().encode(), 0)  # AUDIO_OUTPUT_RETRIEVAL
    if sr <= 0:
        raise RuntimeError("espeak_Initialize failed")
    lib.espeak_SetSynthCallback(cb)
    _STATE.update(lib=lib, cb=cb, chunks=chunks, sr=sr)
    return _STATE


def synthesize(text: str, voice: Voice, sr_out: int = 16000, trim_db: float = -40.0) -> np.ndarray:
    """Return float32 mono speech at `sr_out`, with leading/trailing silence trimmed."""
    with _LOCK:
        st = _init()
        lib = st["lib"]
        if lib.espeak_SetVoiceByName(voice.name.encode()) != 0:
            raise RuntimeError(f"unknown espeak voice {voice.name}")
        lib.espeak_SetParameter(ESPEAK_RATE, voice.rate, 0)
        lib.espeak_SetParameter(ESPEAK_PITCH, voice.pitch, 0)
        lib.espeak_SetParameter(ESPEAK_RANGE, voice.pitch_range, 0)
        st["chunks"].clear()
        b = text.encode()
        lib.espeak_Synth(b, len(b) + 1, 0, 1, 0, 0, None, None)
        lib.espeak_Synchronize()
        if not st["chunks"]:
            raise RuntimeError(f"espeak produced no audio for {text!r}")
        x = np.concatenate(st["chunks"]).astype(np.float32) / 32768.0
        sr_in = st["sr"]
    x = resample(x, sr_in, sr_out)
    frame = sr_out // 100
    e = np.array([np.mean(x[i:i + frame] ** 2) for i in range(0, len(x), frame)]) + 1e-12
    on = np.where(10 * np.log10(e / e.max()) > trim_db)[0]
    if len(on):
        x = x[on[0] * frame: (on[-1] + 1) * frame]
    return x.astype(np.float32)


LANGS = ["en-us", "en", "en-gb-x-rp", "en-gb-scotland", "en-us-nyc", "en-029"]
VARIANTS = ["m1", "m2", "m3", "m4", "m5", "m6", "m7", "f1", "f2", "f3", "f4", "f5"]


def speaker_pool(n: int = 36, seed: int = 0) -> list[Voice]:
    """Deterministic pool of distinct synthetic speakers."""
    rng = np.random.RandomState(seed)
    combos = [(lang, var) for var in VARIANTS for lang in LANGS]
    rng.shuffle(combos)
    voices = []
    for i, (lang, var) in enumerate(combos[:n]):
        female = var.startswith("f")
        voices.append(Voice(f"tts{i:03d}", lang, var,
                            pitch=int(rng.randint(55, 85) if female else rng.randint(25, 60)),
                            rate=int(rng.randint(115, 146)), pitch_range=int(rng.randint(30, 70))))
    return voices
