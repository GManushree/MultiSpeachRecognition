"""Synthetic sentence generator for the TTS development corpus (meeting-flavoured)."""
from __future__ import annotations

import numpy as np

SUBJECTS = ["the team", "the manager", "our client", "the design group", "my colleague", "the new intern",
            "the board", "the engineer", "the vendor", "everyone", "the project lead", "the sales team",
            "the reviewer", "our partner", "the committee", "the analyst"]
VERBS = ["reviewed", "approved", "rejected", "finished", "started", "delayed", "changed", "discussed",
         "tested", "shipped", "planned", "moved", "cancelled", "updated", "checked", "signed"]
OBJECTS = ["the budget", "the report", "the schedule", "the contract", "the prototype", "the proposal",
           "the slides", "the release", "the meeting", "the survey", "the invoice", "the roadmap",
           "the demo", "the feedback", "the agenda", "the design", "the plan", "the order"]
TIMES = ["yesterday", "today", "this morning", "last week", "on monday", "on friday", "after lunch",
         "before the deadline", "this afternoon", "next month", "again", "quickly"]
OPENERS = ["i think", "maybe", "honestly", "well", "so", "actually", "okay", "right", "you know",
           "i believe", "apparently", "i guess"]
QUESTIONS = ["can we talk about", "should we move", "who is handling", "did anyone see", "when do we review",
             "where is", "what happened to", "could you send"]
REPLIES = ["yes that sounds good", "no i don't think so", "let me check", "i agree with that",
           "we need more time", "that works for me", "i'm not sure", "good point", "let's do it",
           "thanks for the update", "i can take that", "send it to me please"]


def sentence(rng: np.random.RandomState) -> str:
    r = rng.rand()
    if r < 0.5:
        s = f"{rng.choice(SUBJECTS)} {rng.choice(VERBS)} {rng.choice(OBJECTS)}"
        if rng.rand() < 0.6:
            s += f" {rng.choice(TIMES)}"
        if rng.rand() < 0.4:
            s = f"{rng.choice(OPENERS)} {s}"
    elif r < 0.75:
        s = f"{rng.choice(QUESTIONS)} {rng.choice(OBJECTS)}"
        if rng.rand() < 0.4:
            s += f" {rng.choice(TIMES)}"
    else:
        s = str(rng.choice(REPLIES))
    return s
