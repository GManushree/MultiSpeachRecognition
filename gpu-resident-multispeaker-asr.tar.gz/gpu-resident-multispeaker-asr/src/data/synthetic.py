"""Synthetic overlapping-speech corpus generator (development and testing only).

For each mixture: draw K speakers (speaker-disjoint across splits), one sentence each,
synthesize, scale by a random relative gain, place them with a controlled overlap ratio,
sum, add low-level white noise. Saved per mixture:
  mix.wav, s{j}.wav (scaled, unpadded source j), and a manifest line with speaker ids,
  transcripts, offsets, VAD-derived speech segments and the measured overlap ratio.
Reference speaker activity is computed from the *source* signals (energy VAD), so it is
exact up to the VAD threshold - not estimated from the mixture."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from src.audio.loader import save_audio
from src.data.text import sentence
from src.data.tts import speaker_pool, synthesize


def vad_segments(x: np.ndarray, sr: int, offset_s: float = 0.0, frame_s: float = 0.01,
                 thresh_db: float = -35.0, min_gap_s: float = 0.15, min_len_s: float = 0.05):
    """Energy VAD relative to the signal's own peak frame energy -> [[start, end], ...] seconds."""
    f = int(sr * frame_s)
    n = len(x) // f
    if n == 0:
        return []
    e = (x[: n * f].reshape(n, f) ** 2).mean(1) + 1e-12
    on = 10 * np.log10(e / e.max()) > thresh_db
    segs, start = [], None
    for i, v in enumerate(np.append(on, False)):
        if v and start is None:
            start = i
        elif not v and start is not None:
            segs.append([start * frame_s, i * frame_s])
            start = None
    merged = []
    for s in segs:
        if merged and s[0] - merged[-1][1] < min_gap_s:
            merged[-1][1] = s[1]
        else:
            merged.append(s)
    return [[round(a + offset_s, 3), round(b + offset_s, 3)] for a, b in merged if b - a >= min_len_s]


def overlap_ratio(speakers: list[dict]) -> float:
    """Overlapped speech time / total speech time, from the VAD segments (10 ms grid)."""
    if not speakers:
        return 0.0
    end = max(s[1] for spk in speakers for s in spk["segments"]) if any(spk["segments"] for spk in speakers) else 0
    grid = np.zeros(int(end * 100) + 2, dtype=np.int32)
    for spk in speakers:
        for a, b in spk["segments"]:
            grid[int(round(a * 100)): int(round(b * 100))] += 1
    speech = (grid > 0).sum()
    return float((grid > 1).sum() / speech) if speech else 0.0


def split_speakers(n_speakers: int, seed: int, fractions=(0.67, 0.165, 0.165)):
    pool = speaker_pool(n_speakers, seed)
    n_tr = int(round(fractions[0] * n_speakers))
    n_va = int(round(fractions[1] * n_speakers))
    return {"train": pool[:n_tr], "val": pool[n_tr:n_tr + n_va], "test": pool[n_tr + n_va:]}


def make_mixture(rng, voices, k: int, target_overlap: float, sr: int, gain_db: float,
                 noise_snr_db: float, lead_s: float = 0.2, tail_s: float = 0.2,
                 max_len_s: float = 9.0):
    chosen = [voices[i] for i in rng.choice(len(voices), size=k, replace=False)] if k else []
    srcs, speakers = [], []
    cursor = lead_s
    for j, v in enumerate(chosen):
        text = sentence(rng)
        x = synthesize(text, v, sr)
        g = 10 ** (rng.uniform(-gain_db, gain_db) / 20) if j else 1.0
        x = (x * g * 0.3 / (np.abs(x).max() + 1e-8)).astype(np.float32)
        dur = len(x) / sr
        if j == 0:
            start = cursor
        else:
            prev = speakers[-1]
            ov = target_overlap * min(prev["duration"], dur)
            start = max(lead_s, prev["offset"] + prev["duration"] - ov)
        speakers.append({"speaker_id": v.speaker_id, "text": text, "offset": round(start, 4),
                         "duration": round(dur, 4)})
        srcs.append(x)
    total_s = max([s["offset"] + s["duration"] for s in speakers], default=rng.uniform(2.0, 4.0)) + tail_s
    if total_s > max_len_s:
        return None
    n = int(round(total_s * sr))
    mix = np.zeros(n, dtype=np.float32)
    for s, x in zip(speakers, srcs):
        o = int(round(s["offset"] * sr))
        mix[o:o + len(x)] += x
        s["segments"] = vad_segments(x, sr, s["offset"])
    sig_pow = np.mean(mix ** 2) if k else 1e-4
    mix += (rng.randn(n) * np.sqrt(sig_pow / 10 ** (noise_snr_db / 10))).astype(np.float32)
    return mix, srcs, speakers, total_s


def generate_split(out_dir: Path, split: str, voices, n_mix: int, sr: int, seed: int,
                   k_probs: dict, overlap_range: tuple, gain_db: float, noise_snr_db: float,
                   fixed_k: int | None = None, fixed_overlap: float | None = None,
                   tag: str | None = None) -> Path:
    rng = np.random.RandomState(seed)
    name = tag or split
    wav_dir = out_dir / name
    manifest = out_dir / f"{name}.jsonl"
    ks, ps = zip(*sorted((int(k), p) for k, p in k_probs.items()))
    ps = np.asarray(ps) / np.sum(ps)
    rows, i = [], 0
    while len(rows) < n_mix:
        k = fixed_k if fixed_k is not None else int(rng.choice(ks, p=ps))
        ov = fixed_overlap if fixed_overlap is not None else rng.uniform(*overlap_range)
        res = make_mixture(rng, voices, k, ov, sr, gain_db, noise_snr_db)
        i += 1
        if res is None:
            continue
        mix, srcs, speakers, total = res
        mid = f"{name}_{len(rows):05d}"
        d = wav_dir / mid
        save_audio(d / "mix.wav", mix, sr)
        for j, x in enumerate(srcs):
            save_audio(d / f"s{j}.wav", x, sr)
            speakers[j]["path"] = str((d / f"s{j}.wav").relative_to(out_dir))
        rows.append({"id": mid, "split": split, "mix_path": str((d / "mix.wav").relative_to(out_dir)),
                     "duration": round(total, 4), "sample_rate": sr, "n_speakers": k,
                     "target_overlap": round(float(ov), 3), "overlap_ratio": round(overlap_ratio(speakers), 4),
                     "speakers": speakers})
    with open(manifest, "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    return manifest


def generate_corpus(cfg: dict, root: Path) -> dict:
    """cfg = training.yaml `data.synthetic` section."""
    root.mkdir(parents=True, exist_ok=True)
    sr = cfg.get("sample_rate", 16000)
    splits = split_speakers(cfg["n_speakers"], cfg["seed"])
    common = dict(sr=sr, k_probs=cfg["k_probs"], overlap_range=tuple(cfg["overlap_range"]),
                  gain_db=cfg["gain_db"], noise_snr_db=cfg["noise_snr_db"])
    out = {}
    for i, (split, n) in enumerate(cfg["n_mixtures"].items()):
        out[split] = str(generate_split(root, split, splits[split], n, seed=cfg["seed"] + 101 * (i + 1), **common))
    for j, ab in enumerate(cfg.get("ablation_sets", [])):  # fixed-K / fixed-overlap test sets
        tag = f"test_k{ab['k']}_ov{int(round(ab['overlap'] * 100)):02d}"
        out[tag] = str(generate_split(root, "test", splits["test"], ab["n"], seed=cfg["seed"] + 7000 + j,
                                      fixed_k=ab["k"], fixed_overlap=ab["overlap"], tag=tag, **common))
    meta = {"speakers": {s: [v.__dict__ for v in vs] for s, vs in splits.items()}, "manifests": out,
            "config": cfg}
    (root / "corpus_meta.json").write_text(json.dumps(meta, indent=2))
    return meta
