"""AMI Meeting Corpus adapter -> common JSONL manifest.

Expected local layout (download separately; AMI is CC BY 4.0 and requires accepting its
terms at https://groups.inf.ed.ac.uk/ami/download/):
  <ami_root>/amicorpus/<MEETING>/audio/<MEETING>.Mix-Headset.wav   (or Array1-01 for SDM)
  <ami_root>/annotations/words/<MEETING>.<SPK>.words.xml          (NXT manual annotations)
  <ami_root>/annotations/segments/<MEETING>.<SPK>.segments.xml    (optional)

Words are grouped into utterance segments (gap > `max_gap_s` starts a new segment), and
recordings are cut into windows of `window_s` seconds for training. The official
"full-corpus-ASR" partition lists are used for splits (train/dev/eval), so speakers and
meetings follow the standard protocol. This adapter was NOT run in the development
environment (corpus not downloadable there); it is covered by unit tests on a tiny
synthetic NXT-format fixture only."""
from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import soundfile as sf

from src.audio.loader import save_audio
from src.models.asr import CharTokenizer

# Official AMI full-corpus-ASR dev/eval meetings; everything else with annotations is train.
AMI_DEV = ["ES2011", "IS1008", "TS3004", "IB4001", "IB4002", "IB4003", "IB4004", "IB4010", "IB4011"]
AMI_EVAL = ["ES2004", "IS1009", "TS3003", "EN2002"]


def ami_split(meeting: str) -> str:
    base = meeting[:6]
    if base in AMI_EVAL:
        return "test"
    if base in AMI_DEV or meeting[:6] in AMI_DEV:
        return "val"
    return "train"


def parse_words_xml(path: Path) -> list[tuple[float, float, str]]:
    """NXT words file -> [(start, end, word)] for <w> elements with times (punctuation dropped)."""
    out = []
    for el in ET.parse(path).getroot().iter():
        if el.tag.endswith("w") and el.get("starttime") and el.get("endtime") and el.get("punc") != "true":
            w = (el.text or "").strip()
            if w:
                out.append((float(el.get("starttime")), float(el.get("endtime")), w))
    return sorted(out)


def words_to_utterances(words, max_gap_s: float = 0.5):
    utts = []
    for s, e, w in words:
        if utts and s - utts[-1][1] <= max_gap_s:
            utts[-1][1] = e
            utts[-1][2].append(w)
        else:
            utts.append([s, e, [w]])
    return [(s, e, " ".join(ws)) for s, e, ws in utts]


def build_ami_manifest(ami_root: str | Path, out_dir: str | Path, mic: str = "Mix-Headset",
                       window_s: float = 8.0, max_spk: int = 4, sr: int = 16000) -> dict:
    ami_root, out_dir = Path(ami_root), Path(out_dir)
    tok = CharTokenizer()
    words_dir = ami_root / "annotations" / "words"
    if not words_dir.exists():
        raise FileNotFoundError(f"AMI annotations not found under {words_dir}; see module docstring")
    meetings = sorted({p.name.split(".")[0] for p in words_dir.glob("*.words.xml")})
    rows = {"train": [], "val": [], "test": []}
    missing = []
    for m in meetings:
        wav = ami_root / "amicorpus" / m / "audio" / f"{m}.{mic}.wav"
        if not wav.exists():
            missing.append(str(wav))
            continue
        spk_utts = {}
        for wf in sorted(words_dir.glob(f"{m}.*.words.xml")):
            spk = f"{m}_{wf.name.split('.')[1]}"
            spk_utts[spk] = words_to_utterances(parse_words_xml(wf))
        x, file_sr = sf.read(str(wav), dtype="float32", always_2d=True)
        x = x.mean(1)
        if file_sr != sr:
            from src.audio.loader import resample
            x = resample(x, file_sr, sr)
        total = len(x) / sr
        for wi, w0 in enumerate(np.arange(0, total - 1.0, window_s)):
            w1 = min(total, w0 + window_s)
            speakers = []
            for spk, utts in spk_utts.items():
                inside = [(max(s, w0), min(e, w1), t) for s, e, t in utts if s < w1 and e > w0]
                # only utterances fully inside the window keep their transcript; cut ones are
                # still marked active for diarization but excluded from WER (text="")
                full = [(s, e, t) for s, e, t in utts if s >= w0 and e <= w1]
                if inside:
                    speakers.append({"speaker_id": spk, "text": " ".join(tok.normalize(t) for _, _, t in full),
                                     "offset": round(inside[0][0] - w0, 3), "duration": round(inside[-1][1] - inside[0][0], 3),
                                     "segments": [[round(s - w0, 3), round(e - w0, 3)] for s, e, _ in inside]})
            if len(speakers) > max_spk:
                continue
            mid = f"ami_{m}_{wi:04d}"
            rel = Path("ami") / m / f"{mid}.wav"
            save_audio(out_dir / rel, x[int(w0 * sr): int(w1 * sr)], sr)
            rows[ami_split(m)].append({"id": mid, "split": ami_split(m), "mix_path": str(rel),
                                       "duration": round(w1 - w0, 3), "sample_rate": sr,
                                       "n_speakers": len(speakers), "speakers": speakers, "corpus": "AMI",
                                       "mic": mic, "has_sources": False})
    out = {}
    for split, rs in rows.items():
        p = out_dir / f"ami_{split}.jsonl"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("".join(json.dumps(r) + "\n" for r in rs))
        out[split] = str(p)
    return {"manifests": out, "missing_audio": missing, "meetings": len(meetings)}
