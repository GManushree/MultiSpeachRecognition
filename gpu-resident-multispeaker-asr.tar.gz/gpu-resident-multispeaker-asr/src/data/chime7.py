"""CHiME-7 DASR adapter -> common JSONL manifest.

CHiME-7 DASR distributes CHiME-6, DiPCo and Mixer 6 under one convention (prepared with
the official `chime7_dasr` scripts / `gss`): per session a JSON transcription list
  [{"session_id", "speaker", "start_time", "end_time", "words"}, ...]
under  <root>/<scenario>/transcriptions/<split>/<session>.json  and audio under
  <root>/<scenario>/audio/<split>/<session>_<mic>.wav (or *_CH*.wav for arrays).
The official metric is the macro-averaged time-constrained minimum-permutation WER
(tcpWER, via `meeteval`) plus DER/JER; this adapter only produces manifests and the
reference segments those scorers need. `start_time`/`end_time` may be strings (CHiME-6)
or floats. Not run in the development environment (data unavailable); unit-tested on a
tiny fixture only. No annotations are invented: windows without reference are dropped."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import soundfile as sf

from src.audio.loader import resample, save_audio
from src.models.asr import CharTokenizer

SCENARIOS = ("chime6", "dipco", "mixer6")
SPLIT_MAP = {"train": "train", "dev": "val", "eval": "test"}


def _t(v) -> float:
    if isinstance(v, (int, float)):
        return float(v)
    if ":" in v:  # CHiME-6 "HH:MM:SS.ss"
        h, m, s = v.split(":")
        return int(h) * 3600 + int(m) * 60 + float(s)
    return float(v)


def build_chime7_manifest(root: str | Path, out_dir: str | Path, scenario: str = "chime6",
                          split: str = "dev", mic_glob: str = "*.wav", window_s: float = 8.0,
                          max_spk: int = 4, sr: int = 16000) -> dict:
    if scenario not in SCENARIOS:
        raise ValueError(f"scenario must be one of {SCENARIOS}")
    root, out_dir = Path(root), Path(out_dir)
    tdir = root / scenario / "transcriptions" / split
    if not tdir.exists():
        raise FileNotFoundError(f"{tdir} not found; prepare CHiME-7 DASR with the official scripts")
    tok = CharTokenizer()
    rows, missing = [], []
    for tf in sorted(tdir.glob("*.json")):
        sess = tf.stem
        utts = json.loads(tf.read_text())
        wavs = sorted((root / scenario / "audio" / split).glob(f"{sess}_{mic_glob}"))
        if not wavs:
            missing.append(sess)
            continue
        x, fsr = sf.read(str(wavs[0]), dtype="float32", always_2d=True)
        x = resample(x[:, 0], fsr, sr)
        total = len(x) / sr
        for wi, w0 in enumerate(np.arange(0, total - 1.0, window_s)):
            w1 = min(total, w0 + window_s)
            by_spk: dict = {}
            for u in utts:
                s, e = _t(u["start_time"]), _t(u["end_time"])
                if s < w1 and e > w0:
                    d = by_spk.setdefault(u["speaker"], {"segs": [], "text": []})
                    d["segs"].append([round(max(s, w0) - w0, 3), round(min(e, w1) - w0, 3)])
                    if s >= w0 and e <= w1:
                        d["text"].append(tok.normalize(u["words"]))
            if not by_spk or len(by_spk) > max_spk:
                continue
            speakers = [{"speaker_id": f"{scenario}_{k}", "text": " ".join(v["text"]),
                         "offset": v["segs"][0][0], "duration": round(v["segs"][-1][1] - v["segs"][0][0], 3),
                         "segments": v["segs"]} for k, v in sorted(by_spk.items())]
            mid = f"{scenario}_{sess}_{wi:04d}"
            rel = Path("chime7") / scenario / f"{mid}.wav"
            save_audio(out_dir / rel, x[int(w0 * sr): int(w1 * sr)], sr)
            rows.append({"id": mid, "split": SPLIT_MAP.get(split, split), "mix_path": str(rel),
                         "duration": round(w1 - w0, 3), "sample_rate": sr, "n_speakers": len(speakers),
                         "speakers": speakers, "corpus": f"CHiME-7/{scenario}", "has_sources": False})
    p = out_dir / f"chime7_{scenario}_{split}.jsonl"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("".join(json.dumps(r) + "\n" for r in rows))
    return {"manifest": str(p), "missing_audio_sessions": missing, "windows": len(rows)}
