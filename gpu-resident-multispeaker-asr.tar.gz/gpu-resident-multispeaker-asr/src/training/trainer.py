"""Shared optimisation loop used by every training stage."""
from __future__ import annotations

import itertools
import math
import time
from pathlib import Path
from typing import Callable

import torch

from src.training.checkpoints import load_checkpoint, save_checkpoint
from src.utils.device import peak_memory_mb, rss_mb
from src.utils.logging import JsonlLogger, get_logger

log = get_logger("train")


def warmup_cosine(optimizer, warmup: int, total: int, floor: float = 0.05):
    def f(step):
        if step < warmup:
            return (step + 1) / max(1, warmup)
        p = min(1.0, (step - warmup) / max(1, total - warmup))
        return floor + (1 - floor) * 0.5 * (1 + math.cos(math.pi * p))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, f)


def infinite(loader):
    while True:
        yield from loader


def run_training(*, name: str, model: torch.nn.Module, params, loader, step_fn: Callable,
                 eval_fn: Callable | None, steps: int, lr: float, warmup: int, device: torch.device,
                 out_dir: Path, log_dir: Path, cfg: dict, precision: str = "fp32", grad_clip: float = 5.0,
                 eval_every: int = 250, patience: int = 6, higher_is_better: bool = False,
                 resume: bool = False) -> dict:
    """step_fn(batch) -> (loss tensor, log dict). eval_fn() -> (metric float, dict).
    Saves `<name>_last.pt` every evaluation and `<name>.pt` at the best validation metric."""
    params = [p for p in params if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=lr, weight_decay=1e-2)
    sched = warmup_cosine(opt, warmup, steps)
    use_scaler = precision == "fp16" and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda") if use_scaler else None
    jl = JsonlLogger(log_dir / f"{name}.jsonl")
    best_path, last_path = out_dir / f"{name}.pt", out_dir / f"{name}_last.pt"
    step, best, bad_evals, skipped = 0, None, 0, 0
    if resume and last_path.exists():
        st = load_checkpoint(last_path, model, opt, sched, scaler, restore_rng=True)
        step, best = st["step"], st["metrics"].get("best")
        log.info(f"[{name}] resumed at step {step} (best={best})")
    n_params = sum(p.numel() for p in params)
    log.info(f"[{name}] training {n_params / 1e6:.2f}M params for {steps} steps on {device} ({precision})")
    jl.log(event="start", stage=name, steps=steps, lr=lr, params=n_params, precision=precision)
    it = infinite(loader)
    t0, window = time.time(), []
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    try:
        while step < steps:
            model.train()
            batch = next(it)
            ac = torch.autocast(device.type, dtype=torch.float16 if precision == "fp16" else torch.bfloat16) \
                if precision != "fp32" else torch.autocast(device.type, enabled=False)
            with ac:
                loss, rec = step_fn(batch)
            if not torch.isfinite(loss):
                skipped += 1
                opt.zero_grad(set_to_none=True)
                log.warning(f"[{name}] non-finite loss at step {step}; batch skipped ({skipped} total)")
                if skipped > 50:
                    raise RuntimeError("too many non-finite losses; aborting")
                step += 1
                continue
            opt.zero_grad(set_to_none=True)
            if scaler:
                scaler.scale(loss).backward()
                scaler.unscale_(opt)
            else:
                loss.backward()
            gnorm = torch.nn.utils.clip_grad_norm_(params, grad_clip)
            if scaler:
                scaler.step(opt)
                scaler.update()
            else:
                opt.step()
            sched.step()
            step += 1
            window.append(rec)
            if step % 25 == 0 or step == 1:
                avg = {k: sum(r[k] for r in window if k in r) / max(1, sum(k in r for r in window))
                       for k in window[-1]}
                rate = step / (time.time() - t0)
                log.info(f"[{name}] step {step}/{steps} " + " ".join(f"{k}={v:.3f}" for k, v in avg.items())
                         + f" gnorm={float(gnorm):.2f} lr={sched.get_last_lr()[0]:.2e} {rate:.2f} it/s")
                jl.log(event="train", stage=name, step=step, lr=sched.get_last_lr()[0], grad_norm=float(gnorm),
                       gpu_peak_mb=peak_memory_mb(device), rss_mb=rss_mb(), **avg)
                window = []
            if eval_fn and (step % eval_every == 0 or step == steps):
                metric, info = eval_fn()
                improved = best is None or (metric > best if higher_is_better else metric < best)
                if improved:
                    best, bad_evals = metric, 0
                    save_checkpoint(best_path, model, step, cfg, name, metrics={"best": best, **info})
                else:
                    bad_evals += 1
                save_checkpoint(last_path, model, step, cfg, name, opt, sched, scaler, metrics={"best": best})
                log.info(f"[{name}] eval step {step}: metric={metric:.4f} best={best:.4f} {info}")
                jl.log(event="eval", stage=name, step=step, metric=metric, best=best, **info)
                if bad_evals >= patience:
                    log.info(f"[{name}] early stopping after {bad_evals} evaluations without improvement")
                    break
    except BaseException:
        save_checkpoint(out_dir / f"{name}_crash.pt", model, step, cfg, name, opt, sched, scaler,
                        metrics={"best": best})
        log.error(f"[{name}] training interrupted at step {step}; state saved to {name}_crash.pt")
        raise
    if eval_fn is None:
        save_checkpoint(best_path, model, step, cfg, name)
    jl.log(event="end", stage=name, step=step, best=best, skipped=skipped, seconds=time.time() - t0)
    return {"best": best, "steps": step, "skipped": skipped, "seconds": round(time.time() - t0, 1)}


def take(loader, n):
    return itertools.islice(loader, n)
