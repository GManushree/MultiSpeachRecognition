"""Checkpoint save/restore with optimizer, scheduler, scaler and RNG state."""
from __future__ import annotations

import random
from pathlib import Path

import numpy as np
import torch


def save_checkpoint(path: str | Path, model: torch.nn.Module, step: int, cfg: dict, stage: str,
                    optimizer=None, scheduler=None, scaler=None, metrics: dict | None = None,
                    extra: dict | None = None) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    state = {"model": model.state_dict(), "step": step, "config": cfg, "stage": stage,
             "metrics": metrics or {}, "rng": {"torch": torch.get_rng_state(), "numpy": np.random.get_state(),
                                              "python": random.getstate()}}
    if optimizer is not None:
        state["optimizer"] = optimizer.state_dict()
    if scheduler is not None:
        state["scheduler"] = scheduler.state_dict()
    if scaler is not None:
        state["scaler"] = scaler.state_dict()
    state.update(extra or {})
    tmp = path.with_suffix(".tmp")
    torch.save(state, tmp)
    tmp.replace(path)  # atomic: a crash never leaves a half-written checkpoint
    return path


def load_checkpoint(path: str | Path, model: torch.nn.Module | None = None, optimizer=None,
                    scheduler=None, scaler=None, strict: bool = True, restore_rng: bool = False,
                    map_location="cpu") -> dict:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"checkpoint {path} does not exist (refusing to fall back to random weights)")
    state = torch.load(path, map_location=map_location, weights_only=False)
    if model is not None:
        missing, unexpected = model.load_state_dict(state["model"], strict=strict)
        state["missing_keys"], state["unexpected_keys"] = list(missing), list(unexpected)
    if optimizer is not None and "optimizer" in state:
        optimizer.load_state_dict(state["optimizer"])
    if scheduler is not None and "scheduler" in state:
        scheduler.load_state_dict(state["scheduler"])
    if scaler is not None and "scaler" in state:
        scaler.load_state_dict(state["scaler"])
    if restore_rng and "rng" in state:
        torch.set_rng_state(state["rng"]["torch"])
        np.random.set_state(state["rng"]["numpy"])
        random.setstate(state["rng"]["python"])
    return state
