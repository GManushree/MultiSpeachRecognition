"""Manifest I/O, validation, statistics, and PyTorch datasets/collators.

Manifest format (JSON lines, one mixture per line; shared by the synthetic, AMI and
CHiME-7 adapters): see docs/evaluation_protocol.md. Paths are relative to the manifest's
directory unless absolute."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import soundfile as sf
import torch
from torch.utils.data import Dataset

from src.audio.loader import load_audio
from src.models.asr import CharTokenizer

STDN_FRAME_S = 0.04  # 10 ms features x 4 subsampling


def read_manifest(path: str | Path) -> list[dict]:
    path = Path(path)
    rows = [json.loads(l) for l in path.read_text().splitlines() if l.strip()]
    for r in rows:
        r["_root"] = str(path.parent)
    return rows


def _abs(row: dict, p: str) -> Path:
    q = Path(p)
    return q if q.is_absolute() else Path(row["_root"]) / q


def validate_manifest(rows: list[dict], expected_sr: int = 16000, check_audio: bool = True) -> dict:
    """Missing files, sample-rate mismatches, invalid annotations. Returns a report; never raises."""
    rep = {"n": len(rows), "missing_files": [], "bad_sample_rate": [], "bad_annotations": []}
    for r in rows:
        files = [r["mix_path"]] + [s["path"] for s in r.get("speakers", []) if s.get("path")]
        for p in files:
            fp = _abs(r, p)
            if not fp.exists():
                rep["missing_files"].append(str(fp))
            elif check_audio:
                info = sf.info(str(fp))
                if info.samplerate != expected_sr:
                    rep["bad_sample_rate"].append((str(fp), info.samplerate))
        for s in r.get("speakers", []):
            for a, b in s.get("segments", []):
                if not (0 <= a < b <= r["duration"] + 1e-3):
                    rep["bad_annotations"].append((r["id"], s["speaker_id"], a, b))
    rep["ok"] = not (rep["missing_files"] or rep["bad_sample_rate"] or rep["bad_annotations"])
    return rep


def manifest_stats(rows: list[dict]) -> dict:
    ks = np.array([r["n_speakers"] for r in rows])
    durs = np.array([r["duration"] for r in rows])
    ovs = np.array([r.get("overlap_ratio", 0.0) for r in rows])
    spk = {s["speaker_id"] for r in rows for s in r["speakers"]}
    return {"mixtures": len(rows), "hours": round(float(durs.sum()) / 3600, 3),
            "mean_duration_s": round(float(durs.mean()), 2) if len(rows) else 0,
            "speaker_count_hist": {int(k): int((ks == k).sum()) for k in np.unique(ks)},
            "mean_overlap_ratio": round(float(ovs[ks > 1].mean()), 3) if (ks > 1).any() else 0.0,
            "unique_speakers": len(spk)}


def activity_labels(row: dict, n_frames: int, max_spk: int, frame_s: float = STDN_FRAME_S) -> np.ndarray:
    """(n_frames, max_spk) binary labels: frame active if >= half of it is inside a segment."""
    grid_n = n_frames * 4
    lab = np.zeros((n_frames, max_spk), dtype=np.float32)
    for j, s in enumerate(row["speakers"][:max_spk]):
        g = np.zeros(grid_n + 4, dtype=np.float32)
        for a, b in s.get("segments", []):
            g[int(round(a * 100)): int(round(b * 100))] = 1
        lab[:, j] = g[:grid_n].reshape(n_frames, 4).mean(1) >= 0.5
    return lab


class MixtureDataset(Dataset):
    """Mixture + aligned references for diarization/separation/joint training."""

    def __init__(self, manifest: str | Path, max_spk: int = 3, sr: int = 16000, max_items: int | None = None,
                 crop_s: float | None = None, min_active_s: float = 0.25, seed: int = 0):
        """crop_s: random training crops (aligned to the 40 ms STDN grid). Speakers with less
        than `min_active_s` of reference activity inside the crop are dropped from the
        references (a silent reference makes SI-SDR degenerate). Transcripts are not
        croppable, so crops are only valid for stages without the ASR loss."""
        self.rows = [r for r in read_manifest(manifest) if r["n_speakers"] <= max_spk][:max_items]
        self.max_spk, self.sr = max_spk, sr
        self.crop_s, self.min_active_s = crop_s, min_active_s
        self.rng = np.random.RandomState(seed)
        self.tok = CharTokenizer()

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        r = self.rows[i]
        mix = load_audio(_abs(r, r["mix_path"]), self.sr)
        n = len(mix)
        srcs = np.zeros((self.max_spk, n), dtype=np.float32)
        for j, s in enumerate(r["speakers"]):
            x = load_audio(_abs(r, s["path"]), self.sr)
            o = int(round(s["offset"] * self.sr))
            srcs[j, o:o + len(x)] = x[: max(0, n - o)]
        n_feat = n // 160 + 1
        n_out = ((n_feat - 1) // 2) // 2 + 1
        labels = activity_labels(r, n_out, self.max_spk)
        targets = [self.tok.encode(s["text"]) for s in r["speakers"]]
        n_spk = r["n_speakers"]
        hop = 640  # samples per STDN frame
        if self.crop_s and n > int(self.crop_s * self.sr):
            C = int(self.crop_s * self.sr) // hop * hop
            j0 = self.rng.randint(0, (n - C) // hop + 1)
            s0 = j0 * hop
            mix, srcs = mix[s0:s0 + C], srcs[:, s0:s0 + C]
            n_c = ((C // 160) // 2) // 2 + 1
            lab = labels[j0:j0 + n_c]
            lab = np.pad(lab, ((0, n_c - len(lab)), (0, 0)))
            keep = [k for k in range(n_spk) if lab[:, k].sum() * STDN_FRAME_S >= self.min_active_s]
            srcs_new = np.zeros_like(srcs)
            lab_new = np.zeros_like(lab)
            for i, k in enumerate(keep):
                srcs_new[i], lab_new[:, i] = srcs[k], lab[:, k]
            srcs, labels, n_spk = srcs_new, lab_new, len(keep)
            targets = [[] for _ in keep]  # not valid for ASR loss
        return {"id": r["id"], "mix": mix, "sources": srcs, "n_spk": n_spk,
                "act_labels": labels, "targets": targets}


def collate_mixtures(items: list[dict]) -> dict:
    B = len(items)
    N = max(len(it["mix"]) for it in items)
    S = items[0]["sources"].shape[0]
    T = max(it["act_labels"].shape[0] for it in items)
    L = max([len(t) for it in items for t in it["targets"]] + [1])
    mix = torch.zeros(B, N)
    src = torch.zeros(B, S, N)
    lab = torch.zeros(B, T, S)
    tgt = torch.zeros(B, S, L, dtype=torch.long)
    tlen = torch.zeros(B, S, dtype=torch.long)
    for b, it in enumerate(items):
        n = len(it["mix"])
        mix[b, :n] = torch.from_numpy(it["mix"])
        src[b, :, :n] = torch.from_numpy(it["sources"])
        lab[b, : it["act_labels"].shape[0]] = torch.from_numpy(it["act_labels"])
        for j, t in enumerate(it["targets"]):
            tgt[b, j, : len(t)] = torch.tensor(t, dtype=torch.long)
            tlen[b, j] = len(t)
    return {"ids": [it["id"] for it in items], "mix": mix, "mix_len": torch.tensor([len(it["mix"]) for it in items]),
            "sources": src, "act_labels": lab, "targets": tgt, "target_len": tlen,
            "n_spk": torch.tensor([it["n_spk"] for it in items])}


class SourceUtteranceDataset(Dataset):
    """Single-speaker utterances (the clean sources of each mixture) for ASR pretraining."""

    def __init__(self, manifest: str | Path, sr: int = 16000, max_items: int | None = None):
        rows = read_manifest(manifest)
        self.items = [(r, s) for r in rows for s in r["speakers"]][:max_items]
        self.sr = sr
        self.tok = CharTokenizer()

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        r, s = self.items[i]
        return {"wav": load_audio(_abs(r, s["path"]), self.sr), "target": self.tok.encode(s["text"]),
                "text": self.tok.normalize(s["text"])}


def collate_utterances(items: list[dict]) -> dict:
    N = max(len(it["wav"]) for it in items)
    L = max(max(len(it["target"]) for it in items), 1)
    wav = torch.zeros(len(items), N)
    tgt = torch.zeros(len(items), L, dtype=torch.long)
    for b, it in enumerate(items):
        wav[b, : len(it["wav"])] = torch.from_numpy(it["wav"])
        tgt[b, : len(it["target"])] = torch.tensor(it["target"])
    return {"wav": wav, "wav_len": torch.tensor([len(it["wav"]) for it in items]), "targets": tgt,
            "target_len": torch.tensor([len(it["target"]) for it in items]),
            "texts": [it["text"] for it in items]}


def transcripts(manifest: str | Path) -> list[str]:
    tok = CharTokenizer()
    return [tok.normalize(s["text"]) for r in read_manifest(manifest) for s in r["speakers"]]
