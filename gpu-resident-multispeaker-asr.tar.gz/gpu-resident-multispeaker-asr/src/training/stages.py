"""Training stages (staged integration followed by joint fine-tuning).

Order and initialisation (each stage starts from the previous stage's checkpoint, so the
saved JointModel always contains every trained module):
  lm          -> checkpoints/lm.pt           char LSTM LM on training transcripts
  diarization -> checkpoints/diarization.pt  STDN only (L_diar); separator/ASR untouched
  asr         -> checkpoints/asr.pt          ASR on clean single-speaker sources (CTC)
  separation  -> checkpoints/separation.pt   separator (L_sep) conditioned on the FROZEN STDN
  joint       -> checkpoints/joint.pt        all three modules, L_sep + l1 L_diar + l2 L_asr

`separation.pt` is therefore the "separately trained components" control for the joint
training ablation. Caveat (documented): the joint model receives extra optimisation steps."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from src.evaluation.der import frame_der
from src.evaluation.wer import corpus_wer
from src.models.asr import CharTokenizer, CTCASR, ctc_loss, greedy_decode
from src.models.joint_model import JointModel
from src.models.rescoring import CharLSTMLM, lm_loss
from src.models.stdn import estimate_speaker_count, subsampled_length
from src.training.checkpoints import load_checkpoint, save_checkpoint
from src.training.datasets import (MixtureDataset, SourceUtteranceDataset, collate_mixtures,
                                   collate_utterances, transcripts)
from src.training.losses import si_sdr
from src.training.trainer import run_training, take
from src.utils.logging import get_logger
from src.utils.reproducibility import set_seed

log = get_logger("stages")
STAGE_ORDER = ["lm", "diarization", "asr", "separation", "asr_adapt", "joint"]
PREV = {"diarization": None, "asr": "diarization", "separation": "asr", "asr_adapt": "separation",
        "joint": "asr_adapt"}


def _to(batch, device):
    return {k: (v.to(device, non_blocking=True) if torch.is_tensor(v) and k not in ("mix_len", "n_spk") else v)
            for k, v in batch.items()}


def _paths(cfg):
    from src.utils.config import resolve_path
    root = resolve_path(cfg["data"]["root"])
    return {s: root / f"{s}.jsonl" for s in ("train", "val", "test")}, resolve_path(cfg["out_dir"]), \
        resolve_path(cfg["log_dir"])


# ------------------------------------------------------------------------------- LM
def train_lm(cfg, device, smoke=False):
    paths, out_dir, log_dir = _paths(cfg)
    st = cfg["stages"]["lm"]
    tok = CharTokenizer()
    def enc(texts):
        ids = [tok.encode(t) for t in texts]
        L = max(len(i) for i in ids)
        x = torch.zeros(len(ids), L, dtype=torch.long)
        for n, i in enumerate(ids):
            x[n, : len(i)] = torch.tensor(i)
        return x, torch.tensor([len(i) for i in ids])
    tr_x, tr_l = enc(transcripts(paths["train"]))
    va_x, va_l = enc(transcripts(paths["val"]))
    lm = CharLSTMLM(**cfg["model"]["lm"]).to(device)
    bs = st["batch_size"]
    steps = 5 if smoke else st["epochs"] * max(1, len(tr_x) // bs)

    def loader():
        while True:
            perm = torch.randperm(len(tr_x))
            for i in range(0, len(perm) - bs + 1, bs):
                yield tr_x[perm[i:i + bs]], tr_l[perm[i:i + bs]]

    def step(batch):
        x, l = batch
        loss = lm_loss(lm, x.to(device), l.to(device))
        return loss, {"nll": loss.item()}

    @torch.no_grad()
    def evaluate():
        lm.eval()
        nll = lm_loss(lm, va_x.to(device), va_l.to(device)).item()
        return nll, {"val_nll_per_char": nll, "val_ppl": float(np.exp(nll))}

    return run_training(name="lm", model=lm, params=lm.parameters(), loader=loader(), step_fn=step,
                        eval_fn=evaluate, steps=steps, lr=st["lr"], warmup=50 if not smoke else 1,
                        device=device, out_dir=out_dir, log_dir=log_dir, cfg=cfg,
                        eval_every=max(1, steps // 4), patience=99)


# ------------------------------------------------------------------------------- ASR
def evaluate_asr(asr: CTCASR, features, loader, device, max_batches=None):
    tok = CharTokenizer()
    asr.eval()
    pairs = []
    with torch.no_grad():
        for b in take(loader, max_batches) if max_batches else loader:
            wav = b["wav"].to(device)
            logits, olen = asr(features(wav), b["wav_len"].to(device) // features.hop + 1)
            toks, _, lens = greedy_decode(logits, olen)
            for n in range(len(lens)):
                pairs.append((b["texts"][n], tok.decode(toks[n, : lens[n]].tolist())))
    return corpus_wer(pairs).rate, pairs


def train_asr(cfg, device, smoke=False, resume=False):
    paths, out_dir, log_dir = _paths(cfg)
    st = cfg["stages"]["asr"]
    model = JointModel(cfg["model"]).to(device)
    _init_from(model, out_dir, "asr", device)
    model.freeze(["stdn", "separator"])
    tr = SourceUtteranceDataset(paths["train"], max_items=64 if smoke else None)
    va = SourceUtteranceDataset(paths["val"], max_items=16 if smoke else 200)
    dl = DataLoader(tr, st["batch_size"], shuffle=True, collate_fn=collate_utterances,
                    num_workers=cfg.get("num_workers", 0), drop_last=True)
    vdl = DataLoader(va, 32, collate_fn=collate_utterances)
    rng = np.random.RandomState(cfg["seed"])

    def step(b):
        wav = b["wav"].to(device)
        # light augmentation: random gain and additive noise at 20-40 dB SNR
        g = torch.from_numpy(rng.uniform(0.3, 1.5, (wav.shape[0], 1)).astype(np.float32)).to(device)
        wav = wav * g
        p = wav.square().mean(-1, keepdim=True)
        snr = torch.from_numpy(rng.uniform(20, 40, (wav.shape[0], 1)).astype(np.float32)).to(device)
        wav = wav + torch.randn_like(wav) * (p / 10 ** (snr / 10)).sqrt()
        logits, olen = model.asr(model.features(wav), b["wav_len"].to(device) // model.features.hop + 1)
        loss = ctc_loss(logits, olen, b["targets"].to(device), b["target_len"].to(device))
        return loss, {"ctc": loss.item()}

    def evaluate():
        w, pairs = evaluate_asr(model.asr, model.features, vdl, device)
        return w, {"val_wer": w, "example": f"{pairs[0][0]!r} -> {pairs[0][1]!r}"}

    return run_training(name="asr", model=model, params=model.asr.parameters(), loader=dl, step_fn=step,
                        eval_fn=evaluate, steps=4 if smoke else st["steps"], lr=st["lr"],
                        warmup=1 if smoke else st["warmup"], device=device, out_dir=out_dir, log_dir=log_dir,
                        cfg=cfg, precision=cfg.get("precision", "fp32"), grad_clip=cfg["grad_clip"],
                        eval_every=2 if smoke else cfg["eval_every"],
                        patience=cfg.get("early_stopping_patience", 6), resume=resume)


# ------------------------------------------------------------------- mixture stages
@torch.no_grad()
def evaluate_mixtures(model: JointModel, loader, device, max_batches=None, with_sep=True, with_asr=False):
    """Validation metrics on mixtures: frame DER (estimated K), speaker-count accuracy,
    SI-SDRi on the first n_spk attractors with PIT (oracle count) and, with_asr, greedy WER
    of the separated streams against the PIT-matched reference transcripts."""
    from src.evaluation.separation_metrics import pit_si_sdr
    from src.models.joint_model import rms_normalize
    model.eval()
    tok = CharTokenizer()
    ders, k_acc, sdri, pairs, clean_pairs = [], [], [], [], []
    for b in take(loader, max_batches) if max_batches else loader:
        b = _to(b, device)
        feat_len = b["mix_len"] // model.features.hop + 1
        diar = model.stdn(model.features(b["mix"]), feat_len)
        k_hat, mask, _ = estimate_speaker_count(diar.exist_prob)
        act = (diar.activity_prob > 0.5) & mask[:, None, :]
        out_len = subsampled_length(feat_len)
        kmax = int(b["n_spk"].max())
        est = model.separator(b["mix"], diar.attractors[:, :kmax], diar.activity_prob[:, :, :kmax]) \
            if with_sep and kmax else None
        for i in range(len(b["n_spk"])):
            K, T = int(b["n_spk"][i]), int(out_len[i])
            d, _ = frame_der(b["act_labels"][i, :T, :K].cpu().numpy(), act[i, :T].cpu().numpy())
            ders.append(d)
            k_acc.append(int(k_hat[i]) == K)
            if est is not None and K:
                n = int(b["mix_len"][i])
                r = pit_si_sdr(est[i, :K, :n], b["sources"][i, :K, :n], b["mix"][i, :n])
                sdri += r["si_sdri"]
                if with_asr:
                    wav = rms_normalize(est[i, r["perm"], :n])
                    toks, _, lens = greedy_decode(*model.asr(model.features(wav)))
                    for row, j in enumerate(r["refs"]):
                        ref = tok.decode(b["targets"][i, j, : int(b["target_len"][i, j])].tolist())
                        pairs.append((ref, tok.decode(toks[row, : lens[row]].tolist())))
                    ct, _, cn = greedy_decode(*model.asr(model.features(rms_normalize(b["sources"][i, r["refs"], :n]))))
                    for row, j in enumerate(r["refs"]):
                        ref = tok.decode(b["targets"][i, j, : int(b["target_len"][i, j])].tolist())
                        clean_pairs.append((ref, tok.decode(ct[row, : cn[row]].tolist())))
    out = {"frame_der": float(np.mean(ders)), "count_acc": float(np.mean(k_acc))}
    if sdri:
        out["si_sdri"] = float(np.mean(sdri))
    if pairs:
        out["sep_stream_wer"] = corpus_wer(pairs).rate
        out["clean_source_wer"] = corpus_wer(clean_pairs).rate
        out["example"] = f"{pairs[0][0]!r} -> {pairs[0][1]!r}"
    return out


def _init_from(model, out_dir: Path, stage: str, device):
    prev = PREV.get(stage)
    if prev is None:
        return
    p = out_dir / f"{prev}.pt"
    load_checkpoint(p, model, map_location=device)  # raises if missing: no silent random init
    log.info(f"[{stage}] initialised from {p}")


def train_mixture_stage(stage: str, cfg, device, smoke=False, resume=False):
    paths, out_dir, log_dir = _paths(cfg)
    st = cfg["stages"][stage]
    model = JointModel(cfg["model"]).to(device)
    _init_from(model, out_dir, stage, device)
    model.freeze(st.get("freeze", []))
    S = model.max_speakers
    use = st["use"]
    if st.get("crop_s") and use.get("asr"):
        raise ValueError("crop_s cannot be combined with the ASR loss (transcripts are not croppable)")
    tr = MixtureDataset(paths["train"], S, max_items=16 if smoke else None, crop_s=st.get("crop_s"),
                        seed=cfg["seed"])
    va = MixtureDataset(paths["val"], S, max_items=8 if smoke else None)
    dl = DataLoader(tr, st["batch_size"], shuffle=True, collate_fn=collate_mixtures,
                    num_workers=cfg.get("num_workers", 0), drop_last=True)
    vdl = DataLoader(va, 8, collate_fn=collate_mixtures)

    weights = {**cfg["weights"], **st.get("weights", {})}

    def step(b):
        return model.compute_losses(_to(b, device), use, weights)

    def evaluate():
        m = evaluate_mixtures(model, vdl, device, with_sep=use.get("sep", False) or use.get("asr", False),
                              with_asr=use.get("asr", False))
        if stage == "diarization":
            return m["frame_der"], m
        if stage == "separation":
            return m["si_sdri"], m
        # asr_adapt / joint: model selection on the end task (WER of separated streams)
        return m["sep_stream_wer"], m

    return run_training(name=stage, model=model, params=model.parameters(), loader=dl, step_fn=step,
                        eval_fn=evaluate, steps=3 if smoke else st["steps"], lr=st["lr"],
                        warmup=1 if smoke else st["warmup"], device=device, out_dir=out_dir, log_dir=log_dir,
                        cfg=cfg, precision=cfg.get("precision", "fp32"), grad_clip=cfg["grad_clip"],
                        eval_every=3 if smoke else st.get("eval_every", cfg["eval_every"]),
                        patience=cfg.get("early_stopping_patience", 6),
                        higher_is_better=stage == "separation", resume=resume)


def run_stage(stage: str, cfg, device, smoke=False, resume=False):
    set_seed(cfg["seed"] + STAGE_ORDER.index(stage))
    if stage == "lm":
        return train_lm(cfg, device, smoke)
    if stage == "asr":
        return train_asr(cfg, device, smoke, resume)
    return train_mixture_stage(stage, cfg, device, smoke, resume)
