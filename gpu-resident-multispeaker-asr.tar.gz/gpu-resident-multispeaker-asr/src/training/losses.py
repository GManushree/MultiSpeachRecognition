"""Losses for L_total = L_sep + lambda_1 * L_diar + lambda_2 * L_asr.

Speaker assignment: for each mixture with K reference speakers, the first K attractors
(EDA convention) are matched to the K references by the Hungarian algorithm on a combined
pairwise cost  C[i, j] = BCE(activity_i, label_j) * w_diar - SI-SDR(est_i, ref_j) * w_sep.
The *same* permutation is then used for the activity, separation and ASR losses, so the
three objectives agree on which stream is which speaker. Pairwise costs are separable,
so the Hungarian solution is the exact PIT optimum for any K."""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment


def si_sdr(est: torch.Tensor, ref: torch.Tensor, mask: torch.Tensor | None = None,
           eps: float = 1e-8) -> torch.Tensor:
    """Scale-invariant SDR in dB along the last axis; broadcasting over leading dims."""
    est, ref = est.float(), ref.float()
    if mask is not None:
        m = mask.to(est.dtype)
        n = m.sum(-1, keepdim=True).clamp(min=1)
        est = (est - (est * m).sum(-1, keepdim=True) / n) * m
        ref = (ref - (ref * m).sum(-1, keepdim=True) / n) * m
    else:
        est = est - est.mean(-1, keepdim=True)
        ref = ref - ref.mean(-1, keepdim=True)
    alpha = (est * ref).sum(-1, keepdim=True) / (ref.square().sum(-1, keepdim=True) + eps)
    target = alpha * ref
    noise = est - target
    return 10 * torch.log10((target.square().sum(-1) + eps) / (noise.square().sum(-1) + eps))


def pairwise_bce(logits: torch.Tensor, labels: torch.Tensor, frame_mask: torch.Tensor) -> torch.Tensor:
    """logits (T, K), labels (T, K), frame_mask (T,) -> mean BCE matrix (K_pred, K_ref)."""
    lg = logits.float()[:, :, None].expand(-1, -1, labels.shape[1])
    lb = labels.float()[:, None, :].expand_as(lg)
    bce = F.binary_cross_entropy_with_logits(lg, lb, reduction="none")
    m = frame_mask.float()[:, None, None]
    return (bce * m).sum(0) / m.sum().clamp(min=1)


def hungarian(cost: torch.Tensor) -> np.ndarray:
    """Returns perm with perm[j] = predicted index assigned to reference j."""
    c = torch.nan_to_num(cost.detach().float(), nan=1e6, posinf=1e6, neginf=-1e6).cpu().numpy()
    rows, cols = linear_sum_assignment(c)
    perm = np.empty(c.shape[1], dtype=np.int64)
    perm[cols] = rows
    return perm


def existence_loss(exist_logits: torch.Tensor, n_spk: torch.Tensor) -> torch.Tensor:
    """exist_logits (B, S); target 1 for the first n_spk attractors, 0 for the next one
    (positions beyond n_spk + 1 are ignored, as in EEND-EDA)."""
    B, S = exist_logits.shape
    pos = torch.arange(S, device=exist_logits.device)[None]
    n = n_spk.to(exist_logits.device)[:, None]
    target = (pos < n).float()
    valid = pos <= n
    bce = F.binary_cross_entropy_with_logits(exist_logits.float(), target, reduction="none")
    return (bce * valid).sum() / valid.sum().clamp(min=1)


def finite_or_zero(x: torch.Tensor, name: str, log: dict) -> torch.Tensor:
    """Guard against NaN/Inf: replaces a non-finite loss term with a zero that keeps the
    graph (so backward still runs) and counts the event in the log dict."""
    if torch.isfinite(x).all():
        return x
    log[f"nonfinite_{name}"] = log.get(f"nonfinite_{name}", 0) + 1
    return x.nan_to_num(0.0, 0.0, 0.0) * 0.0
