"""End-to-end multi-speaker ASR pipelines (one processing block at a time).

ResidentPipeline (the paper's design)
    H2D(audio) -> LogMel -> STDN/EDA -> separator(all capacity streams, masked)
    -> LogMel -> ASR -> on-device N-best -> on-device rescoring -> pack -> D2H(packet)
    Exactly 2 crossings per block with fixed_capacity=True and the device N-best decoder.
    Options that add crossings (each recorded by the tracker):
      fixed_capacity=False   read K_hat on host to separate only detected speakers (+1 D2H, sync)
      decoder="beam"         host prefix beam search: logits D2H, hypotheses H2D
      n_crossings=4          controlled variant: identical compute plus one extra round trip
                             of the separated waveforms (for the L_sync estimate)
CascadedPipeline (conventional baseline, same weights)
    Every module boundary goes through host memory, K_hat is decided on host, decoding is
    host prefix beam search, rescoring inputs are re-uploaded, timestamps from host
    forced alignment.
Both return a BlockResult with words per speaker, diarization activity and timings."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
import torch
import torch.nn.functional as F

from src.audio.loader import AudioError
from src.evaluation.transfer_profiler import TransferTracker
from src.models.aggregation import Word, tokens_to_words
from src.models.asr import (ASR_FRAME_S, CharTokenizer, device_nbest, forced_align,
                            prefix_beam_search)
from src.models.joint_model import JointModel, rms_normalize
from src.models.rescoring import CharLSTMLM, RescoreConfig, Rescorer
from src.models.stdn import estimate_speaker_count
from src.training.datasets import STDN_FRAME_S
from src.utils.device import autocast_ctx

TOK = CharTokenizer()


@dataclass
class BlockResult:
    offset_s: float
    duration_s: float
    speakers: dict = field(default_factory=dict)   # local idx -> {"words", "exist_prob", "uncertain", "text"}
    activity: np.ndarray | None = None             # (T_d, S) probabilities at 40 ms
    exist_prob: np.ndarray | None = None
    bank_ids: np.ndarray | None = None             # streaming: global speaker id per local idx
    timings: dict = field(default_factory=dict)
    transfers: dict = field(default_factory=dict)


class _Clock:
    """Per-module timing. CUDA: events (no sync until read). CPU: perf_counter (CPU is synchronous)."""

    def __init__(self, device):
        self.cuda = device.type == "cuda"
        self.marks: list = []

    def mark(self, name):
        if self.cuda:
            ev = torch.cuda.Event(enable_timing=True)
            ev.record()
            self.marks.append((name, ev))
        else:
            self.marks.append((name, time.perf_counter()))

    def read(self) -> dict:
        out = {}
        for (n0, a), (n1, b) in zip(self.marks, self.marks[1:]):
            out[n1] = (a.elapsed_time(b) / 1000) if self.cuda else (b - a)
        return out


def _check_audio(x: np.ndarray, min_samples: int = 400):
    if x.ndim != 1:
        raise AudioError(f"expected mono audio, got shape {x.shape}")
    if len(x) < min_samples:
        raise AudioError(f"audio block too short ({len(x)} samples; need >= {min_samples})")
    if not np.isfinite(x).all():
        raise AudioError("audio contains NaN/Inf")


class _Base:
    def __init__(self, model: JointModel, lm: CharLSTMLM | None, cfg: dict, device: torch.device,
                 precision: str = "fp32"):
        self.model = model.to(device).eval()
        self.lm = lm.to(device).eval() if lm is not None else None
        self.cfg, self.device, self.precision = cfg, device, precision
        rc = cfg.get("rescore", {})
        self.rescorer = Rescorer(self.lm, RescoreConfig(**rc))
        self.S = model.max_speakers
        self.tracker = TransferTracker(device)

    def _amp(self):
        return autocast_ctx(self.device, self.precision)

    def _speaker_entry(self, chars, frames, exist_p, offset, activity=None):
        """Words for one speaker stream. Timestamps: `timestamp_source: diarization` (default)
        places the words, in order, over this speaker's diarized active regions in proportion
        to their character counts; `ctc` uses the CTC emission frames. The CTC frames of the
        full-attention recogniser were found to be temporally unreliable (see
        docs/limitations.md), whereas the diarization activity is frame-accurate."""
        thr, margin = self.cfg.get("exist_threshold", 0.5), self.cfg.get("uncertainty_margin", 0.15)
        words = tokens_to_words(chars, frames, ASR_FRAME_S, offset)
        if activity is not None and words and self.cfg.get("timestamp_source", "diarization") == "diarization":
            regions = active_regions(activity, self.cfg.get("activity_threshold", 0.5), offset)
            if regions:
                words = place_words(words, regions)
        return {"text": " ".join(w.text for w in words), "words": words,
                "exist_prob": float(exist_p), "uncertain": bool(abs(exist_p - thr) < margin)}


def active_regions(activity: np.ndarray, threshold: float, offset: float, frame_s: float = STDN_FRAME_S,
                   merge_gap_s: float = 0.3, min_len_s: float = 0.1) -> list[tuple[float, float]]:
    on = np.append(activity > threshold, False)
    regs, start = [], None
    for t, v in enumerate(on):
        if v and start is None:
            start = t
        elif not v and start is not None:
            regs.append([offset + start * frame_s, offset + t * frame_s])
            start = None
    merged = []
    for r in regs:
        if merged and r[0] - merged[-1][1] <= merge_gap_s:
            merged[-1][1] = r[1]
        else:
            merged.append(r)
    return [(a, b) for a, b in merged if b - a >= min_len_s]


def place_words(words: list[Word], regions: list[tuple[float, float]]) -> list[Word]:
    """Map words onto the concatenated active timeline proportionally to character count."""
    total = sum(b - a for a, b in regions)
    weights = [len(w.text) + 1 for w in words]   # +1: inter-word gap
    W = float(sum(weights))
    def to_abs(u):  # u in [0, total] on the concatenated timeline -> absolute seconds
        for a, b in regions:
            if u <= b - a + 1e-9:
                return a + u
            u -= b - a
        return regions[-1][1]
    out, acc = [], 0.0
    for w, wt in zip(words, weights):
        s = to_abs(acc / W * total)
        e = to_abs((acc + wt - 1) / W * total)
        out.append(Word(w.text, s, max(e, s + 0.02)))
        acc += wt
    return out


class ResidentPipeline(_Base):
    def __init__(self, *a, fixed_capacity: bool = True, decoder: str = "device_nbest", n_crossings: int = 2, **k):
        super().__init__(*a, **k)
        self.fixed_capacity, self.decoder, self.n_crossings = fixed_capacity, decoder, n_crossings
        if n_crossings not in (2, 4):
            raise ValueError("n_crossings must be 2 (resident) or 4 (controlled extra round trip)")

    @torch.no_grad()
    def process_block(self, audio: np.ndarray, offset_s: float = 0.0, bank=None) -> BlockResult:
        _check_audio(audio)
        tr, clk, m = self.tracker, _Clock(self.device), self.model
        tr.reset()
        clk.mark("start")
        x = tr.h2d(audio, "audio")[None]                               # crossing 1
        clk.mark("h2d")
        with self._amp():
            feats = m.features(x)
            clk.mark("features")
            diar = m.stdn(feats)
            exist = diar.exist_prob[0, : self.S].float()
            act = diar.activity_prob[0, :, : self.S].float()
            k_hat, present, uncertain = estimate_speaker_count(exist[None], self.cfg.get("exist_threshold", 0.5))
            clk.mark("diarization")
            att = diar.attractors[:, : self.S]
            if self.fixed_capacity:
                sel = torch.arange(self.S, device=self.device)
            else:  # data-dependent shape: requires reading K_hat / mask on host
                tr.sync("read speaker mask")
                mask_h = tr.d2h(present[0], "speaker mask")
                sel = torch.as_tensor(np.nonzero(mask_h)[0], device=self.device)
            est = m.separator(x, att[:, sel], diar.activity_prob[:, :, sel])[0] if len(sel) else x.new_zeros(0, x.shape[1])
            clk.mark("separation")
            if self.n_crossings == 4:  # controlled extra round trip, same payload back and forth
                est = tr.h2d(tr.d2h(est.float(), "separated (extra)"), "separated (extra)").to(est.dtype)
            n_s = est.shape[0]
            if n_s:
                wav = rms_normalize(est.float())
                n_frames = wav.shape[-1] // m.features.hop + 1
                logits, _ = m.asr(m.features(wav))
                logp = F.log_softmax(logits.float(), -1)
                clk.mark("asr")
                out_len = torch.full((n_s,), logp.shape[1], device=self.device, dtype=torch.long)
                if self.decoder == "device_nbest":
                    _, _, toks, frames, lens = device_nbest(logp, self.cfg.get("n_best", 8), self.cfg.get("n_flip", 3))
                elif self.decoder == "greedy":
                    _, _, toks, frames, lens = device_nbest(logp, 1, 0)
                elif self.decoder == "beam":
                    toks, frames, lens = self._host_beam(logp)
                else:
                    raise ValueError(self.decoder)
                best, _ = self.rescorer.rescore(logp, out_len, toks, lens)
                ar = torch.arange(n_s, device=self.device)
                b_tok, b_fr, b_len = toks[ar, best], frames[ar, best], lens[ar, best]
                clk.mark("rescoring")
            else:
                T1 = 1
                b_tok = b_fr = torch.zeros(0, T1, device=self.device, dtype=torch.long)
                b_len = torch.zeros(0, device=self.device, dtype=torch.long)
                clk.mark("asr")
                clk.mark("rescoring")
            bank_map = bank.match(att[0, sel], present[0, sel]) if bank is not None else None
            # ---- pack everything the host needs into one buffer -> a single D2H crossing
            L = b_tok.shape[1]
            parts = [exist, uncertain.float(), act.reshape(-1), sel.float(), b_len.float(),
                     b_tok.float().reshape(-1), b_fr.float().reshape(-1)]
            if bank_map is not None:
                parts.append(bank_map.float())
            packet = torch.cat([p.reshape(-1) for p in parts])
        host = tr.d2h(packet, "decoded packet")                        # crossing 2
        clk.mark("d2h")
        return self._unpack(host, act.shape[0], n_s, L, offset_s, len(audio), clk, bank_map is not None)

    def _host_beam(self, logp):
        lp = self.tracker.d2h(logp, "logits for beam search")
        hyps_all = []
        for s in range(lp.shape[0]):
            hyps_all.append(prefix_beam_search(lp[s], self.cfg.get("beam_width", 8), self.cfg.get("n_best", 8)))
        N = max(len(h) for h in hyps_all)
        L = max([len(t) for h in hyps_all for t, _ in h] + [1])
        toks = np.zeros((lp.shape[0], N, L), np.int64)
        frames = np.zeros_like(toks)
        lens = np.zeros((lp.shape[0], N), np.int64)
        for s, h in enumerate(hyps_all):
            for n in range(N):
                t = list(h[min(n, len(h) - 1)][0])
                toks[s, n, : len(t)], lens[s, n] = t, len(t)
                frames[s, n, : len(t)] = forced_align(lp[s], t)
        packed = np.concatenate([toks.ravel(), frames.ravel(), lens.ravel()])
        dev = self.tracker.h2d(packed, "beam hypotheses", dtype=torch.long)
        a, b = toks.size, toks.size * 2
        return dev[:a].view(toks.shape), dev[a:b].view(toks.shape), dev[b:].view(lens.shape)

    def _unpack(self, h, T_d, n_s, L, offset_s, n_samples, clk, with_bank) -> BlockResult:
        S, i = self.S, 0
        exist = h[i:i + S]; i += S
        _unc = h[i]; i += 1
        act = h[i:i + T_d * S].reshape(T_d, S); i += T_d * S
        sel = h[i:i + n_s].astype(int); i += n_s
        lens = h[i:i + n_s].astype(int); i += n_s
        toks = h[i:i + n_s * L].reshape(n_s, L).astype(int); i += n_s * L
        frs = h[i:i + n_s * L].reshape(n_s, L).astype(int); i += n_s * L
        bank_ids = h[i:i + n_s].astype(int) if with_bank else None
        thr = self.cfg.get("exist_threshold", 0.5)
        res = BlockResult(offset_s, n_samples / 16000, activity=act, exist_prob=exist, bank_ids=bank_ids)
        for j, k in enumerate(sel):
            if exist[k] <= thr:     # masked capacity stream (fixed_capacity mode): not a speaker
                continue
            res.speakers[int(k)] = self._speaker_entry(TOK.decode(toks[j, : lens[j]]), list(frs[j, : lens[j]]),
                                                       exist[k], offset_s, act[:, k])
            if bank_ids is not None:
                res.speakers[int(k)]["bank_id"] = int(bank_ids[j])
        res.timings = clk.read()
        res.timings["total"] = sum(res.timings.values())
        res.transfers = self.tracker.summary()
        return res


class CascadedPipeline(_Base):
    """Conventional baseline: each module is a separate host-orchestrated stage."""

    @torch.no_grad()
    def process_block(self, audio: np.ndarray, offset_s: float = 0.0, bank=None) -> BlockResult:
        _check_audio(audio)
        tr, m, clk = self.tracker, self.model, _Clock(self.device)
        tr.reset()
        clk.mark("start")
        with self._amp():
            x = tr.h2d(audio, "audio -> features")[None]
            feats = tr.d2h(m.features(x).float(), "features")
            clk.mark("features")
            diar = m.stdn(tr.h2d(feats, "features -> STDN"))
            exist = tr.d2h(diar.exist_prob[0, : self.S].float(), "existence")
            act = tr.d2h(diar.activity_prob[0, :, : self.S].float(), "activity")
            att = tr.d2h(diar.attractors[0, : self.S].float(), "attractors")
            tr.sync("speaker count decision on host")
            sel = np.nonzero(exist > self.cfg.get("exist_threshold", 0.5))[0]
            clk.mark("diarization")
            res = BlockResult(offset_s, len(audio) / 16000, activity=act, exist_prob=exist)
            if len(sel) == 0:
                for k in ("separation", "asr", "rescoring"):
                    clk.mark(k)
            else:
                xa = tr.h2d(audio, "audio -> separator")[None]
                a_d = tr.h2d(att[sel][None], "attractors -> separator")
                act_d = tr.h2d(act[:, sel][None], "activity -> separator")
                est = tr.d2h(m.separator(xa, a_d, act_d)[0].float(), "separated waveforms")
                clk.mark("separation")
                lps = []
                for s in range(len(sel)):  # per-speaker recognizer calls, as separate tools would do
                    w = rms_normalize(tr.h2d(est[s], f"stream {s} -> ASR")[None])
                    logits, _ = m.asr(m.features(w))
                    lps.append(tr.d2h(F.log_softmax(logits[0].float(), -1), f"logits {s}"))
                clk.mark("asr")
                for s, k in enumerate(sel):
                    hyps = prefix_beam_search(lps[s], self.cfg.get("beam_width", 8), self.cfg.get("n_best", 8))
                    L = max([len(t) for t, _ in hyps] + [1])
                    toks = np.zeros((1, len(hyps), L), np.int64)
                    lens = np.array([[len(t) for t, _ in hyps]])
                    for n, (t, _) in enumerate(hyps):
                        toks[0, n, : len(t)] = t
                    lp_d = tr.h2d(lps[s][None], f"logits {s} -> rescoring")
                    best, _ = self.rescorer.rescore(lp_d, torch.tensor([lps[s].shape[0]], device=self.device),
                                                    tr.h2d(toks, f"hyps {s}", torch.long),
                                                    torch.as_tensor(lens, device=self.device), mode="batched")
                    b = int(tr.d2h(best, f"best idx {s}")[0])
                    t = list(toks[0, b, : lens[0, b]])
                    res.speakers[int(k)] = self._speaker_entry(TOK.decode(t), forced_align(lps[s], t),
                                                               exist[k], offset_s, act[:, k])
                clk.mark("rescoring")
        res.timings = clk.read()
        res.timings["total"] = sum(res.timings.values())
        res.transfers = tr.summary()
        return res


def build_pipeline(model, lm, inf_cfg: dict, device, precision="fp32", mode: str | None = None, **overrides):
    p = dict(inf_cfg["pipeline"])
    p.update(overrides)
    mode = mode or p.get("mode", "resident")
    if mode == "cascaded":
        return CascadedPipeline(model, lm, p, device, precision)
    return ResidentPipeline(model, lm, p, device, precision, fixed_capacity=p.get("fixed_capacity", True),
                            decoder=p.get("decoder", "device_nbest"), n_crossings=p.get("n_crossings", 2))


def diarization_segments(res: BlockResult, frame_s: float = STDN_FRAME_S, threshold: float = 0.5,
                         labels: dict | None = None, min_dur: float = 0.08) -> list[tuple[float, float, str]]:
    """Threshold activity of present speakers -> [(start, end, label)] absolute seconds."""
    out = []
    if res.activity is None:
        return out
    end_s = res.offset_s + res.duration_s
    for k in res.speakers:
        on = np.append(res.activity[:, k] > threshold, False)
        lab = (labels or {}).get(k, f"SPEAKER_{k:02d}")
        start = None
        for t, v in enumerate(on):
            if v and start is None:
                start = t
            elif not v and start is not None:
                s, e = res.offset_s + start * frame_s, min(end_s, res.offset_s + t * frame_s)
                if e - s >= min_dur:
                    out.append((s, e, lab))
                start = None
    return out


def words_of(res: BlockResult) -> dict[int, list[Word]]:
    return {k: v["words"] for k, v in res.speakers.items()}
