"""Streaming inference: fixed-size blocks with left context and stateful speaker tracking.

Speaker tracking keeps a bank of global speaker attractors ON THE DEVICE. Each block's
attractors are matched to the bank by cosine similarity with a greedy, fully tensorized
assignment (no host sync); matched entries are EMA-updated, unmatched present speakers
open new entries. The resulting global ids travel in the block's single D2H packet.

Partial utterances: a block emits a word only if it ends at least `guard_s` before the
block's end (otherwise it may be cut); the next block, which sees that audio as left
context, re-decodes it completely. Words already emitted for a global speaker are not
re-emitted (start must be >= last emitted end - tolerance). Malformed blocks (NaN/Inf)
are skipped and reported instead of aborting the stream."""
from __future__ import annotations

import time

import numpy as np
import torch
import torch.nn.functional as F

from src.audio.loader import AudioError
from src.audio.preprocessing import iter_blocks
from src.models.aggregation import Segment, aggregate, speaker_label, words_to_segments
from src.inference.pipeline import diarization_segments


class SpeakerBank:
    def __init__(self, dim: int, device: torch.device, capacity: int = 8, threshold: float = 0.6,
                 momentum: float = 0.9):
        self.bank = torch.zeros(capacity, dim, device=device)
        self.n = torch.zeros((), dtype=torch.long, device=device)
        self.capacity, self.threshold, self.momentum = capacity, threshold, momentum

    @torch.no_grad()
    def match(self, att: torch.Tensor, present: torch.Tensor) -> torch.Tensor:
        """att (K, D), present (K,) bool -> global ids (K,) long (-1: absent or bank full)."""
        a = F.normalize(att.float(), dim=-1)
        ids = torch.full((att.shape[0],), -1, dtype=torch.long, device=att.device)
        used = torch.zeros(self.capacity, dtype=torch.bool, device=att.device)
        rows = torch.arange(self.capacity, device=att.device)
        for k in range(att.shape[0]):  # K is the static capacity -> loop has fixed length
            valid = (rows < self.n) & ~used
            sim = torch.where(valid, self.bank @ a[k], torch.full_like(self.bank[:, 0], -2.0))
            best_v, best_i = sim.max(0)
            is_match = present[k] & (best_v > self.threshold)
            is_new = present[k] & ~is_match & (self.n < self.capacity)
            new_i = self.n.clamp(max=self.capacity - 1)
            gid = torch.where(is_match, best_i, torch.where(is_new, new_i, ids.new_tensor(-1)))
            ids[k] = gid
            upd = F.normalize(self.momentum * self.bank[best_i] + (1 - self.momentum) * a[k], dim=0)
            row_match = (rows == best_i) & is_match
            row_new = (rows == new_i) & is_new
            self.bank = torch.where(row_match[:, None], upd[None], self.bank)
            self.bank = torch.where(row_new[:, None], a[k][None], self.bank)
            used |= row_match | row_new
            self.n = self.n + is_new.long()
        return ids


class StreamingTranscriber:
    def __init__(self, pipeline, block_s: float = 2.0, hop_s: float | None = None, left_context_s: float = 2.0,
                 match_threshold: float = 0.6, guard_s: float = 0.15, sr: int = 16000):
        self.p, self.block_s, self.hop_s, self.ctx_s = pipeline, block_s, hop_s or block_s, left_context_s
        self.guard_s, self.sr = guard_s, sr
        self.bank = SpeakerBank(pipeline.model.stdn.eda.dim, pipeline.device, threshold=match_threshold)
        self.last_end: dict[int, float] = {}
        self.segments: list[Segment] = []
        self.diar: list = []
        self.block_stats: list[dict] = []
        self.errors: list[str] = []

    def feed_block(self, blk, final: bool) -> list[Segment]:
        start_s, end_s = blk.start_sample / self.sr, blk.end_sample / self.sr
        t0 = time.perf_counter()
        try:
            res = self.p.process_block(blk.audio, blk.ctx_start / self.sr, bank=self.bank)
        except AudioError as e:
            self.errors.append(f"block {blk.index}: {e}")
            return []
        wall = time.perf_counter() - t0
        new = []
        for k, sp in res.speakers.items():
            gid = sp.get("bank_id", -1)
            label = speaker_label(gid)
            limit = end_s if final else end_s - self.guard_s
            keep = [w for w in sp["words"] if w.end <= limit and w.start >= self.last_end.get(gid, -1) - 0.05
                    and w.end > start_s - 0.05]
            if keep:
                self.last_end[gid] = max(w.end for w in keep)
                new += words_to_segments(keep, label, confidence=sp["exist_prob"], uncertain=sp["uncertain"] or gid < 0)
        labels = {k: speaker_label(sp.get("bank_id", -1)) for k, sp in res.speakers.items()}
        for s, e, lab in diarization_segments(res, labels=labels):
            s2, e2 = max(s, start_s), min(e, end_s)
            if e2 > s2:
                self.diar.append((s2, e2, lab))
        self.segments += new
        self.block_stats.append({"block": blk.index, "start_s": start_s, "end_s": end_s, "wall_s": wall,
                                 "block_audio_s": (blk.end_sample - blk.start_sample) / self.sr,
                                 "rtf": wall / max(1e-9, self.hop_s), "timings": res.timings,
                                 "n_crossings": res.transfers["n_crossings"]})
        return new

    def run(self, audio: np.ndarray) -> dict:
        blocks = list(iter_blocks(audio, self.sr, self.block_s, self.hop_s, self.ctx_s))
        for i, blk in enumerate(blocks):
            self.feed_block(blk, final=i == len(blocks) - 1)
        dur = len(audio) / self.sr
        return {"segments": aggregate(self.segments, dur), "diarization": _merge_diar(self.diar),
                "blocks": self.block_stats, "errors": self.errors}


def _merge_diar(segs, gap: float = 0.05):
    out = []
    for s, e, lab in sorted(segs, key=lambda x: (x[2], x[0])):
        if out and out[-1][2] == lab and s - out[-1][1] <= gap:
            out[-1] = (out[-1][0], max(out[-1][1], e), lab)
        else:
            out.append((s, e, lab))
    return sorted(out)
