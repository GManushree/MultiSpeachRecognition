"""Offline inference: whole-file transcription and model loading helpers."""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import torch

from src.audio.loader import AudioError, load_audio
from src.inference.pipeline import build_pipeline, diarization_segments
from src.inference.streaming import StreamingTranscriber
from src.models.aggregation import aggregate, speaker_label, words_to_segments
from src.models.joint_model import JointModel
from src.models.rescoring import CharLSTMLM
from src.training.checkpoints import load_checkpoint
from src.utils.config import resolve_path


def load_models(cfg: dict, device: torch.device, checkpoint: str | None = None,
                lm_checkpoint: str | None = None):
    """Loads trained weights. Missing checkpoints raise - never silently random."""
    model = JointModel(cfg["model"])
    ck = load_checkpoint(resolve_path(checkpoint or cfg["checkpoint"]), model, map_location="cpu")
    lm = None
    lm_path = lm_checkpoint or cfg.get("lm_checkpoint")
    if lm_path:
        lm = CharLSTMLM(**cfg["model"]["lm"])
        load_checkpoint(resolve_path(lm_path), lm, map_location="cpu")
    info = {"checkpoint": str(checkpoint or cfg["checkpoint"]), "stage": ck.get("stage"), "step": ck.get("step"),
            "lm_checkpoint": lm_path}
    return model.to(device).eval(), (lm.to(device).eval() if lm else None), info


class OfflineTranscriber:
    """Single pass for recordings up to `max_single_block_s`; longer ones are processed with
    the streaming machinery (large blocks + left context) and aggregated."""

    def __init__(self, model, lm, cfg: dict, device, precision="fp32", max_single_block_s: float = 20.0, **overrides):
        self.pipeline = build_pipeline(model, lm, cfg, device, precision, **overrides)
        self.cfg, self.max_single = cfg, max_single_block_s

    def transcribe_array(self, audio: np.ndarray, sr: int = 16000) -> dict:
        if audio.size == 0:
            raise AudioError("empty audio")
        dur = len(audio) / sr
        t0 = time.perf_counter()
        if dur <= self.max_single:
            res = self.pipeline.process_block(audio, 0.0)
            segs = []
            labels = {}
            for n, (k, sp) in enumerate(sorted(res.speakers.items())):
                labels[k] = speaker_label(n)
                segs += words_to_segments(sp["words"], labels[k], self.cfg["pipeline"].get("merge_gap_s", 0.6),
                                          sp["exist_prob"], sp["uncertain"])
            out = {"segments": aggregate(segs, dur), "diarization": diarization_segments(res, labels=labels),
                   "timings": res.timings, "transfers": res.transfers,
                   "speakers": {labels[k]: {"text": v["text"], "exist_prob": v["exist_prob"]}
                                for k, v in res.speakers.items()}}
        else:
            st = StreamingTranscriber(self.pipeline, block_s=10.0, left_context_s=2.0)
            out = st.run(audio)
        out["processing_s"] = time.perf_counter() - t0
        out["duration_s"] = dur
        out["rtf"] = out["processing_s"] / dur
        return out

    def transcribe_file(self, path: str | Path) -> dict:
        return self.transcribe_array(load_audio(path, 16000))
