// Fused power-spectrum -> sparse Mel projection -> log, CUDA implementation.
//
// Why a custom kernel: the PyTorch baseline materializes a (B, 201, T) power tensor and
// then runs a dense (80 x 201) GEMM even though each triangular Mel filter is non-zero
// on only a few contiguous FFT bins. This kernel reads the complex STFT once, squares it
// in registers and accumulates only each band's non-zero bins, then applies the log.
//
// Layout: spec (B, F, T, 2) float32 [real, imag]; fb (M, F) float32;
//         band_lo/band_hi (M) int32 half-open bin ranges; out (B, M, T) float32.
// Thread mapping: t is the fastest-varying index so reads of spec[b, f, t] coalesce.
//
// STATUS: written against the CPU kernel's semantics; NOT compiled or executed in the
// development environment (no nvcc / GPU). See docs/limitations.md.
#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>
#include <c10/cuda/CUDAStream.h>

__global__ void fused_log_mel_kernel(const float* __restrict__ spec, const float* __restrict__ fb,
                                     const int* __restrict__ band_lo, const int* __restrict__ band_hi,
                                     float* __restrict__ out, int B, int F, int T, int M, float eps) {
  long idx = (long)blockIdx.x * blockDim.x + threadIdx.x;
  long total = (long)B * M * T;
  if (idx >= total) return;
  int t = idx % T;
  int m = (idx / T) % M;
  int b = idx / ((long)T * M);
  float acc = 0.f;
  const float* sb = spec + (long)b * F * T * 2;
  for (int f = band_lo[m]; f < band_hi[m]; ++f) {
    float re = sb[((long)f * T + t) * 2];
    float im = sb[((long)f * T + t) * 2 + 1];
    acc = fmaf(fb[(long)m * F + f], re * re + im * im, acc);
  }
  out[idx] = logf(acc + eps);
}

torch::Tensor fused_log_mel_cuda(torch::Tensor spec, torch::Tensor fb, torch::Tensor band_lo,
                                 torch::Tensor band_hi, double eps) {
  const int B = spec.size(0), F = spec.size(1), T = spec.size(2), M = fb.size(0);
  auto out = torch::empty({B, M, T}, spec.options());
  long total = (long)B * M * T;
  const int threads = 256;
  const int blocks = (int)((total + threads - 1) / threads);
  // Launch on PyTorch's current stream so the op composes with caller-managed streams.
  cudaStream_t stream = c10::cuda::getCurrentCUDAStream();
  fused_log_mel_kernel<<<blocks, threads, 0, stream>>>(
      spec.data_ptr<float>(), fb.data_ptr<float>(), band_lo.data_ptr<int>(),
      band_hi.data_ptr<int>(), out.data_ptr<float>(), B, F, T, M, (float)eps);
  C10_CUDA_KERNEL_LAUNCH_CHECK();
  return out;
}
