// Python bindings + CPU implementation of the fused log-Mel op.
// The CPU path has identical semantics to kernels.cu and is what the test-suite
// validates when no GPU is present. Built with -DWITH_CUDA only when nvcc exists.
#include <torch/extension.h>
#include <ATen/Parallel.h>
#include <cmath>

#ifdef WITH_CUDA
torch::Tensor fused_log_mel_cuda(torch::Tensor spec, torch::Tensor fb, torch::Tensor band_lo,
                                 torch::Tensor band_hi, double eps);
#endif

static torch::Tensor fused_log_mel_cpu(torch::Tensor spec, torch::Tensor fb,
                                       torch::Tensor band_lo, torch::Tensor band_hi, double eps) {
  const int64_t B = spec.size(0), F = spec.size(1), T = spec.size(2), M = fb.size(0);
  auto out = torch::empty({B, M, T}, spec.options());
  const float* s = spec.data_ptr<float>();
  const float* w = fb.data_ptr<float>();
  const int* lo = band_lo.data_ptr<int>();
  const int* hi = band_hi.data_ptr<int>();
  float* o = out.data_ptr<float>();
  at::parallel_for(0, B * M, 1, [&](int64_t begin, int64_t end) {
    for (int64_t bm = begin; bm < end; ++bm) {
      const int64_t b = bm / M, m = bm % M;
      const float* sb = s + b * F * T * 2;
      float* ob = o + bm * T;
      for (int64_t t = 0; t < T; ++t) ob[t] = 0.f;
      for (int64_t f = lo[m]; f < hi[m]; ++f) {
        const float wf = w[m * F + f];
        const float* row = sb + f * T * 2;
        for (int64_t t = 0; t < T; ++t) {
          const float re = row[2 * t], im = row[2 * t + 1];
          ob[t] += wf * (re * re + im * im);
        }
      }
      for (int64_t t = 0; t < T; ++t) ob[t] = std::log(ob[t] + (float)eps);
    }
  });
  return out;
}

torch::Tensor fused_log_mel(torch::Tensor spec, torch::Tensor fb, torch::Tensor band_lo,
                            torch::Tensor band_hi, double eps) {
  TORCH_CHECK(spec.dim() == 4 && spec.size(3) == 2, "spec must be (B, F, T, 2)");
  TORCH_CHECK(spec.scalar_type() == torch::kFloat32 && fb.scalar_type() == torch::kFloat32,
              "float32 inputs required");
  TORCH_CHECK(band_lo.scalar_type() == torch::kInt32 && band_hi.scalar_type() == torch::kInt32,
              "int32 band indices required");
  TORCH_CHECK(fb.size(1) == spec.size(1), "filterbank/frequency size mismatch");
  spec = spec.contiguous(); fb = fb.contiguous();
  band_lo = band_lo.contiguous(); band_hi = band_hi.contiguous();
  if (spec.is_cuda()) {
#ifdef WITH_CUDA
    return fused_log_mel_cuda(spec, fb, band_lo, band_hi, eps);
#else
    TORCH_CHECK(false, "extension built without CUDA support");
#endif
  }
  return fused_log_mel_cpu(spec, fb, band_lo, band_hi, eps);
}

bool built_with_cuda() {
#ifdef WITH_CUDA
  return true;
#else
  return false;
#endif
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("fused_log_mel", &fused_log_mel, "Fused power->sparse Mel->log (CPU / CUDA)");
  m.def("built_with_cuda", &built_with_cuda);
}
