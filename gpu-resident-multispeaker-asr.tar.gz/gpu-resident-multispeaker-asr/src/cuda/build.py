"""JIT build of the fused log-Mel extension.

Compiles bindings.cpp (CPU kernel) always, and kernels.cu (CUDA kernel) only when a CUDA
toolkit is found. Build artefacts go to build/torch_ext. `python -m src.cuda.build`
builds and reports what was compiled."""
from __future__ import annotations

import functools
import os
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUILD_DIR = HERE.parents[1] / "build" / "torch_ext"


def cuda_toolkit_available() -> bool:
    import torch
    from torch.utils.cpp_extension import CUDA_HOME
    return torch.cuda.is_available() and CUDA_HOME is not None and shutil.which("nvcc") is not None


@functools.lru_cache(maxsize=1)
def load_extension(verbose: bool = False):
    from torch.utils.cpp_extension import load
    BUILD_DIR.mkdir(parents=True, exist_ok=True)
    with_cuda = cuda_toolkit_available()
    sources = [str(HERE / "bindings.cpp")] + ([str(HERE / "kernels.cu")] if with_cuda else [])
    flags = ["-O3"] + (["-DWITH_CUDA"] if with_cuda else [])
    return load(name="msasr_fused_logmel" + ("_cuda" if with_cuda else "_cpu"), sources=sources,
                extra_cflags=flags, extra_cuda_cflags=["-O3", "--use_fast_math"] if with_cuda else None,
                build_directory=str(BUILD_DIR), verbose=verbose, with_cuda=with_cuda)


def extension_status() -> dict:
    """Never raises: reports whether the extension builds and with which backends."""
    try:
        ext = load_extension()
        return {"built": True, "cpu_kernel": True, "cuda_kernel": bool(ext.built_with_cuda())}
    except Exception as e:  # reported verbatim in the environment report
        return {"built": False, "error": f"{type(e).__name__}: {str(e)[:300]}"}


if __name__ == "__main__":
    os.environ.setdefault("MAX_JOBS", "2")
    print(extension_status())
