"""Structured logging: human-readable console plus JSON-lines metric logs."""
from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path


def get_logger(name: str = "msasr", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        h = logging.StreamHandler(sys.stdout)
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%H:%M:%S"))
        logger.addHandler(h)
        logger.setLevel(level)
        logger.propagate = False
    return logger


class JsonlLogger:
    """Appends one JSON record per call; used for training curves and benchmark rows."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, **record):
        record.setdefault("time", time.time())
        with open(self.path, "a") as f:
            f.write(json.dumps(record, default=_default) + "\n")


def _default(o):
    try:
        return float(o)
    except Exception:
        return str(o)
