"""YAML configuration loading with `defaults` inheritance and dotted overrides."""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]


def deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(path: str | Path, overrides: list[str] | None = None) -> dict[str, Any]:
    """Load a YAML file. A top-level `defaults: [a.yaml, ...]` list is merged first
    (paths relative to the file). `overrides` are `key.sub=value` strings parsed as YAML."""
    path = Path(path)
    if not path.is_absolute() and not path.exists():
        path = ROOT / path
    with open(path) as f:
        cfg = yaml.safe_load(f) or {}
    merged: dict = {}
    for dep in cfg.pop("defaults", []) or []:
        merged = deep_merge(merged, load_config(path.parent / dep))
    merged = deep_merge(merged, cfg)
    for ov in overrides or []:
        key, _, raw = ov.partition("=")
        node = merged
        parts = key.split(".")
        for p in parts[:-1]:
            node = node.setdefault(p, {})
        node[parts[-1]] = yaml.safe_load(raw)
    return merged


def resolve_path(p: str | Path) -> Path:
    p = Path(p)
    return p if p.is_absolute() else ROOT / p
