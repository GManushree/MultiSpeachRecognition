"""Device selection, autocast policy, and timing/memory helpers."""
from __future__ import annotations

import contextlib
import time

import torch


def select_device(pref: str = "auto") -> torch.device:
    if pref == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dev = torch.device(pref)
    if dev.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but torch.cuda.is_available() is False")
    return dev


def autocast_ctx(device: torch.device, precision: str):
    """precision: 'fp32' | 'fp16' | 'bf16'. FP16 autocast is the paper's mixed-precision
    mode on CUDA; on CPU only bf16 autocast exists, so 'fp16' on CPU raises instead of
    silently running something else."""
    if precision == "fp32":
        return contextlib.nullcontext()
    dtype = {"fp16": torch.float16, "bf16": torch.bfloat16}[precision]
    if device.type == "cpu" and dtype is torch.float16:
        raise ValueError("fp16 autocast is not supported on CPU; use bf16 for the CPU ablation")
    return torch.autocast(device_type=device.type, dtype=dtype)


def sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


class Timer:
    """Wall-clock timer that synchronizes CUDA at boundaries so kernel time is included."""

    def __init__(self, device: torch.device):
        self.device = device

    def __enter__(self):
        sync(self.device)
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *exc):
        sync(self.device)
        self.elapsed = time.perf_counter() - self.t0


def param_bytes(module: torch.nn.Module) -> int:
    return sum(p.numel() * p.element_size() for p in module.parameters())


def peak_memory_mb(device: torch.device) -> float | None:
    if device.type == "cuda":
        return torch.cuda.max_memory_allocated(device) / 2**20
    return None


def rss_mb() -> float:
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS"):
                    return int(line.split()[1]) / 1024
    except OSError:
        pass
    return float("nan")
