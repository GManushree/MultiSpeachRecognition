"""Transcribe a recording:
  python scripts/transcribe.py --audio data/example.wav --checkpoint checkpoints/joint.pt --output results/transcript.json
Optional: --streaming (block processing), --mode cascaded, --srt/--txt exports, --channel N."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.audio.loader import load_audio  # noqa: E402
from src.inference.offline import OfflineTranscriber, load_models  # noqa: E402
from src.inference.pipeline import build_pipeline  # noqa: E402
from src.inference.streaming import StreamingTranscriber  # noqa: E402
from src.models.aggregation import to_json, to_srt, to_text  # noqa: E402
from src.utils.config import load_config  # noqa: E402
from src.utils.device import select_device  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--audio", required=True)
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--lm-checkpoint", default=None)
    ap.add_argument("--config", default="configs/inference.yaml")
    ap.add_argument("--output", default="results/transcript.json")
    ap.add_argument("--streaming", action="store_true")
    ap.add_argument("--mode", choices=["resident", "cascaded"], default=None)
    ap.add_argument("--precision", default=None)
    ap.add_argument("--channel", type=int, default=None)
    ap.add_argument("--srt", default=None)
    ap.add_argument("--txt", default=None)
    a = ap.parse_args()
    cfg = load_config(a.config)
    device = select_device(cfg.get("device", "auto"))
    precision = a.precision or cfg.get("precision", "fp32")
    model, lm, info = load_models(cfg, device, a.checkpoint, a.lm_checkpoint)
    audio = load_audio(a.audio, 16000, channel=a.channel)
    over = {"mode": a.mode} if a.mode else {}
    if a.streaming:
        s = cfg["streaming"]
        st = StreamingTranscriber(build_pipeline(model, lm, cfg, device, precision, **over), s["block_s"], s["hop_s"],
                                  s["left_context_s"], s["speaker_match_threshold"])
        out = st.run(audio)
        out["duration_s"] = len(audio) / 16000
    else:
        out = OfflineTranscriber(model, lm, cfg, device, precision, **over).transcribe_array(audio)
    segs = out["segments"]
    to_json(segs, a.output)
    if a.srt:
        Path(a.srt).write_text(to_srt(segs))
    if a.txt:
        Path(a.txt).write_text(to_text(segs))
    print(to_text(segs) or "(no speech recognized)")
    meta = {k: out[k] for k in ("duration_s", "processing_s", "rtf", "transfers") if k in out}
    meta.update(device=device.type, precision=precision, model=info)
    print(json.dumps(meta, default=str, indent=1)[:1500])


if __name__ == "__main__":
    main()
