"""Train the system: python scripts/train.py --config configs/training.yaml [--stage all|lm|diarization|asr|separation|joint]

--smoke runs every selected stage for a handful of steps on a few items (pipeline check only;
a smoke run says nothing about convergence)."""
from __future__ import annotations

import argparse
import json
import signal
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch  # noqa: E402

from src.training.stages import STAGE_ORDER, run_stage  # noqa: E402
from src.utils.config import load_config  # noqa: E402
from src.utils.device import select_device  # noqa: E402
from src.utils.logging import JsonlLogger, get_logger  # noqa: E402
from src.utils.reproducibility import provenance  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/training.yaml")
    ap.add_argument("--stage", default="all", help="all or comma-separated stages: " + ",".join(STAGE_ORDER))
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("overrides", nargs="*", help="key.sub=value config overrides")
    a = ap.parse_args()

    def _on_term(signum, frame):  # make SIGTERM go through the trainer's crash-checkpoint path
        raise KeyboardInterrupt(f"signal {signum}")
    signal.signal(signal.SIGTERM, _on_term)
    cfg = load_config(a.config, a.overrides)
    if a.smoke:
        cfg["out_dir"], cfg["log_dir"] = "checkpoints/smoke", "results/train_logs/smoke"
    if a.threads:
        torch.set_num_threads(a.threads)
    device = select_device(cfg.get("device", "auto"))
    log = get_logger("train")
    stages = STAGE_ORDER if a.stage == "all" else a.stage.split(",")
    JsonlLogger(Path(cfg["log_dir"]) / "runs.jsonl").log(event="run", stages=stages, smoke=a.smoke,
                                                         provenance=provenance(), config=cfg)
    results = {}
    for s in stages:
        if s not in STAGE_ORDER:
            raise SystemExit(f"unknown stage {s}")
        log.info(f"===== stage {s} =====")
        results[s] = run_stage(s, cfg, device, smoke=a.smoke, resume=a.resume)
        log.info(f"stage {s} done: {results[s]}")
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
