"""Evaluate the system:
  python scripts/evaluate.py --config configs/evaluation.yaml               # test manifest
  python scripts/evaluate.py --config configs/evaluation.yaml --ablations   # ablations 1, 2, 5, 6
Results: results/eval/*.json (every record carries provenance + checkpoint + settings)."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch  # noqa: E402

from src.evaluation.evaluate import evaluate_manifest  # noqa: E402
from src.inference.offline import load_models  # noqa: E402
from src.utils.config import load_config, resolve_path  # noqa: E402
from src.utils.device import select_device  # noqa: E402
from src.utils.logging import get_logger  # noqa: E402
from src.utils.reproducibility import provenance  # noqa: E402

log = get_logger("eval")


def _save(obj, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=str))
    log.info(f"wrote {path}")


def _brief(r):
    b = {"cpWER": round(r["cpwer"]["rate"], 4), "DER": round(r["der"]["der"], 4),
         "count_acc": round(r["speaker_count_accuracy"], 3)}
    if "separation" in r:
        b["SI-SDRi"] = r["separation"]["si_sdri_mean_db"]
        b["SI-SDRi_multi"] = r["separation"]["si_sdri_multispeaker_db"]
        b["SI-SDRi_by_k"] = r["separation"]["si_sdri_by_k_db"]
    if "oracle_source_wer" in r:
        b["oracle_src_WER"] = round(r["oracle_source_wer"]["rate"], 4)
    return b


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/evaluation.yaml")
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--ablations", action="store_true")
    ap.add_argument("--max-items", type=int, default=None)
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("overrides", nargs="*")
    a = ap.parse_args()
    cfg = load_config(a.config, a.overrides)
    if a.threads:
        torch.set_num_threads(a.threads)
    device = select_device(cfg.get("device", "auto"))
    out_dir = resolve_path(cfg["out_dir"])
    prov = provenance()
    collar = cfg["der"]["collar"]
    max_items = a.max_items or cfg.get("max_items")
    model, lm, info = load_models(cfg, device, a.checkpoint)
    common = dict(collar=collar, max_items=max_items)

    if not a.ablations:
        for name, man in cfg["manifests"].items():
            r = evaluate_manifest(model, lm, cfg, device, str(resolve_path(man)), cfg.get("precision", "fp32"),
                                  keep_items=True, **common)
            r.update(provenance=prov, model=info, dataset=name)
            _save(r, out_dir / f"eval_{name}.json")
            print(name, json.dumps(_brief(r)))
        return

    root = resolve_path("data/synthetic")
    test = str(root / "test.jsonl")
    results = {"provenance": prov}
    # Ablation 1: joint vs separately trained components (same pipeline settings)
    abl1 = {}
    # control: every module trained separately (STDN, ASR, separator, ASR adapted to the frozen
    # separator); joint: all modules fine-tuned with L_total. joint_v1 = first, collapsed recipe.
    for tag, ck in (("separate", "checkpoints/asr_adapt.pt"), ("joint", "checkpoints/joint.pt"),
                    ("joint_v1_collapsed", "checkpoints/joint_v1_collapsed.pt")):
        m, l, inf = load_models(cfg, device, ck)
        r = evaluate_manifest(m, l, cfg, device, test, **common)
        abl1[tag] = {"checkpoint": inf, **_brief(r), "full": r}
        log.info(f"ablation1 {tag}: {_brief(r)}")
    results["ablation1_joint_training"] = abl1
    # Ablation 2: precision (accuracy part; latency/memory part is in benchmark.py)
    precs = ["fp32", "fp16"] if device.type == "cuda" else ["fp32", "bf16"]
    abl2 = {}
    for p in precs:
        r = evaluate_manifest(model, lm, cfg, device, test, p, with_separation=False, with_oracle=False, **common)
        abl2[p] = {**_brief(r), "latency_s": r["latency_s"], "rtf_mean": r["rtf_mean"]}
        log.info(f"ablation2 {p}: {abl2[p]}")
    if device.type != "cuda":
        abl2["note"] = "FP16 autocast requires CUDA; bf16 CPU autocast is reported as the closest available proxy."
    results["ablation2_precision"] = abl2
    # Ablation 5: overlap ratio (K = 2)
    abl5 = {}
    for ov in ("00", "20", "40", "60"):
        man = root / f"test_k2_ov{ov}.jsonl"
        r = evaluate_manifest(model, lm, cfg, device, str(man), **common)
        abl5[f"target_overlap_0.{ov}"] = {**_brief(r), "measured_overlap_ratio": _mean_overlap(man)}
        log.info(f"ablation5 ov{ov}: {abl5[f'target_overlap_0.{ov}']}")
    results["ablation5_overlap"] = abl5
    # Ablation 6: speaker count (target overlap 0.3)
    abl6 = {"configured_capacity": model.max_speakers, "trained_max_speakers": 3}
    for k in (1, 2, 3):
        man = root / f"test_k{k}_ov30.jsonl"
        if man.exists():
            r = evaluate_manifest(model, lm, cfg, device, str(man), **common)
            abl6[f"k{k}"] = _brief(r) | {"count_mean_error": r["speaker_count_mean_error"]}
            log.info(f"ablation6 k{k}: {abl6[f'k{k}']}")
    results["ablation6_speaker_count"] = abl6
    _save(results, out_dir / "ablations.json")


def _mean_overlap(man):
    from src.training.datasets import read_manifest
    rows = read_manifest(man)
    return round(sum(r["overlap_ratio"] for r in rows) / len(rows), 3)


if __name__ == "__main__":
    main()
