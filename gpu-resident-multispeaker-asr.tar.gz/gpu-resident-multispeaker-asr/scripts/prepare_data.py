"""Prepare datasets: python scripts/prepare_data.py --config configs/training.yaml [--only synthetic|ami|chime7]

* synthetic: generated locally with eSpeak NG (no download).
* AMI / CHiME-7: never downloaded automatically (large, licence terms). Set data.ami.root /
  data.chime7.root to a local copy; manifests are then built from it.
Writes manifest validation and dataset statistics to <data.root>/prepare_report.json."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.synthetic import generate_corpus  # noqa: E402
from src.training.datasets import manifest_stats, read_manifest, validate_manifest  # noqa: E402
from src.utils.config import load_config, resolve_path  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/training.yaml")
    ap.add_argument("--only", default="synthetic,ami,chime7")
    ap.add_argument("--force", action="store_true", help="regenerate an existing synthetic corpus")
    ap.add_argument("overrides", nargs="*")
    a = ap.parse_args()
    cfg = load_config(a.config, a.overrides)
    root = resolve_path(cfg["data"]["root"])
    which = a.only.split(",")
    report = {}
    if "synthetic" in which:
        meta_path = root / "corpus_meta.json"
        if meta_path.exists() and not a.force:
            print(f"synthetic corpus exists at {root} (use --force to regenerate)")
            manifests = json.loads(meta_path.read_text())["manifests"]
        else:
            manifests = generate_corpus(cfg["data"]["synthetic"], root)["manifests"]
        for name, m in manifests.items():
            rows = read_manifest(m)
            report[f"synthetic/{name}"] = {"validation": validate_manifest(rows), "stats": manifest_stats(rows)}
    ami = cfg["data"].get("ami", {})
    if "ami" in which:
        if ami.get("root"):
            from src.data.ami import build_ami_manifest
            report["ami"] = build_ami_manifest(ami["root"], root.parent / "ami", ami.get("mic", "Mix-Headset"),
                                               ami.get("window_s", 8.0))
        else:
            report["ami"] = "SKIPPED: data.ami.root not set (download AMI separately; see docs/training_guide.md)"
    ch = cfg["data"].get("chime7", {})
    if "chime7" in which:
        if ch.get("root"):
            from src.data.chime7 import build_chime7_manifest
            report["chime7"] = build_chime7_manifest(ch["root"], root.parent / "chime7", ch.get("scenario", "chime6"),
                                                     ch.get("split", "dev"))
        else:
            report["chime7"] = "SKIPPED: data.chime7.root not set (prepare with official CHiME-7 DASR scripts)"
    root.mkdir(parents=True, exist_ok=True)
    (root / "prepare_report.json").write_text(json.dumps(report, indent=2, default=str))
    for k, v in report.items():
        if isinstance(v, dict) and "stats" in v:
            val = v["validation"]
            print(f"{k}: ok={val['ok']} missing={len(val['missing_files'])} {v['stats']}")
        else:
            print(f"{k}: {v if isinstance(v, str) else json.dumps(v, default=str)[:300]}")


if __name__ == "__main__":
    main()
