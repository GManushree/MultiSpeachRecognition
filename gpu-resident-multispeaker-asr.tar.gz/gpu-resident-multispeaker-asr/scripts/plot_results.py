"""Plot training curves and benchmark/ablation results: python scripts/plot_results.py
Reads results/train_logs/*.jsonl, results/benchmark/benchmark.json, results/eval/ablations.json;
writes PNGs to results/figures/. Only plots values that exist in those files."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "figures"


def training_curves():
    logs = sorted((ROOT / "results/train_logs").glob("*.jsonl"))
    logs = [p for p in logs if p.stem in ("diarization", "asr", "separation", "joint")]
    if not logs:
        return
    fig, axes = plt.subplots(2, len(logs), figsize=(4 * len(logs), 6), squeeze=False)
    for i, p in enumerate(logs):
        df = pd.DataFrame([json.loads(l) for l in p.read_text().splitlines()])
        tr, ev = df[df.event == "train"], df[df.event == "eval"]
        for col in [c for c in ("total", "ctc", "l_diar", "l_sep", "l_asr") if c in tr and tr[c].notna().any()]:
            axes[0, i].plot(tr.step, tr[col], label=col)
        axes[0, i].set_title(f"{p.stem}: training loss")
        axes[0, i].legend(fontsize=7)
        if len(ev):
            axes[1, i].plot(ev.step, ev.metric, marker="o")
            axes[1, i].set_title(f"{p.stem}: validation metric")
        for ax in axes[:, i]:
            ax.set_xlabel("step")
            ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT / "training_curves.png", dpi=120)


def benchmark_plots():
    p = ROOT / "results/benchmark/benchmark.json"
    if not p.exists():
        return
    b = json.loads(p.read_text())
    lat = b["latency_500ms"]
    names = list(lat)
    mods = [m for m in ("h2d", "features", "diarization", "separation", "asr", "rescoring", "d2h")]
    fig, ax = plt.subplots(figsize=(8, 4))
    bottom = [0.0] * len(names)
    for m in mods:
        vals = [lat[n]["per_module_median_s"].get(m, 0) * 1e3 for n in names]
        ax.bar(names, vals, bottom=bottom, label=m)
        bottom = [a + v for a, v in zip(bottom, vals)]
    ax.axhline(100, color="k", ls="--", lw=1, label="100 ms budget (RTF 0.2)")
    ax.set_ylabel("median ms per 500 ms block")
    ax.set_title(f"Per-module latency ({b['provenance']['processor']}, {'CUDA' if b['provenance']['cuda_available'] else 'CPU only'})")
    ax.legend(fontsize=7, ncol=2)
    plt.xticks(rotation=20, fontsize=8)
    fig.tight_layout()
    fig.savefig(OUT / "latency_breakdown.png", dpi=120)
    sw = b["block_size_sweep"]
    fig, ax = plt.subplots(figsize=(5, 3.5))
    xs = [float(k) for k in sw]
    ax.plot(xs, [sw[k]["rtf_median"] for k in sw], marker="o")
    ax.axhline(0.2, color="k", ls="--", lw=1)
    ax.set_xlabel("block duration (s)")
    ax.set_ylabel("RTF (median)")
    ax.set_title("Block size vs real-time factor")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT / "block_size_rtf.png", dpi=120)


def ablation_plots():
    p = ROOT / "results/eval/ablations.json"
    if not p.exists():
        return
    a = json.loads(p.read_text())
    ov = a["ablation5_overlap"]
    xs = [v["measured_overlap_ratio"] for v in ov.values()]
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.2))
    for ax, key, lab in zip(axes, ("cpWER", "DER", "SI-SDRi"), ("cpWER", "DER", "SI-SDRi (dB)")):
        ax.plot(xs, [v.get(key) for v in ov.values()], marker="o")
        ax.set_xlabel("measured overlap ratio")
        ax.set_title(lab)
        ax.grid(alpha=0.3)
    fig.suptitle("Ablation 5: overlap (K = 2, synthetic test speakers)", fontsize=10)
    fig.tight_layout()
    fig.savefig(OUT / "ablation_overlap.png", dpi=120)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    training_curves()
    benchmark_plots()
    ablation_plots()
    print("\n".join(str(p) for p in sorted(OUT.glob("*.png"))) or "nothing to plot", file=sys.stdout)
