"""Benchmark the pipeline: python scripts/benchmark.py --config configs/benchmark.yaml

Measures (all on the current hardware, written to results/benchmark/benchmark.json + CSV):
  * 500 ms block latency: resident (2 crossings), controlled 4-crossing, resident+host beam,
    cascaded baseline; per-module medians, p95, RTF, RTF<0.2 check, dominant module
  * block-size sweep (resident), throughput, CPU preprocessing overhead, memory
  * precision latency (fp32 vs fp16 on CUDA / bf16 on CPU)
  * rescoring: serial vs CUDA streams vs batched on identical inputs
  * crossing cost probe (CUDA only) and the L_sync estimate (T_n4 - T_n2) / 2
Analytical latency-model values are reported in a separate, explicitly labelled section."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch  # noqa: E402

from src.evaluation.latency import (block_latency, collect_blocks, crossing_cost_probe,  # noqa: E402
                                    preprocessing_overhead, rescoring_modes, throughput)
from src.evaluation.throughput import memory_report  # noqa: E402
from src.evaluation.transfer_profiler import analytical_rtf, estimate_l_sync, profile_memcpy  # noqa: E402
from src.inference.offline import load_models  # noqa: E402
from src.inference.pipeline import build_pipeline  # noqa: E402
from src.utils.config import load_config, resolve_path  # noqa: E402
from src.utils.device import select_device  # noqa: E402
from src.utils.logging import get_logger  # noqa: E402
from src.utils.reproducibility import provenance, set_seed  # noqa: E402

log = get_logger("bench")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/benchmark.yaml")
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--quick", action="store_true", help="fewer items/repeats (pipeline check)")
    ap.add_argument("overrides", nargs="*")
    a = ap.parse_args()
    cfg = load_config(a.config, a.overrides)
    if a.threads:
        torch.set_num_threads(a.threads)
    set_seed(0)
    device = select_device(cfg.get("device", "auto"))
    n, rep, wu = cfg["n_items"], cfg["repeats"], cfg["warmup"]
    if a.quick:
        n, rep, wu = 4, 1, 1
    man = str(resolve_path(cfg["manifest"]))
    model, lm, info = load_models(cfg, device, a.checkpoint)
    out = {"provenance": provenance(), "model": info, "manifest": man, "settings": {
        "n_items": n, "repeats": rep, "warmup": wu, "torch_threads": torch.get_num_threads(),
        "pipeline": cfg["pipeline"], "precision": cfg.get("precision", "fp32")}}
    bs = cfg["latency_block_s"]
    blocks = collect_blocks(man, bs, n)
    variants = {"resident_2x": {}, "resident_4x_controlled": {"n_crossings": 4},
                "resident_host_beam": {"decoder": "beam"}, "resident_dynamic_k": {"fixed_capacity": False},
                "cascaded": {"mode": "cascaded"}}
    lat = {}
    for name, ov in variants.items():
        p = build_pipeline(model, lm, cfg, device, cfg.get("precision", "fp32"), **ov)
        lat[name] = block_latency(p, blocks, bs, wu, rep)
        lat[name]["memcpy_profile"] = profile_memcpy(lambda: p.process_block(blocks[0]), device)
        log.info(f"{name}: median {lat[name]['latency_s']['median'] * 1e3:.1f} ms, RTF {lat[name]['rtf_median']:.3f}, "
                 f"crossings {lat[name]['crossings']['n_crossings']}, dominant {lat[name]['dominant_module']}")
    out["latency_500ms"] = lat
    t2, t4 = lat["resident_2x"]["latency_s"]["median"], lat["resident_4x_controlled"]["latency_s"]["median"]
    out["l_sync_estimate"] = {
        "value_s": estimate_l_sync(t4, t2), "t_n2_s": t2, "t_n4_s": t4, "device": device.type,
        "valid": device.type == "cuda",
        "note": ("Measured on CUDA: identical compute, extra round trip of the separated waveforms."
                 if device.type == "cuda" else
                 "NOT a PCIe synchronisation measurement: on CPU there is no device memory, so the extra "
                 "'crossing' is a host memcpy. Reported only to show the procedure; the difference is noise-level.")}
    sweep = {}
    p = build_pipeline(model, lm, cfg, device, cfg.get("precision", "fp32"))
    for b in cfg["block_sizes_s"]:
        sweep[str(b)] = block_latency(p, collect_blocks(man, b, n), b, wu, rep)
        log.info(f"block {b}s: median {sweep[str(b)]['latency_s']['median'] * 1e3:.1f} ms RTF {sweep[str(b)]['rtf_median']:.3f}")
    out["block_size_sweep"] = sweep
    precs = ["fp32", "fp16"] if device.type == "cuda" else ["fp32", "bf16"]
    out["precision_latency"] = {pr: block_latency(build_pipeline(model, lm, cfg, device, pr), blocks, bs, wu, rep)
                                for pr in precs}
    for pr in precs:
        log.info(f"precision {pr}: median {out['precision_latency'][pr]['latency_s']['median'] * 1e3:.1f} ms")
    out["throughput_offline"] = throughput(p, man, n)
    for k in (1, 2, 3):
        km = resolve_path(f"data/synthetic/test_k{k}_ov30.jsonl")
        if km.exists():
            out[f"throughput_k{k}"] = throughput(p, str(km), min(n, 20))
    out["preprocessing"] = preprocessing_overhead(man, n, bs)
    out["memory"] = memory_report(model, lm, device, blocks[0], p)
    out["rescoring"] = rescoring_modes(p, blocks[: min(len(blocks), 8)])
    log.info(f"rescoring serial {out['rescoring']['serial']['per_block_s']['median'] * 1e3:.2f} ms, "
             f"batched {out['rescoring']['batched']['per_block_s']['median'] * 1e3:.2f} ms")
    out["crossing_probe"] = crossing_cost_probe(device) or "NOT MEASURED: no CUDA device"
    t_comp = lat["resident_2x"]["latency_s"]["median"]
    out["analytical_model"] = {
        "label": "ANALYTICAL PREDICTION - not a measurement",
        "formula": "RTF ~= (T_comp + n * L_sync) / T_b",
        "T_comp_s (measured, this hardware)": t_comp, "T_b_s": bs,
        "predictions": {f"L_sync={ls * 1e6:.0f}us": {f"n={k}": analytical_rtf(t_comp, k, ls, bs) for k in (2, 4, 25)}
                        for ls in (10e-6, 50e-6, 200e-6)},
        "note": "L_sync values are hypothetical inputs to the model, chosen to span plausible ranges; "
                "they were not measured on this machine."}
    od = resolve_path(cfg["out_dir"])
    od.mkdir(parents=True, exist_ok=True)
    (od / "benchmark.json").write_text(json.dumps(out, indent=2, default=str))
    with open(od / "latency_500ms.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "device", "block_s", "median_ms", "p95_ms", "rtf_median", "crossings", "explicit_syncs",
                    "dominant_module"])
        for k, v in lat.items():
            w.writerow([k, device.type, bs, round(v["latency_s"]["median"] * 1e3, 2), round(v["latency_s"]["p95"] * 1e3, 2),
                        round(v["rtf_median"], 4), v["crossings"]["n_crossings"], v["crossings"]["explicit_syncs"],
                        v["dominant_module"]])
    log.info(f"wrote {od / 'benchmark.json'}")


if __name__ == "__main__":
    main()
