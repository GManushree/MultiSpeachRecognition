"""Stage 1 environment report: OS, Python, GPU, driver, CUDA, compilers, disk, packages.

Writes results/environment.json and prints a compatibility summary. Nothing here
assumes a GPU exists just because PyTorch is installed."""
from __future__ import annotations

import importlib
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def _run(cmd: list[str]) -> str | None:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=20).stdout.strip() or None
    except (OSError, subprocess.TimeoutExpired):
        return None


def main() -> dict:
    rep: dict = {
        "os": platform.platform(),
        "python": sys.version.split()[0],
        "cpu_count": os.cpu_count(),
        "disk_free_gb": round(shutil.disk_usage(ROOT).free / 2**30, 1),
    }
    try:
        with open("/proc/meminfo") as f:
            rep["ram_gb"] = round(int(f.readline().split()[1]) / 2**20, 1)
    except OSError:
        pass
    rep["nvidia_smi"] = _run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version",
                              "--format=csv,noheader"]) if shutil.which("nvidia-smi") else None
    rep["nvcc"] = (_run(["nvcc", "--version"]) or "").splitlines()[-1:] if shutil.which("nvcc") else None
    rep["gcc"] = (_run(["gcc", "--version"]) or "").splitlines()[:1] if shutil.which("gcc") else None
    rep["ninja"] = shutil.which("ninja") is not None
    pkgs = {}
    for name in ["torch", "torchaudio", "numpy", "scipy", "soundfile", "yaml", "fastapi",
                 "pytest", "pandas", "matplotlib", "pyannote.metrics", "jiwer", "espeakng_loader"]:
        try:
            m = importlib.import_module(name)
            pkgs[name] = getattr(m, "__version__", "installed")
        except Exception as e:  # report, never hide
            pkgs[name] = f"MISSING ({type(e).__name__})"
    rep["packages"] = pkgs
    try:
        import torch
        rep["torch_cuda_build"] = torch.version.cuda
        rep["cuda_available"] = torch.cuda.is_available()
        if torch.cuda.is_available():
            rep["gpus"] = [{"name": torch.cuda.get_device_name(i),
                            "mem_gb": round(torch.cuda.get_device_properties(i).total_memory / 2**30, 1),
                            "cc": ".".join(map(str, torch.cuda.get_device_capability(i)))}
                           for i in range(torch.cuda.device_count())]
    except ImportError:
        rep["cuda_available"] = False
    from src.cuda.build import extension_status
    rep["custom_extension"] = extension_status()

    notes = []
    if not rep.get("cuda_available"):
        notes.append("No usable CUDA device: GPU-resident timings, CUDA streams, FP16 and the custom "
                     "CUDA kernel cannot be measured here. CPU fallback paths will be used and labelled.")
    if not rep["nvcc"]:
        notes.append("nvcc not found: the CUDA kernel in src/cuda/kernels.cu cannot be compiled; the "
                     "C++ CPU kernel in the same extension can be built if a C++ compiler exists.")
    rep["compatibility_notes"] = notes
    out = ROOT / "results" / "environment.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(rep, indent=2))
    print(json.dumps(rep, indent=2))
    return rep


if __name__ == "__main__":
    main()
